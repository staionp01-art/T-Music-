package com.tmusic.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.Typeface
import android.os.Build
import android.text.TextPaint
import android.text.TextUtils
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.core.graphics.PathParser
import androidx.media3.session.MediaController
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun c(v: Long): Int = v.toInt()

private const val K_NORMAL = 0
private const val K_VINYL = 1
private const val K_NEON = 2
private const val K_DOT = 3
private const val K_BLUR = 4
private const val K_PAPER = 5
private const val K_WAVE = 6

/** مواصفات تصميم ويدجت واحد. */
private class Th(
    val solid: Int,
    val acc: Int,
    val ppc: Int,
    val radius: Float,
    val a: Int,
    val b: Int,
    val fg: Int = c(0xFFFFFFFF),
    val sub: Int = c(0xFFB5B0C2),
    val trk: Int = c(0x24FFFFFF),
    val btn: Int = c(0x1FFFFFFF),
    val circle: Boolean = false,
    val artR: Float = -1f,
    val bh: Float = 4f,
    val kind: Int = K_NORMAL,
    val grad: IntArray? = null,
    val gradPos: FloatArray? = null,
    val gradAngle: Float = 135f
)

private val THEMES: List<Th> = listOf(
    // 0 أورورا
    Th(c(0xFF16151C), c(0xFFA98BFF), c(0xFF12101A), 28f, c(0xFF7C4DFF), c(0xFFFF6EC7),
        grad = intArrayOf(c(0xFF2B1B52), c(0xFF14121F), c(0xFF14121F)), gradPos = floatArrayOf(0f, 0.7f, 1f)),
    // 1 فينيل
    Th(c(0xFF101214), c(0xFF35E0A1), c(0xFF06251A), 32f, c(0xFF2A2A2A), c(0xFF444444), circle = true, kind = K_VINYL),
    // 2 كبسولة
    Th(c(0xFF1D1A26), c(0xFFFFB86B), c(0xFF2A1800), -1f, c(0xFFFFB86B), c(0xFFFF5F6D), circle = true),
    // 3 مينيمال فاتح
    Th(c(0xFFF7F5F2), c(0xFF17151A), c(0xFFFFFFFF), 24f, c(0xFFE8D9C4), c(0xFFBFA58A),
        fg = c(0xFF17151A), sub = c(0xFF777777), trk = c(0xFFE3DFD9), btn = c(0xFFEBE7E1)),
    // 4 نيون
    Th(c(0xFF06080D), c(0xFF19E3FF), c(0xFF001A20), 26f, c(0xFF19E3FF), c(0xFF7A5CFF),
        fg = c(0xFFE8FBFF), sub = c(0xFF6FB6C9), trk = c(0x2619E3FF), btn = c(0x1A19E3FF), kind = K_NEON),
    // 5 غروب
    Th(c(0xFFFF7A45), c(0xFFFFFFFF), c(0xFFC21F55), 30f, c(0xFFFFD36B), c(0xFFFF7A45),
        sub = c(0xCCFFFFFF), trk = c(0x4DFFFFFF), btn = c(0x33FFFFFF),
        grad = intArrayOf(c(0xFFFF7A45), c(0xFFFF3D77), c(0xFF8A2BE2)), gradPos = floatArrayOf(0f, 0.6f, 1f), gradAngle = 120f),
    // 6 شريط منقّط
    Th(c(0xFF1A1A1A), c(0xFF00E5A8), c(0xFF00221A), 20f, c(0xFF00E5A8), c(0xFF007AD9), artR = 8f, bh = 6f, kind = K_DOT),
    // 7 ضبابي
    Th(c(0xFF111111), c(0xFFFFFFFF), c(0xFF111111), 30f, c(0xFF3B82F6), c(0xFF9333EA), btn = c(0x29FFFFFF), kind = K_BLUR),
    // 8 ورقي كلاسيكي
    Th(c(0xFFF1E7D3), c(0xFF8C4A2F), c(0xFFFFFFFF), 22f, c(0xFF8C4A2F), c(0xFFD49A5B),
        fg = c(0xFF2D2218), sub = c(0xFF7A6853), trk = c(0xFFDDCFB5), btn = c(0xFFE6D8BF), kind = K_PAPER),
    // 9 موجة
    Th(c(0xFF0F1220), c(0xFF8FA2FF), c(0xFF0F1220), 36f, c(0xFF4F46E5), c(0xFF22D3EE), btn = 0, circle = true, bh = 10f, kind = K_WAVE)
)

private const val I_PREV = "M6 6h2v12H6zM9.5 12 18 6v12z"
private const val I_NEXT = "M16 6h2v12h-2zM6 18V6l8.5 6z"
private const val I_PAUSE = "M6 5h4v14H6zM14 5h4v14h-4z"
private const val I_PLAY = "M7 4v16l13-8z"

private class St(
    val title: String,
    val artist: String,
    val playing: Boolean,
    val prog: Float,
    val pos: Long,
    val cover: Bitmap?,
    val alpha: Int
)

private fun lg(w: Float, h: Float, deg: Float, cols: IntArray, pos: FloatArray?): LinearGradient {
    val r = Math.toRadians(deg.toDouble())
    val dx = sin(r).toFloat()
    val dy = (-cos(r)).toFloat()
    val len = abs(w * dx) + abs(h * dy)
    val cx = w / 2f
    val cy = h / 2f
    return LinearGradient(cx - dx * len / 2f, cy - dy * len / 2f, cx + dx * len / 2f, cy + dy * len / 2f, cols, pos, Shader.TileMode.CLAMP)
}

/** يقصّ كل ما خارج الشكل (حواف ناعمة) داخل الطبقة الحالية. */
private fun cutOutside(cv: Canvas, rect: RectF, rad: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    val path = Path()
    path.addRoundRect(rect, rad, rad, Path.Direction.CW)
    path.fillType = Path.FillType.INVERSE_WINDING
    cv.drawPath(path, p)
}

private fun icon(cv: Canvas, d: String, cx: Float, cy: Float, size: Float, color: Int) {
    val path = PathParser.createPathFromPathData(d)
    val m = Matrix()
    val k = size / 24f
    m.setScale(k, k)
    m.postTranslate(cx - size / 2f, cy - size / 2f)
    path.transform(m)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    cv.drawPath(path, p)
}

private fun drawArt(cv: Canvas, th: Th, cover: Bitmap?, x: Float, y: Float, w: Float, h: Float, rad: Float, circle: Boolean, s: Float, angle: Float) {
    var ax = x
    var ay = y
    var aw = w
    var ah = h
    if (circle) {
        val sd = min(w, h)
        ax = x + (w - sd) / 2f
        ay = y + (h - sd) / 2f
        aw = sd
        ah = sd
    }
    val layer = cv.saveLayer(ax, ay, ax + aw, ay + ah, null)
    cv.translate(ax, ay)
    val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    cv.save()
    if (th.kind == K_VINYL) cv.rotate(angle, aw / 2f, ah / 2f)
    if (cover != null) {
        val bw = cover.width.toFloat()
        val bh = cover.height.toFloat()
        val sc = max(aw / bw, ah / bh)
        val sw = aw / sc
        val sh = ah / sc
        val src = Rect(((bw - sw) / 2f).toInt(), ((bh - sh) / 2f).toInt(), ((bw + sw) / 2f).toInt(), ((bh + sh) / 2f).toInt())
        cv.drawBitmap(cover, src, RectF(0f, 0f, aw, ah), p)
    } else if (th.kind == K_VINYL) {
        p.color = c(0xFF202020)
        cv.drawRect(0f, 0f, aw, ah, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = s
        p.color = c(0xFF333333)
        var r = aw * 0.48f
        while (r > aw * 0.2f) {
            cv.drawCircle(aw / 2f, ah / 2f, r, p)
            r -= aw * 0.06f
        }
        p.style = Paint.Style.FILL
    } else {
        p.shader = lg(aw, ah, 135f, intArrayOf(th.a, th.b), null)
        cv.drawRect(0f, 0f, aw, ah, p)
        p.shader = RadialGradient(aw * 0.3f, ah * 0.25f, max(aw, ah) * 0.5f, intArrayOf(c(0x66FFFFFF), 0), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, aw, ah, p)
        p.shader = null
    }
    cv.restore()
    cutOutside(cv, RectF(0f, 0f, aw, ah), if (circle) aw / 2f else rad)
    cv.restoreToCount(layer)
    if (th.kind == K_VINYL) {
        val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
        val ccx = ax + aw / 2f
        val ccy = ay + ah / 2f
        p2.color = c(0xFF0B0B0B)
        cv.drawCircle(ccx, ccy, aw * 0.17f + 3f * s, p2)
        p2.shader = lg(aw * 0.34f, aw * 0.34f, 135f, intArrayOf(th.acc, c(0xFF0FA36F)), null)
        cv.save()
        cv.translate(ccx - aw * 0.17f, ccy - aw * 0.17f)
        cv.drawCircle(aw * 0.17f, aw * 0.17f, aw * 0.17f, p2)
        cv.restore()
        p2.shader = null
        p2.color = c(0xFF0B0B0B)
        cv.drawCircle(ccx, ccy, aw * 0.035f, p2)
    }
}

private fun drawBar(cv: Canvas, th: Th, x0: Float, x1: Float, y: Float, prog: Float, s: Float) {
    val bh = th.bh * s
    val len = x1 - x0
    val fillX = x0 + len * prog
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    when (th.kind) {
        K_DOT -> {
            val dash = 3f * s
            val period = 6f * s
            var x = x0
            while (x + dash <= x1) {
                p.color = if (x + dash <= fillX) th.acc else th.trk
                cv.drawRoundRect(RectF(x, y - bh / 2f, x + dash, y + bh / 2f), s, s, p)
                x += period
            }
        }
        K_WAVE -> {
            val lw = 2f * s
            val period = 5f * s
            var x = x0
            var i = 0
            while (x + lw <= x1) {
                val hh = bh * (0.45f + 0.55f * abs(sin(i * 0.9f)))
                p.color = if (x < fillX) th.acc else (th.acc and 0x00FFFFFF) or (0x40 shl 24)
                cv.drawRoundRect(RectF(x, y - hh / 2f, x + lw, y + hh / 2f), s, s, p)
                x += period
                i++
            }
        }
        else -> {
            p.color = th.trk
            cv.drawRoundRect(RectF(x0, y - bh / 2f, x1, y + bh / 2f), bh / 2f, bh / 2f, p)
            p.color = th.acc
            if (th.kind == K_NEON) p.setShadowLayer(5f * s, 0f, 0f, th.acc)
            cv.drawRoundRect(RectF(x0, y - bh / 2f, max(fillX, x0 + bh), y + bh / 2f), bh / 2f, bh / 2f, p)
            p.clearShadowLayer()
        }
    }
    // المقبض
    val lo = x0 + 7f * s
    val hi = x1 - 7f * s
    val tx = if (hi > lo) fillX.coerceIn(lo, hi) else fillX
    p.color = (th.acc and 0x00FFFFFF) or (0x44 shl 24)
    cv.drawCircle(tx, y, 10.5f * s, p)
    p.color = th.acc
    cv.drawCircle(tx, y, 6.5f * s, p)
    p.color = th.ppc
    cv.drawCircle(tx, y, 2.2f * s, p)
}

private fun drawFace(th: Th, big: Boolean, wDp: Float, hDp: Float, s: Float, st: St): Bitmap {
    val W = (wDp * s).toInt()
    val H = (hDp * s).toInt()
    val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    val rDp = if (th.radius < 0) hDp / 2f else min(th.radius, hDp / 2f)
    val R = rDp * s
    val pad = 12f * s
    val full = RectF(0f, 0f, W.toFloat(), H.toFloat())

    // ===== الخلفية =====
    val bg = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val bc = Canvas(bg)
    val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    if (th.kind == K_BLUR) {
        if (st.cover != null) {
            val tiny = Bitmap.createScaledBitmap(st.cover, 20, 20, true)
            bc.drawBitmap(tiny, null, full, bp)
            bp.color = c(0x99000000)
            bc.drawRect(full, bp)
        } else {
            bp.shader = lg(W.toFloat(), H.toFloat(), 135f, intArrayOf(c(0xFF3B82F6), c(0xFF9333EA), c(0xFFF43F5E)), null)
            bc.drawRect(full, bp)
            bp.shader = null
            bp.color = c(0x73000000)
            bc.drawRect(full, bp)
        }
    } else if (th.grad != null) {
        bp.shader = lg(W.toFloat(), H.toFloat(), th.gradAngle, th.grad, th.gradPos)
        bc.drawRect(full, bp)
    } else {
        bp.color = th.solid
        bc.drawRect(full, bp)
    }
    cutOutside(bc, full, R)
    val cp = Paint(Paint.FILTER_BITMAP_FLAG)
    cp.alpha = st.alpha
    cv.drawBitmap(bg, 0f, 0f, cp)
    bg.recycle()

    if (th.kind == K_NEON) {
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.style = Paint.Style.STROKE
        sp.strokeWidth = 5f * s
        sp.color = c(0x4019E3FF)
        sp.maskFilter = BlurMaskFilter(8f * s, BlurMaskFilter.Blur.NORMAL)
        cv.drawRoundRect(RectF(3f * s, 3f * s, W - 3f * s, H - 3f * s), R, R, sp)
        sp.maskFilter = null
        sp.strokeWidth = 1.5f * s
        sp.color = c(0x8C19E3FF)
        cv.drawRoundRect(RectF(1f * s, 1f * s, W - 1f * s, H - 1f * s), R, R, sp)
    }

    // ===== الهندسة =====
    val artL: Float
    val artT: Float
    val artW: Float
    val artH: Float
    val textL: Float
    val textR: Float
    val barL: Float
    val barR: Float
    val barY: Float
    val titleY: Float
    val artistY: Float
    val prevX: Float
    val playX: Float
    val nextX: Float
    val ctlY: Float
    if (!big) {
        val sz = min(64f, hDp - 16f) * s
        artL = pad; artW = sz; artH = sz; artT = (H - sz) / 2f
        textL = (12f + 64f + 12f) * s
        textR = (wDp - 12f - 132f - 12f) * s
        barL = textL; barR = textR
        barY = H / 2f + 20f * s
        titleY = H / 2f - 8f * s
        artistY = H / 2f + 8f * s
        ctlY = H / 2f
        nextX = (wDp - 12f - 19f) * s
        playX = (wDp - 12f - 38f - 6f - 22f) * s
        prevX = (wDp - 12f - 38f - 6f - 44f - 6f - 19f) * s
    } else {
        val free = wDp - 24f - 12f
        val aw = 0.42f * free
        artL = pad; artT = pad; artW = aw * s; artH = H - 2f * pad
        textL = (12f + aw + 12f) * s
        textR = (wDp - 12f) * s
        barL = textL; barR = textR
        barY = (hDp - 5f) / 2f * s
        titleY = pad + 18f * s
        artistY = pad + 38f * s
        ctlY = (hDp - 12f - 22f) * s
        prevX = textL + 19f * s
        nextX = textR - 19f * s
        playX = (textL + textR) / 2f
    }

    // ===== الغلاف =====
    val artRad = when {
        th.artR >= 0f -> th.artR * s
        th.radius < 0f -> min(artW, artH) / 2f
        else -> max(0f, (rDp - 12f) * s)
    }
    val angle = (st.pos / 1000f * 30f) % 360f
    drawArt(cv, th, st.cover, artL, artT, artW, artH, min(artRad, min(artW, artH) / 2f), th.circle, s, angle)

    // ===== النصوص =====
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    val paper = th.kind == K_PAPER
    tp.typeface = if (paper) Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC) else Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    tp.textSize = (if (big) 17f else 15f) * s
    tp.color = th.fg
    val avail = max(10f, textR - textL)
    cv.drawText(TextUtils.ellipsize(st.title, tp, avail, TextUtils.TruncateAt.END).toString(), textL, titleY, tp)
    tp.typeface = if (paper) Typeface.create(Typeface.SERIF, Typeface.NORMAL) else Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    tp.textSize = (if (big) 13.5f else 12.5f) * s
    tp.color = th.sub
    cv.drawText(TextUtils.ellipsize(st.artist, tp, avail, TextUtils.TruncateAt.END).toString(), textL, artistY, tp)

    // ===== شريط التقدّم + المقبض =====
    drawBar(cv, th, barL, barR, barY, st.prog, s)

    // ===== الأزرار =====
    val bp2 = Paint(Paint.ANTI_ALIAS_FLAG)
    if (th.btn != 0) {
        bp2.color = th.btn
        cv.drawCircle(prevX, ctlY, 19f * s, bp2)
        cv.drawCircle(nextX, ctlY, 19f * s, bp2)
    }
    bp2.color = th.acc
    if (th.kind == K_NEON) bp2.setShadowLayer(7f * s, 0f, 0f, th.acc)
    cv.drawCircle(playX, ctlY, 22f * s, bp2)
    bp2.clearShadowLayer()
    icon(cv, I_PREV, prevX, ctlY, 20f * s, th.fg)
    icon(cv, I_NEXT, nextX, ctlY, 20f * s, th.fg)
    icon(cv, if (st.playing) I_PAUSE else I_PLAY, playX, ctlY, 20f * s, th.ppc)
    return out
}

/** مستقبل ويدجت لكل تصميم وحجم. */
open class ThemedWidget(private val th: Int, private val big: Boolean) : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) PlayerWidget.render(ctx, m, id, th, big)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, m: AppWidgetManager, id: Int, newOptions: android.os.Bundle?) {
        PlayerWidget.render(ctx, m, id, th, big)
    }
}

object PlayerWidget {
    private var cKey: String? = null
    private var cBmp: Bitmap? = null

    private val reg: List<Triple<Class<out AppWidgetProvider>, Int, Boolean>> = WIDGET_REGISTRY

    fun push(ctx: Context, c: MediaController?) {
        runCatching {
            if (c != null) {
                val dur = c.duration
                val pos = c.currentPosition
                ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE).edit()
                    .putString("title", c.mediaMetadata.title?.toString() ?: "")
                    .putString("artist", c.mediaMetadata.artist?.toString() ?: "")
                    .putString("id", c.currentMediaItem?.mediaId ?: "")
                    .putInt("prog", if (dur > 0) (pos * 1000 / dur).toInt().coerceIn(0, 1000) else 0)
                    .putLong("pos", pos)
                    .putBoolean("playing", c.isPlaying).apply()
            }
            refreshAll(ctx)
        }
    }

    /** تحديث التقدّم (كل ثانيتين أثناء التشغيل). */
    fun pushProgress(ctx: Context, pos: Long, dur: Long) {
        runCatching {
            if (dur <= 0) return
            val prog = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
            ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE).edit().putInt("prog", prog).putLong("pos", pos).apply()
            refreshAll(ctx)
        }
    }

    private fun refreshAll(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        for ((cls, th, big) in reg) {
            val ids = m.getAppWidgetIds(ComponentName(ctx, cls))
            for (id in ids) render(ctx, m, id, th, big)
        }
    }

    private fun cover(ctx: Context, id: String): Bitmap? {
        if (id.isBlank()) return null
        val f = File(ctx.cacheDir, "covers/$id.jpg")
        if (!f.exists()) return null
        val key = f.path + f.lastModified()
        if (key == cKey) return cBmp
        val b = runCatching { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 }) }.getOrNull()
        cKey = key
        cBmp = b
        return b
    }

    fun render(ctx: Context, m: AppWidgetManager, id: Int, th: Int, big: Boolean) {
        runCatching {
            val o = m.getAppWidgetOptions(id)
            val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            var w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            var h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            if (land) {
                w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, w)
            } else {
                h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, h)
            }
            if (w <= 0) w = 320
            if (h <= 0) h = if (big) 176 else 88
            val wDp = max(200, w).toFloat()
            val hDp = max(56, h).toFloat()
            val s = min(ctx.resources.displayMetrics.density, 900f / wDp)

            val p = ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE)
            val st = St(
                p.getString("title", "")?.ifBlank { null } ?: "T Music",
                p.getString("artist", "") ?: "",
                p.getBoolean("playing", false),
                p.getInt("prog", 0) / 1000f,
                p.getLong("pos", 0L),
                cover(ctx, p.getString("id", "") ?: ""),
                p.getInt("alpha", 255).coerceIn(40, 255)
            )
            val bmp = drawFace(THEMES[th], big, wDp, hDp, s, st)
            val rv = RemoteViews(ctx.packageName, if (big) R.layout.wface_x2 else R.layout.wface_x1)
            rv.setImageViewBitmap(R.id.w_face, bmp)
            rv.setOnClickPendingIntent(R.id.w_prev, key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
            rv.setOnClickPendingIntent(R.id.w_play, key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            rv.setOnClickPendingIntent(R.id.w_next, key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT))
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            rv.setOnClickPendingIntent(R.id.w_root, open)
            val zones = intArrayOf(R.id.z0, R.id.z1, R.id.z2, R.id.z3, R.id.z4, R.id.z5, R.id.z6, R.id.z7, R.id.z8, R.id.z9)
            for (i in zones.indices) rv.setOnClickPendingIntent(zones[i], seekPi(ctx, i))
            m.updateAppWidget(id, rv)
        }
    }

    private fun seekPi(ctx: Context, i: Int): PendingIntent {
        val it = Intent(ctx, PlaybackService::class.java).setAction("com.tmusic.app.SEEK").putExtra("f", (i + 0.5f) / 10f)
        return PendingIntent.getService(ctx, 2000 + i, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun key(ctx: Context, code: Int): PendingIntent {
        val i = Intent(ctx, PlaybackService::class.java).setAction(Intent.ACTION_MEDIA_BUTTON)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, code))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(ctx, code, i, flags)
        else PendingIntent.getService(ctx, code, i, flags)
    }
}
