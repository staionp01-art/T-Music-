package com.tmusic.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * منبّه احتياطي يوقظ التطبيق كل ~ساعة لفحص التحديث، لأن WorkManager وحده قد يؤجّله النظام (Doze / توفير البطارية).
 * يُعاد جدولته بعد إعادة تشغيل الهاتف وبعد تحديث التطبيق.
 */
object UpdateAlarm {
    private const val EVERY_MS = 60L * 60_000L

    private fun pi(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(ctx, 91, Intent(ctx, UpdateAlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(ctx: Context) {
        runCatching {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // غير دقيق عمدًا (لا يحتاج إذن SCHEDULE_EXACT_ALARM) ويعمل أثناء Doze
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + EVERY_MS, pi(ctx))
        }
    }

    fun cancel(ctx: Context) {
        runCatching { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(ctx)) }
    }
}

class UpdateAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val app = ctx.applicationContext
        AppPrefs.init(app)
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            runCatching { Updater.schedule(app) }
        }
        if (!AppPrefs.autoUpdate) return
        // أعد جدولة المنبّه التالي ثم افحص عبر WorkManager (يحتاج إنترنت)
        UpdateAlarm.schedule(app)
        runCatching {
            val req = OneTimeWorkRequestBuilder<UpdateWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
            WorkManager.getInstance(app).enqueueUniqueWork("tm_update_once", ExistingWorkPolicy.REPLACE, req)
        }
    }
}
