package com.tmusic.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class SurahInfo(val number: Int, val name: String, val ayahs: Int)
data class Reciter(val name: String, val folder: String)

/** بيانات القرآن: أسماء السور وأعداد الآيات، القرّاء، وتحميل النص مع تخزين محلي. */
object Quran {
    private val names = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
        "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
        "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
        "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
        "المسد", "الإخلاص", "الفلق", "الناس"
    )

    private val counts = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
        123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
        34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
        60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
        28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
        15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
        5, 4, 5, 6
    )

    val surahs: List<SurahInfo> = names.indices.map { SurahInfo(it + 1, names[it], counts[it]) }

    val reciters = listOf(
        Reciter("مشاري العفاسي", "Alafasy_128kbps"),
        Reciter("عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_192kbps"),
        Reciter("سعود الشريم", "Saood_ash-Shuraym_128kbps"),
        Reciter("محمود الحصري", "Husary_128kbps"),
        Reciter("عبد الباسط عبد الصمد", "Abdul_Basit_Murattal_192kbps"),
        Reciter("محمد صديق المنشاوي", "Minshawy_Murattal_128kbps")
    )

    /** كل السور تبدأ بالبسملة عدا الفاتحة (هي آية فيها) والتوبة (بلا بسملة). */
    fun hasBasmala(surah: Int) = surah != 1 && surah != 9

    fun audioUrl(folder: String, surah: Int, ayah: Int): String =
        String.format(Locale.US, "https://everyayah.com/data/%s/%03d%03d.mp3", folder, surah, ayah)

    fun digits(n: Int): String = n.toString().map { '٠' + (it - '0') }.joinToString("")

    fun normalize(s: String): String = s.trim()
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ة', 'ه').replace('ى', 'ي')

    fun search(q: String): List<SurahInfo> {
        val k = normalize(q).removePrefix("سورة").trim()
        if (k.isEmpty()) return emptyList()
        return surahs.filter { normalize(it.name).contains(k) || it.number.toString() == k }
    }

    /** يحمّل آيات السورة؛ من الذاكرة المحلية إن وُجدت وإلا من الإنترنت ثم يحفظها. */
    suspend fun load(ctx: Context, surah: Int): List<String>? = withContext(Dispatchers.IO) {
        val expected = counts[surah - 1]
        val f = File(File(ctx.filesDir, "quran").apply { mkdirs() }, "$surah.txt")
        if (f.exists()) {
            val cached = f.readLines()
            if (cached.size == expected) return@withContext cached
        }
        try {
            val conn = URL("https://api.alquran.cloud/v1/surah/$surah/quran-uthmani").openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            conn.disconnect()
            val arr = JSONObject(body).getJSONObject("data").getJSONArray("ayahs")
            val out = (0 until arr.length()).map { i ->
                val t = arr.getJSONObject(i).getString("text").replace("\n", " ").trim()
                if (i == 0 && hasBasmala(surah)) stripBasmala(t) else t
            }
            if (out.size == expected) { f.writeText(out.joinToString("\n")); out } else null
        } catch (e: Exception) {
            null
        }
    }

    /** النص العثماني يضع البسملة في أول آية؛ نفصلها لنعرضها في الترويسة. */
    private fun stripBasmala(t: String): String {
        val words = t.split(" ")
        if (words.size <= 4) return t
        val first = words[0].filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
        return if (first == "بسم") words.drop(4).joinToString(" ") else t
    }
}
