package com.tmusic.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** يحمّل أغلفة الألبومات بطريقة تعمل على كل إصدارات أندرويد، مع ذاكرة مؤقتة. */
object Art {
    private val cache = object : LruCache<Long, Bitmap>(32 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }
    private val missing = HashSet<Long>()
    fun forget(id: Long) { missing.remove(id) }
    private val remoteCache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    /** صورة من رابط (مصغّرات يوتيوب مثلًا) مع ذاكرة مؤقتة. */
    suspend fun remote(url: String): Bitmap? {
        remoteCache.get(url)?.let { return it }
        val b = withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000
                try { c.inputStream.use { BitmapFactory.decodeStream(it) } } finally { c.disconnect() }
            } catch (e: Exception) { null }
        }
        if (b != null) remoteCache.put(url, b)
        return b
    }

    private fun diskFile(ctx: Context, id: Long) = java.io.File(ctx.cacheDir, "covers/$id.jpg")
    fun putCover(ctx: Context, id: Long, b: Bitmap) {
        cache.put(id, b); missing.remove(id)
        runCatching { val f = diskFile(ctx, id); f.parentFile?.mkdirs(); f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) } }
        runCatching { if (ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE).getString("id", "") == id.toString()) PlayerWidget.push(ctx, null) }
    }

    fun peek(song: Song): Bitmap? = cache.get(song.id)

    /** الغلاف المضمَّن داخل ملف الصوت نفسه (ID3) — يعمل لكل الإصدارات ولأي ملف منزَّل. */
    private fun embedded(ctx: Context, song: Song): Bitmap? {
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, song.uri)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }

    suspend fun get(ctx: Context, song: Song): Bitmap? {
        cache.get(song.id)?.let { return it }
        if (song.id in missing) return null
        val bmp = withContext(Dispatchers.IO) {
            try {
                val df = diskFile(ctx, song.id)
                if (song.artUrl == null && df.exists()) BitmapFactory.decodeFile(df.path)?.let { return@withContext it }
                if (song.artUrl != null) {
                    val c = URL(song.artUrl).openConnection() as HttpURLConnection
                    c.connectTimeout = 10000; c.readTimeout = 15000
                    try { c.inputStream.use { BitmapFactory.decodeStream(it) } } finally { c.disconnect() }
                }
                else if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(song.uri, Size(480, 480), null)
                else ctx.contentResolver.openInputStream(song.art)?.use { BitmapFactory.decodeStream(it) }
            } catch (e: Exception) { null }
        }
        val finalBmp = bmp ?: if (song.artUrl == null) withContext(Dispatchers.IO) { embedded(ctx, song) } else null
        if (finalBmp != null) {
            cache.put(song.id, finalBmp)
            withContext(Dispatchers.IO) {
                runCatching { val f = diskFile(ctx, song.id); if (!f.exists()) { f.parentFile?.mkdirs(); f.outputStream().use { finalBmp.compress(Bitmap.CompressFormat.JPEG, 85, it) } } }
                runCatching { if (ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE).getString("id", "") == song.id.toString()) PlayerWidget.push(ctx, null) }
            }
        } else missing.add(song.id)
        return finalBmp
    }
}
