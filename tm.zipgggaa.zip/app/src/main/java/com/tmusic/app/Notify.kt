package com.tmusic.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** إشعارات التطبيق: التحديثات والتنزيلات. القنوات تُنشأ عند أول إشعار. */
object Notify {
    const val CH_UPDATES = "tm_updates"
    const val CH_DOWNLOADS = "tm_downloads"
    /** قناة عالية الأهمية لإشعار «تحديث جديد»: تظهر منبثقة وعلى شاشة القفل حتى والتطبيق مغلق. */
    const val CH_UPDATE_ALERT = "tm_update_alert"
    const val ID_UPDATE = 7002

    private fun mgr(ctx: Context): NotificationManager {
        val m = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (m.getNotificationChannel(CH_UPDATES) == null)
                m.createNotificationChannel(NotificationChannel(CH_UPDATES, "التحديثات", NotificationManager.IMPORTANCE_DEFAULT))
            if (m.getNotificationChannel(CH_UPDATE_ALERT) == null)
                m.createNotificationChannel(NotificationChannel(CH_UPDATE_ALERT, "تنبيه التحديث الجديد", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                    description = "يخبرك بصدور إصدار جديد حتى لو كان التطبيق مغلقًا"
                })
            if (m.getNotificationChannel(CH_DOWNLOADS) == null)
                m.createNotificationChannel(NotificationChannel(CH_DOWNLOADS, "التنزيلات", NotificationManager.IMPORTANCE_LOW))
        }
        return m
    }

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** progress: 0..100 لشريط تقدّم، أو indeterminate لشريط غير محدد. الضغط على الإشعار يفتح التطبيق. */
    fun post(
        ctx: Context, id: Int, channel: String, title: String, text: String, icon: Int,
        ongoing: Boolean = false, progress: Int? = null, indeterminate: Boolean = false,
        subText: String? = null, actionText: String? = null, actionIntent: PendingIntent? = null,
        alert: Boolean = false
    ) {
        runCatching {
            val app = ctx.applicationContext
            val b = NotificationCompat.Builder(app, channel)
                .setSmallIcon(icon).setContentTitle(title).setContentText(text)
                .setContentIntent(openApp(app)).setAutoCancel(!ongoing).setOngoing(ongoing).setOnlyAlertOnce(true)
                .setColor(0xFFF5F2EA.toInt())
            if (alert) b.setPriority(NotificationCompat.PRIORITY_HIGH).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION).setWhen(System.currentTimeMillis()).setShowWhen(true)
            if (subText != null) b.setSubText(subText)
            if (actionText != null && actionIntent != null) b.addAction(0, actionText, actionIntent)
            if (progress != null || indeterminate) b.setProgress(100, progress ?: 0, indeterminate)
            mgr(app).notify(id, b.build())
        }
    }

    fun clear(ctx: Context, id: Int) { runCatching { mgr(ctx.applicationContext).cancel(id) } }
}
