package com.tmusic.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** قائمة المفضلة: الأحدث أولًا. أغاني الإنترنت تُحفظ بياناتها داخل القائمة نفسها. */
object Favorites {
    val ids = mutableStateListOf<Long>()
    private val meta = HashMap<Long, Song>()
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences("tm_favs", Context.MODE_PRIVATE)
        runCatching {
            val a = JSONArray(prefs!!.getString("favs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.getLong("id")
                ids.add(id)
                val url = o.optString("url")
                if (url.isNotBlank()) meta[id] = Song(
                    id, o.optString("t"), o.optString("a"), "", 0L, o.optLong("d"),
                    remoteUrl = url, artUrl = o.optString("art").ifBlank { null }, downloadUrl = o.optString("dl").ifBlank { null }
                )
            }
        }
    }

    private fun save() {
        val a = JSONArray()
        ids.forEach { id ->
            val o = JSONObject().put("id", id)
            meta[id]?.let { s ->
                o.put("t", s.title).put("a", s.artist).put("d", s.duration)
                    .put("url", s.remoteUrl ?: "").put("art", s.artUrl ?: "").put("dl", s.downloadUrl ?: "")
            }
            a.put(o)
        }
        prefs?.edit()?.putString("favs", a.toString())?.apply()
    }

    fun has(id: Long): Boolean = id in ids

    /** يضيف أو يزيل مباشرة. يعيد true إن أُضيفت الآن. */
    fun toggle(s: Song): Boolean {
        return if (s.id in ids) {
            ids.remove(s.id); meta.remove(s.id); save(); false
        } else {
            ids.add(0, s.id)
            if (s.remoteUrl != null) meta[s.id] = s
            save(); true
        }
    }

    fun songs(byId: Map<Long, Song>): List<Song> = ids.mapNotNull { byId[it] ?: meta[it] }
}

/** زر القلب: يضغط فتُضاف الأغنية إلى المفضلة فورًا، ويضغط ثانية فتُزال. */
@Composable
fun HeartButton(song: Song, modifier: Modifier = Modifier, size: Dp = 28.dp, off: Color = Color.White) {
    val on = Favorites.has(song.id)
    val haptic = LocalHapticFeedback.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    IconButton(
        onClick = {
            Favorites.toggle(song)
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            scope.launch { scale.snapTo(0.6f); scale.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 400f)) }
        },
        modifier = modifier
    ) {
        Icon(
            if (on) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (on) "إزالة من المفضلة" else "إضافة إلى المفضلة",
            Modifier.size(size).graphicsLayer { scaleX = scale.value; scaleY = scale.value },
            tint = if (on) Color(0xFFFF5C8A) else off
        )
    }
}

@Composable
fun FavoritesTab(byId: Map<Long, Song>, ui: PlayerUi) {
    val songs = Favorites.songs(byId)
    if (songs.isEmpty()) {
        EmptyState(Icons.Rounded.FavoriteBorder, "لا توجد مفضلة بعد", "اضغط القلب في شاشة التشغيل أو في قائمة الأغنية لتُضاف هنا مباشرة.")
        return
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button({ ui.play(songs, 0, false) }) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("تشغيل") }
            FilledTonalButton({ ui.play(songs, 0, true) }) { Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("عشوائي") }
            Text("${songs.size} أغنية", color = TM.Muted, fontSize = 12.sp)
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(songs, i) }
            }
        }
    }
}
