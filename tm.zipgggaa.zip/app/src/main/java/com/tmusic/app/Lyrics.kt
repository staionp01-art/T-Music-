package com.tmusic.app

import android.content.Context
import java.io.File

data class LyricLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

internal val TS = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

/** يقرأ تنسيق LRC المتزامن، وإن لم تكن فيه أوقات يعرض النص كما هو. */
fun parseLyrics(raw: String): Lyrics {
    val timed = mutableListOf<LyricLine>()
    val plain = mutableListOf<LyricLine>()
    for (line in raw.replace("\r", "").lines()) {
        val stamps = TS.findAll(line).toList()
        val text = TS.replace(line, "").trim()
        val t = line.trim()
        if (stamps.isNotEmpty()) {
            stamps.forEach { m ->
                val f = m.groupValues[3]
                val ms = when (f.length) { 0 -> 0; 1 -> f.toInt() * 100; 2 -> f.toInt() * 10; else -> f.take(3).toInt() }
                timed += LyricLine(
                    m.groupValues[1].toLong() * 60_000 + m.groupValues[2].toLong() * 1000 + ms,
                    text.ifEmpty { "♪" }
                )
            }
        } else if (!(t.startsWith("[") && t.endsWith("]") && t.contains(":"))) {
            plain += LyricLine(0, t)
        }
    }
    return if (timed.isNotEmpty()) Lyrics(timed.sortedBy { it.timeMs }, true)
    else Lyrics(plain.dropWhile { it.text.isEmpty() }, false)
}

object LyricsStore {
    private fun file(ctx: Context, id: Long) =
        File(File(ctx.filesDir, "lyrics").apply { mkdirs() }, "$id.txt")

    fun load(ctx: Context, id: Long): Lyrics? =
        file(ctx, id).takeIf { it.exists() }?.readText()?.let(::parseLyrics)?.takeIf { it.lines.isNotEmpty() }

    fun save(ctx: Context, id: Long, raw: String) = file(ctx, id).writeText(raw)
    fun delete(ctx: Context, id: Long) { file(ctx, id).delete() }
}
