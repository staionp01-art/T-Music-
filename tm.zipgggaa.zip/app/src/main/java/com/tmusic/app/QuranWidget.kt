package com.tmusic.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** ويدجت القرآن: آخر موضع وزر استئناف. */
class QuranWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        val rv = build(ctx)
        for (id in ids) m.updateAppWidget(id, rv)
    }

    companion object {
        fun push(ctx: Context) {
            runCatching {
                val m = AppWidgetManager.getInstance(ctx)
                val ids = m.getAppWidgetIds(ComponentName(ctx, QuranWidget::class.java))
                if (ids.isNotEmpty()) m.updateAppWidget(ids, build(ctx))
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val wp = ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE)
            val last = ctx.getSharedPreferences("tm", Context.MODE_PRIVATE).getString("lastq", null)?.split(":")
            val s = last?.getOrNull(0)?.toIntOrNull()
            val a = last?.getOrNull(1)?.toIntOrNull()
            val rv = RemoteViews(ctx.packageName, R.layout.widget_quran)
            val radius = listOf(R.drawable.widget_bg_r8, R.drawable.widget_bg_r22, R.drawable.widget_bg_r40)[wp.getInt("radius", 1).coerceIn(0, 2)]
            rv.setImageViewResource(R.id.w_bg, radius)
            rv.setInt(R.id.w_bg, "setColorFilter", 0xFF0F6E56.toInt())
            rv.setInt(R.id.w_bg, "setImageAlpha", wp.getInt("alpha", 255).coerceIn(40, 255))
            val intent = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (s != null && a != null) {
                rv.setTextViewText(R.id.q_surah, "سورة " + (Quran.surahs.getOrNull(s - 1)?.name ?: ""))
                rv.setTextViewText(R.id.q_ayah, "الآية " + Quran.digits(a))
                intent.putExtra("resume_q", "$s:$a")
            } else {
                rv.setTextViewText(R.id.q_surah, "القرآن الكريم")
                rv.setTextViewText(R.id.q_ayah, "لم تبدأ الاستماع بعد")
            }
            val pi = PendingIntent.getActivity(ctx, 77, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            rv.setOnClickPendingIntent(R.id.q_resume, pi)
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            return rv
        }
    }
}
