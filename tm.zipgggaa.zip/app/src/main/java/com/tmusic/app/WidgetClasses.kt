package com.tmusic.app

import android.appwidget.AppWidgetProvider

class WAurora1 : ThemedWidget(0, false)
class WAurora2 : ThemedWidget(0, true)
class WVinyl1 : ThemedWidget(1, false)
class WVinyl2 : ThemedWidget(1, true)
class WCapsule1 : ThemedWidget(2, false)
class WCapsule2 : ThemedWidget(2, true)
class WLight1 : ThemedWidget(3, false)
class WLight2 : ThemedWidget(3, true)
class WNeon1 : ThemedWidget(4, false)
class WNeon2 : ThemedWidget(4, true)
class WSunset1 : ThemedWidget(5, false)
class WSunset2 : ThemedWidget(5, true)
class WDotted1 : ThemedWidget(6, false)
class WDotted2 : ThemedWidget(6, true)
class WBlur1 : ThemedWidget(7, false)
class WBlur2 : ThemedWidget(7, true)
class WPaper1 : ThemedWidget(8, false)
class WPaper2 : ThemedWidget(8, true)
class WWave1 : ThemedWidget(9, false)
class WWave2 : ThemedWidget(9, true)

val WIDGET_REGISTRY: List<Triple<Class<out AppWidgetProvider>, Int, Boolean>> = listOf(
    Triple(WAurora1::class.java, 0, false),
    Triple(WAurora2::class.java, 0, true),
    Triple(WVinyl1::class.java, 1, false),
    Triple(WVinyl2::class.java, 1, true),
    Triple(WCapsule1::class.java, 2, false),
    Triple(WCapsule2::class.java, 2, true),
    Triple(WLight1::class.java, 3, false),
    Triple(WLight2::class.java, 3, true),
    Triple(WNeon1::class.java, 4, false),
    Triple(WNeon2::class.java, 4, true),
    Triple(WSunset1::class.java, 5, false),
    Triple(WSunset2::class.java, 5, true),
    Triple(WDotted1::class.java, 6, false),
    Triple(WDotted2::class.java, 6, true),
    Triple(WBlur1::class.java, 7, false),
    Triple(WBlur2::class.java, 7, true),
    Triple(WPaper1::class.java, 8, false),
    Triple(WPaper2::class.java, 8, true),
    Triple(WWave1::class.java, 9, false),
    Triple(WWave2::class.java, 9, true)
)
