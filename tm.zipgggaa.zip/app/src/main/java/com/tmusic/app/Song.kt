package com.tmusic.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Song(
    val id: Long, val title: String, val artist: String,
    val album: String, val albumId: Long, val duration: Long,
    val remoteUrl: String? = null, val artUrl: String? = null,   // لأغاني الإنترنت فقط
    val downloadUrl: String? = null,                             // رابط التنزيل المرخّص إن وُجد
    val added: Long = 0L, val path: String = ""
) {
    val uri: Uri get() = remoteUrl?.let { Uri.parse(it) } ?: ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val art: Uri get() = artUrl?.let { Uri.parse(it) } ?: ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
}

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DATA
    )
    val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>30000"
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols, sel, null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { c ->
        while (c.moveToNext()) out += Song(
            c.getLong(0), c.getString(1) ?: "بدون عنوان", (c.getString(2) ?: "").takeIf { it.isNotBlank() && it != "<unknown>" } ?: "فنان غير معروف",
            c.getString(3) ?: "", c.getLong(4), c.getLong(5),
            added = c.getLong(6), path = c.getString(7) ?: ""
        )
    }
    val meta = ctx.applicationContext.getSharedPreferences("tm_meta", Context.MODE_PRIVATE)
    return out.map { s -> meta.getString("a${s.id}", null)?.let { s.copy(artist = it) } ?: s }
}

data class Album(val id: Long, val name: String, val artist: String, val songs: List<Song>)
data class Artist(val name: String, val songs: List<Song>)

fun List<Song>.toAlbums(): List<Album> = groupBy { it.albumId }.map { (id, s) ->
    val artists = s.map { it.artist }.distinct()
    Album(
        id, s.first().album.ifBlank { "ألبوم غير معروف" },
        if (artists.size == 1) artists[0] else "فنانون مختلفون", s
    )
}.sortedBy { it.name.lowercase() }

fun List<Song>.toArtists(): List<Artist> =
    groupBy { it.artist }.map { (n, s) -> Artist(n, s) }.sortedByDescending { it.songs.size }

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}
