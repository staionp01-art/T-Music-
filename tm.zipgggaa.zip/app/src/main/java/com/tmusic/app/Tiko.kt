package com.tmusic.app

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/* ───────────────────────── تيكو: شخصية التطبيق ─────────────────────────
 * مرشد + مساعد ذكي. يُرسم برمجيًا (Canvas) ليتفاعل: يرمش، يفرح، يحب، يدوخ، ينام، ويرقص.
 */

enum class TikoMood { Idle, Happy, Love, Wow, Dizzy, Sleep, Listen }

/** إعدادات تيكو الخفيفة (الجولة التعريفية). */
object TikoPrefs {
    var replay by mutableStateOf(false)
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("tm_tiko", Context.MODE_PRIVATE)
    fun tourDone(ctx: Context) = sp(ctx).getBoolean("tour_done", false)
    fun setTourDone(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("tour_done", v).apply() }
}

private val TikoSignal = Color(0xFFF5F2EA)

/** رسم تيكو. `mood` يحدد تعبير العينين، و`dance` يجعله يقفز ويدور. */
@Composable
fun TikoView(mood: TikoMood, modifier: Modifier = Modifier, dance: Boolean = false) {
    val inf = rememberInfiniteTransition(label = "tiko")
    val fast = dance || mood == TikoMood.Dizzy
    val spin by inf.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(if (fast) 900 else 3400, easing = LinearEasing)), label = "spin"
    )
    // نبض إيقاعي تقريبي (ليس تحليلًا حقيقيًا للصوت): يعطي إحساس الإيقاع أثناء التشغيل
    val pulse by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val bob by inf.animateFloat(
        -1f, 1f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    val blink = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay((2200..5200).random().toLong())
            blink.animateTo(0.06f, tween(80)); blink.animateTo(1f, tween(110))
        }
    }

    Canvas(modifier) {
        val s = size.minDimension
        val sig = TikoSignal
        val asleep = mood == TikoMood.Sleep
        val listen = mood == TikoMood.Listen
        // ظل تحت الجسم
        drawOval(Color.Black.copy(alpha = 0.45f), Offset(s * 0.26f, s * 0.86f), Size(s * 0.48f, s * 0.07f))

        val hop = if (dance) -abs(sin(spin * 2f)) * s * 0.09f else 0f
        val dy = bob * s * 0.012f + hop
        val tilt = when { dance -> sin(spin) * 9f; mood == TikoMood.Dizzy -> sin(spin) * 7f; else -> 0f }

        translate(top = dy) {
            rotate(tilt, Offset(s / 2f, s * 0.55f)) {
                // الحلقات المتوهجة على الجانبين
                val ringH = s * 0.34f * (1f + if (listen) 0.12f * pulse else 0f)
                for (side in listOf(-1f, 1f)) {
                    val cx = s * 0.5f + side * s * 0.40f
                    val wob = if (asleep) 0.55f else abs(cos(spin + if (side > 0) 0f else 1.2f))
                    val w = s * (0.025f + 0.07f * wob) * (1f + if (listen) 0.25f * pulse else 0f)
                    val a = if (asleep) 0.35f else 1f
                    val cy = s * 0.55f
                    drawOval(sig.copy(alpha = 0.18f * a), Offset(cx - w / 2 - s * 0.012f, cy - ringH / 2 - s * 0.012f), Size(w + s * 0.024f, ringH + s * 0.024f), style = Stroke(s * 0.03f))
                    drawOval(sig.copy(alpha = 0.92f * a), Offset(cx - w / 2, cy - ringH / 2), Size(w, ringH), style = Stroke(s * 0.012f))
                }
                // الأسطوانتان الجانبيتان
                drawRoundRect(Color(0xFF1B1B1B), Offset(s * 0.17f, s * 0.49f), Size(s * 0.66f, s * 0.12f), CornerRadius(s * 0.05f))
                // الرأس
                val c = Offset(s * 0.5f, s * 0.52f)
                drawCircle(
                    Brush.radialGradient(listOf(Color.White, Color(0xFFE6E2D8), Color(0xFF9C988E)), Offset(s * 0.45f, s * 0.40f), s * 0.36f),
                    radius = s * 0.27f, center = c
                )
                drawCircle(Color.White.copy(alpha = 0.14f), radius = s * 0.27f, center = c, style = Stroke(s * 0.006f))
                // حرف T
                drawRect(Color(0xFF222222), Offset(s * 0.455f, s * 0.275f), Size(s * 0.09f, s * 0.018f))
                drawRect(Color(0xFF222222), Offset(s * 0.491f, s * 0.275f), Size(s * 0.018f, s * 0.075f))
                // القناع الأسود
                drawRoundRect(Color(0xFF0E0E0E), Offset(s * 0.35f, s * 0.50f), Size(s * 0.30f, s * 0.17f), CornerRadius(s * 0.06f))
                drawRoundRect(Color.White.copy(alpha = 0.08f), Offset(s * 0.365f, s * 0.507f), Size(s * 0.27f, s * 0.045f), CornerRadius(s * 0.03f))
                // العينان
                val ey = s * 0.585f
                val ew = s * 0.062f
                for (ex in listOf(s * 0.43f, s * 0.57f)) {
                    when (mood) {
                        TikoMood.Happy -> drawArc(
                            sig, 200f, 140f, false, Offset(ex - ew / 2, ey - ew * 0.3f), Size(ew, ew),
                            style = Stroke(s * 0.014f, cap = StrokeCap.Round)
                        )
                        TikoMood.Love -> heart(ex, ey, s * 0.06f * (1f + 0.12f * pulse), sig)
                        TikoMood.Dizzy -> {
                            val r = ew * 0.45f
                            drawLine(sig, Offset(ex - r, ey - r), Offset(ex + r, ey + r), s * 0.013f, StrokeCap.Round)
                            drawLine(sig, Offset(ex - r, ey + r), Offset(ex + r, ey - r), s * 0.013f, StrokeCap.Round)
                        }
                        TikoMood.Sleep -> drawRoundRect(sig.copy(alpha = 0.8f), Offset(ex - ew / 2, ey - s * 0.004f), Size(ew, s * 0.008f), CornerRadius(s * 0.004f))
                        else -> {
                            val eh = when (mood) {
                                TikoMood.Wow -> s * 0.07f
                                TikoMood.Listen -> s * 0.044f * (0.7f + 0.7f * pulse)
                                else -> s * 0.044f * blink.value
                            }
                            drawRoundRect(sig.copy(alpha = 0.22f), Offset(ex - ew / 2 - s * 0.008f, ey - eh / 2 - s * 0.008f), Size(ew + s * 0.016f, eh + s * 0.016f), CornerRadius(s * 0.02f))
                            drawRoundRect(sig, Offset(ex - ew / 2, ey - eh / 2), Size(ew, eh), CornerRadius(s * 0.012f))
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.heart(cx: Float, cy: Float, w: Float, color: Color) {
    val p = Path().apply {
        moveTo(cx, cy + w * 0.45f)
        cubicTo(cx - w * 0.9f, cy - w * 0.05f, cx - w * 0.45f, cy - w * 0.7f, cx, cy - w * 0.25f)
        cubicTo(cx + w * 0.45f, cy - w * 0.7f, cx + w * 0.9f, cy - w * 0.05f, cx, cy + w * 0.45f)
        close()
    }
    drawPath(p, color)
}

/* ───────────────────────── حالة تيكو وتفاعله مع الضغط ───────────────────────── */

class TikoState(private val ctx: Context) {
    var tapMood by mutableStateOf<TikoMood?>(null)
    var sleeping by mutableStateOf(false)
    var bubble by mutableStateOf<String?>(null)
    var dance by mutableStateOf(false)
    var chat by mutableStateOf(false)
    var tapId by mutableIntStateOf(0)
    var songs: List<Song> = emptyList()
    private val times = kotlin.collections.ArrayDeque<Long>()

    fun mood(ui: PlayerUi?): TikoMood = tapMood ?: when {
        sleeping -> TikoMood.Sleep
        ui?.isPlaying == true -> TikoMood.Listen
        else -> TikoMood.Idle
    }

    fun tap(ui: PlayerUi?) {
        val now = System.currentTimeMillis()
        while (times.isNotEmpty() && now - times.first() > 3000) times.removeFirst()
        times.addLast(now)
        val n = times.size
        tapId++
        if (sleeping) { sleeping = false; tapMood = TikoMood.Wow; bubble = "آه! صحّيتني 😮"; return }
        when {
            n >= 10 -> { dance = true; tapMood = TikoMood.Happy; bubble = "ههه! هذه رقصتي المفضلة 💃"; times.clear() }
            n >= 5 -> { tapMood = TikoMood.Dizzy; bubble = "آه… الدنيا تدور! 😵" }
            else -> {
                tapMood = listOf(TikoMood.Happy, TikoMood.Love, TikoMood.Wow)[(n - 1) % 3]
                bubble = TikoBrain.tapLine(ctx, ui?.isPlaying == true)
            }
        }
    }

    fun longPress() {
        tapId++
        sleeping = !sleeping
        tapMood = null; dance = false
        bubble = if (sleeping) "نعسان… zzz 😴" else "صباح الخير! 🌞"
    }

    fun beep() {
        if (!AppPrefs.introSound) return
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 30)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ runCatching { tg.release() } }, 300)
        }
    }
}

/** شعار تيكو: اضغط ليتفاعل، اضغط مطوّلًا لينام/يصحو، وضغطتان تفتحان المحادثة. */
@Composable
fun TikoLogo(state: TikoState, ui: PlayerUi?, size: androidx.compose.ui.unit.Dp = 56.dp) {
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier.size(size).clip(RoundedCornerShape(percent = 22)).background(Color(0xFF111111))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); state.beep(); state.tap(ui) },
                    onDoubleTap = { state.chat = true },
                    onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); state.longPress() }
                )
            }
    ) { TikoView(state.mood(ui), Modifier.size(size), state.dance) }
}

/** فقاعة كلام تيكو: تظهر عند الضغط وتختفي وحدها. */
@Composable
fun TikoBubble(state: TikoState) {
    LaunchedEffect(state.tapId) {
        if (state.tapId == 0) return@LaunchedEffect
        val id = state.tapId
        delay(2800)
        if (state.tapId == id) { state.tapMood = null; state.dance = false; if (!state.sleeping) state.bubble = null }
    }
    AnimatedVisibility(state.bubble != null) {
        Box(
            Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                .clip(RoundedCornerShape(16.dp)).background(TM.Raised).padding(horizontal = 14.dp, vertical = 9.dp)
        ) { Text(state.bubble ?: "", fontSize = 14.sp, color = TM.Text) }
    }
}

/* ───────────────────────── عقل تيكو (محلي) ───────────────────────── */

class TikoReply(val text: String, val action: (() -> Unit)? = null)

object TikoBrain {
    private val tips = listOf(
        "هل تعلم؟ اضغط مطوّلًا على أي أغنية لإضافتها إلى ألبوم.",
        "هل تعلم؟ عند إضافة ويدجت من شاشة الهاتف ستجد 10 تصاميم باسم T Music.",
        "اضغط القلب في شاشة التشغيل لتضيف الأغنية إلى المفضلة.",
        "من الرئيسية تقدر تنزّل أغنية MP3 بلصق الرابط.",
        "قسم T Quran في الأعلى فيه القرآن الكريم بأصوات عدة قرّاء.",
        "اضغط عليّ ضغطتين لنتحدث، أو اطلب مني تشغيل أغنية."
    )
    private val fun_ = listOf(
        "هيهي، هذا يدغدغ! 😄", "أنا هنا! ما الذي تحب أن نسمعه؟", "أحب الموسيقى معك 🎶",
        "هل ضغطتني للتو؟ أنا سعيد!", "ابتسم، الموسيقى تحسّن اليوم."
    )
    private val playing = listOf("أغنية رائعة! 🎶", "أشعر بالإيقاع يمرّ بي 🥁", "استمر، أنا أستمع معك.")

    fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            h < 5 -> "سهران؟ لنسمع شيئًا هادئًا 🌙"
            h < 12 -> "صباح الخير! جاهز لموسيقى اليوم؟ ☀️"
            h < 18 -> "طاب يومك! ماذا نسمع؟"
            else -> "مساء الخير! 🌆"
        }
    }

    private fun lastQuran(ctx: Context): Pair<Int, Int>? {
        val last = ctx.getSharedPreferences("tm", Context.MODE_PRIVATE).getString("lastq", null)?.split(":") ?: return null
        val s = last.getOrNull(0)?.toIntOrNull() ?: return null
        val a = last.getOrNull(1)?.toIntOrNull() ?: return null
        return s to a
    }

    fun tapLine(ctx: Context, isPlaying: Boolean): String {
        val r = (0..9).random()
        val q = lastQuran(ctx)
        return when {
            r < 2 && q != null -> "تكمل من سورة ${Quran.surahs.getOrNull(q.first - 1)?.name ?: ""}؟ قل لي: «أكمل القرآن»"
            r < 4 -> tips.random()
            isPlaying && r < 7 -> playing.random()
            r == 9 -> greeting()
            else -> fun_.random()
        }
    }

    private fun norm(s: String) = s.lowercase()
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        .replace(Regex("[\u064B-\u065F]"), "").trim()

    private fun has(q: String, vararg w: String) = w.any { q.contains(it) }

    /** أوامر محلية بلا إنترنت. تُرجع null إن لم تفهم، فيُحال السؤال للذكاء الاصطناعي إن كان مفعّلًا. */
    fun local(ctx: Context, text: String, songs: List<Song>, ui: PlayerUi?): TikoReply? {
        val q = norm(text)
        if (q.isBlank()) return null
        val c = ui?.controller
        if (has(q, "قران", "سوره") && has(q, "كمل", "اكمل", "استمر", "تابع")) {
            val l = lastQuran(ctx) ?: return TikoReply("ما بدأت سورة بعد. افتح T Quran واختر سورة 📖")
            return TikoReply("أكمل لك سورة ${Quran.surahs.getOrNull(l.first - 1)?.name ?: ""} 📖") { ui?.playQuran(l.first, l.second) }
        }
        if (has(q, "ما هذه الاغنيه", "اي اغنيه", "من يغني", "ما الذي يعمل", "what's playing")) {
            val s = songs.firstOrNull { it.id == ui?.currentId } ?: ui?.let { u -> u.online[u.currentId] }
            return TikoReply(if (s != null) "تسمع الآن «${s.title}» لـ ${s.artist} 🎧" else "لا شيء يعمل الآن. قل: «شغّل» وسأختار لك.")
        }
        if (has(q, "وقف", "ايقاف", "اسكت", "pause", "stop")) return TikoReply("تمام، أوقفت الموسيقى ✋") { c?.pause() }
        if (has(q, "التالي", "بعده", "تخطي", "next")) return TikoReply("التالية! ⏭") { c?.seekToNextMediaItem() }
        if (has(q, "السابق", "previous", "prev")) return TikoReply("السابقة ⏮") { c?.seekToPreviousMediaItem() }
        if (has(q, "عشوائي", "خلط", "shuffle")) return TikoReply("بدّلت وضع الخلط 🔀") { ui?.toggleShuffle() }
        if (q.startsWith("شغل") || q.startsWith("play") || q.startsWith("سمعني")) {
            val term = norm(q.removePrefix("شغل").removePrefix("play").removePrefix("سمعني")).trim()
            if (songs.isEmpty()) return TikoReply("مكتبتك فارغة الآن. انسخ أغاني إلى الهاتف وسأشغّلها لك.")
            if (term.isBlank() || has(term, "شيء", "شي", "اي", "موسيقي", "اغنيه")) {
                return TikoReply("اخترت لك مزيجًا عشوائيًا 🎲") { ui?.play(songs.shuffled(), 0, true) }
            }
            if (has(term, "هادي", "هدوء", "استرخاء", "calm")) {
                return TikoReply("ما أعرف مزاج الأغاني بعد، فاخترت لك مزيجًا عشوائيًا. وإن فعّلت الذكاء الاصطناعي سأفهمك أكثر 🙂") { ui?.play(songs.shuffled(), 0, true) }
            }
            val m = songs.filter { norm(it.title).contains(term) || norm(it.artist).contains(term) }
            return if (m.isNotEmpty()) TikoReply("أشغّل لك «${m.first().title}» 🎶") { ui?.play(m, 0) }
            else TikoReply("ما لقيت «$term» في مكتبتك. جرّب تبويب البحث 🔎")
        }
        if (has(q, "كمل", "استمر", "resume")) return TikoReply("نكمل! ▶️") { c?.play() }
        if (has(q, "اقترح", "رشح", "اقتراح", "suggest")) {
            if (songs.isEmpty()) return TikoReply("مكتبتك فارغة الآن.")
            val byId = songs.associateBy { it.id }
            val top = ui?.plays?.entries?.sortedByDescending { it.value }?.mapNotNull { byId[it.key] }?.take(3).orEmpty()
            val pick = top.ifEmpty { songs.shuffled().take(3) }
            return TikoReply("أقترح: " + pick.joinToString("، ") { "«${it.title}»" } + " — أشغّلها لك؟ قل «شغّل» وسأبدأ بها.") { ui?.play(pick, 0) }
        }
        if (has(q, "مرحبا", "اهلا", "السلام", "هلا", "hello", "hi")) return TikoReply(greeting())
        if (has(q, "شكرا", "thanks")) return TikoReply("العفو! أنا هنا دائمًا 💙")
        if (has(q, "مساعده", "help", "ماذا تقدر", "ايش تسوي")) {
            return TikoReply("أقدر: «شغّل [اسم أغنية أو فنان]»، «أوقف»، «التالي»، «اقترح لي»، «ما هذه الأغنية؟»، «أكمل القرآن».")
        }
        return null
    }
}

/** اتصال اختياري بنموذج ذكاء اصطناعي عبر Cloudflare Worker خاص بك (انظر tools/tiko-worker.js). */
object TikoAi {
    suspend fun ask(url: String, history: List<Pair<Boolean, String>>, context: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val arr = JSONArray()
            history.takeLast(10).forEach { (user, t) -> arr.put(JSONObject().put("role", if (user) "user" else "assistant").put("content", t)) }
            val body = JSONObject().put("messages", arr).put("context", context).toString()
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.connectTimeout = 10000; c.readTimeout = 30000
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode != 200) null
                else JSONObject(c.inputStream.bufferedReader().readText()).optString("reply").takeIf { it.isNotBlank() }
            } finally { c.disconnect() }
        }.getOrNull()
    }
}

/* ───────────────────────── نافذة المحادثة ───────────────────────── */

private class Msg(val user: Boolean, val text: String)

@Composable
fun TikoChat(state: TikoState, ui: PlayerUi?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var thinking by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size, thinking) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size + if (thinking) 1 else 0) }

    fun send(t: String) {
        val text = t.trim()
        if (text.isBlank() || thinking) return
        msgs += Msg(true, text); input = ""
        val local = TikoBrain.local(ctx, text, state.songs, ui)
        if (local != null) { msgs += Msg(false, local.text); local.action?.invoke(); return }
        val url = AppPrefs.tikoUrl.trim()
        if (url.isBlank()) {
            msgs += Msg(false, "ما فهمت هذا الأمر بعد 🙈 جرّب: «شغّل …» أو «اقترح لي». ولأتحدث معك بحرية، فعّل الذكاء الاصطناعي من الإعدادات ثم «تيكو».")
            return
        }
        thinking = true
        scope.launch {
            val cur = state.songs.firstOrNull { it.id == ui?.currentId }
            val ctxLine = "المستخدم يسمع الآن: " + (cur?.let { "«${it.title}» لـ ${it.artist}" } ?: "لا شيء") + ". عدد أغاني مكتبته: ${state.songs.size}."
            val r = TikoAi.ask(url, msgs.map { it.user to it.text }, ctxLine)
            msgs += Msg(false, r ?: "تعذّر الاتصال بعقلي الذكي الآن 😅 تأكد من الإنترنت ومن رابط Worker في الإعدادات.")
            thinking = false
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(
                Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.72f).clip(RoundedCornerShape(26.dp)).background(Color(0xFF141414)).padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF111111))) {
                        TikoView(if (thinking) TikoMood.Wow else TikoMood.Happy, Modifier.size(44.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("تيكو", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TikoSignal)
                        Text(if (AppPrefs.tikoUrl.isBlank()) "أوامر محلية بلا إنترنت" else "الذكاء الاصطناعي مفعّل", color = TM.Muted, fontSize = 11.sp)
                    }
                    TextButton(onClick = onClose) { Text("إغلاق") }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Bubble(false, TikoBrain.greeting() + "\nأنا تيكو، مرشدك ومساعدك. اطلب مني تشغيل أغنية أو اسألني أي شيء.")
                    }
                    itemsIndexed(msgs) { _, m -> Bubble(m.user, m.text) }
                    if (thinking) item { Bubble(false, "أفكّر…") }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("شغّل", "اقترح لي", "ما هذه الأغنية؟", "التالي").forEach { chip ->
                        Box(
                            Modifier.clip(RoundedCornerShape(50)).background(TM.Raised).clickable { send(chip) }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) { Text(chip, fontSize = 12.sp, color = TM.Text) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب لتيكو…", color = TM.Muted) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send(input) }),
                        shape = RoundedCornerShape(18.dp)
                    )
                    IconButton(onClick = { send(input) }, enabled = !thinking) {
                        Icon(Icons.Rounded.Send, "إرسال", tint = TikoSignal)
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(user: Boolean, text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.Start else Arrangement.End) {
        Box(
            Modifier.fillMaxWidth(0.82f).clip(RoundedCornerShape(18.dp))
                .background(if (user) TikoSignal else TM.Raised).padding(horizontal = 13.dp, vertical = 9.dp)
        ) { Text(text, color = if (user) Color.Black else TM.Text, fontSize = 14.sp, textAlign = TextAlign.Start) }
    }
}

/* ───────────────────────── الجولة التعريفية ───────────────────────── */

@Composable
fun TikoTour(onDone: () -> Unit) {
    val steps = listOf(
        TikoMood.Happy to "أهلًا! أنا تيكو، مرشدك ومساعدك في T Music 👋",
        TikoMood.Idle to "من الشريط السفلي تتنقّل بين الرئيسية والبحث والمكتبة والتنزيلات والإعدادات.",
        TikoMood.Wow to "زر T Quran في الأعلى يفتح قسم القرآن الكريم، وأتذكّر لك آخر موضع وصلت إليه.",
        TikoMood.Idle to "من الصفحة الرئيسية تنزّل أغنية MP3 بلصق الرابط، وتجدها في تبويب التنزيلات.",
        TikoMood.Love to "اضغط عليّ في أي وقت وسأتفاعل، وبضغطتين نتحدث: اطلب مني أي أغنية 💙"
    )
    var i by remember { mutableIntStateOf(0) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color(0xFF141414)).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(150.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF111111))) {
                    TikoView(steps[i].first, Modifier.size(150.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(steps[i].second, textAlign = TextAlign.Center, color = TM.Text, fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    steps.indices.forEach { k ->
                        Box(Modifier.size(if (k == i) 9.dp else 6.dp).background(if (k == i) TikoSignal else TM.Muted.copy(alpha = 0.5f), CircleShape))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDone) { Text("تخطّي", color = TM.Muted) }
                    TextButton(onClick = { if (i < steps.lastIndex) i++ else onDone() }) {
                        Text(if (i < steps.lastIndex) "التالي" else "هيا نبدأ", fontWeight = FontWeight.Bold, color = TikoSignal)
                    }
                }
            }
        }
    }
}
