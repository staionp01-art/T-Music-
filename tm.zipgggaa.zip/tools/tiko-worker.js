// عقل تيكو الذكي: Cloudflare Worker يتوسط بين التطبيق وواجهة Claude، فلا يظهر المفتاح داخل التطبيق.
//
// الإعداد (مرة واحدة):
// 1) أنشئ Worker جديدًا في Cloudflare والصق هذا الملف.
// 2) من Settings > Variables أضف Secrets:
//      ANTHROPIC_API_KEY = مفتاحك من console.anthropic.com
//      APP_TOKEN         = كلمة سر طويلة من اختيارك (تمنع غيرك من استهلاك رصيدك)
//    ومتغيرًا اختياريًا MODEL لتغيير النموذج.
// 3) انسخ رابط الـ Worker وألصقه في التطبيق: الإعدادات > تيكو، بهذا الشكل:
//      https://اسم-worker.workers.dev/?k=كلمة_السر

const MODEL_DEFAULT = "claude-haiku-5-5"; // غيّره إذا لزم (يمكن أيضًا عبر المتغير MODEL)

const SYSTEM = `أنت «تيكو»، روبوت لطيف وذكي وهو شخصية تطبيق T Music (موسيقى وقرآن) ومرشد المستخدم فيه.
- تكلّم بالعربية بأسلوب ودود ومرح وقصير (جملتان أو ثلاث غالبًا)، ويمكنك استعمال إيموجي بقدر قليل.
- ساعد في اقتراح الأغاني والأجواء الموسيقية وشرح معاني الأغاني بشكل عام وتعريف ميزات التطبيق.
- لا تختلق معلومات عن أغانٍ أو فنانين لا تعرفهم؛ قل بصدق إنك لست متأكدًا.
- لا تنفّذ أوامر داخل التطبيق بنفسك؛ إن طلب المستخدم تشغيلًا أو إيقافًا فاقترح عليه أن يكتب مثلًا: «شغّل اسم الأغنية».`;

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json; charset=utf-8" } });

export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("Tiko is awake 🤖", { status: 200 });
    const url = new URL(req.url);
    if (env.APP_TOKEN && url.searchParams.get("k") !== env.APP_TOKEN) return json({ error: "unauthorized" }, 401);

    let body;
    try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }

    let msgs = (body.messages || []).slice(-12).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 1500),
    })).filter(m => m.content);
    while (msgs.length && msgs[0].role !== "user") msgs.shift();   // يجب أن تبدأ بالمستخدم
    if (!msgs.length) return json({ reply: "قل لي شيئًا لأرد عليك 🙂" });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: env.MODEL || MODEL_DEFAULT,
        max_tokens: 400,
        system: SYSTEM + "\n\nسياق: " + String(body.context || "").slice(0, 600),
        messages: msgs,
      }),
    });
    if (!r.ok) return json({ error: "upstream " + r.status }, 502);
    const data = await r.json();
    const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim();
    return json({ reply: reply || "ما عرفت أرد الآن 😅" });
  },
};
