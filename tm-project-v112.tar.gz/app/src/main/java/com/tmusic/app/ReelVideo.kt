package com.tmusic.app

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.os.Build
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** قوالب الريلز المبنية على مقاطع فيديو حقيقية (assets/reelbg/bgN.mp4) بدل الرسم بالكود. */
val reelVideoNames = listOf("ساكورا رمادي", "ساكورا ليلي", "عيون الساكورا", "الساموراي", "مجرّة")

/** عدد قوالب الرسم القديمة قبل قوالب الفيديو (زجاجي، ساكورا، غلاف نابض، أسطوانة). */
const val REEL_VIDEO_BASE = 4

/**
 * مشهد: مقطع فيديو يتكرر في وسط الإطار فوق خلفية مموّهة منه نفسه، وبطاقة زجاجية سفلية
 * فيها الغلاف والعنوان وأعمدة الصوت الحقيقية وشريط التقدم.
 * المقاطع مضغوطة بإطارات مفتاحية في كل إطار (all-intra) فالقفز لأي إطار سريع.
 */
class VideoScene(
    ctx: Context, private val song: Song, art: Bitmap?, private val lenSec: Int,
    label: String, private val spec: Spectrum, index: Int
) : ReelFrame {
    private val W = 720f
    private val H = 1280f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val art = art
    private val logo: Bitmap? = runCatching { BitmapFactory.decodeResource(ctx.resources, R.drawable.tm_logo) }.getOrNull()
    private val accent: Int = run {
        if (art == null) return@run Color.rgb(255, 140, 200)
        runCatching {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = hsv[1].coerceAtLeast(0.45f); hsv[2] = hsv[2].coerceAtLeast(0.9f)
            Color.HSVToColor(hsv)
        }.getOrDefault(Color.rgb(255, 140, 200))
    }

    private val mmr = MediaMetadataRetriever()
    private var durUs = 1_000_000L
    private var ready = false
    private var lastIdx = -1
    private var frame: Bitmap? = null
    private val tiny = Bitmap.createBitmap(24, 42, Bitmap.Config.ARGB_8888)
    private val tinyCanvas = Canvas(tiny)

    private val tag = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 40f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 28f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
    private val tt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 34f; typeface = Typeface.DEFAULT_BOLD }
    private val ta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 255, 255, 255); textSize = 25f }
    private val cta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 255, 255, 255); textSize = 30f; textAlign = Paint.Align.CENTER }

    private val card = RectF(40f, 760f, 680f, 1130f)
    private val cover = RectF(card.left + 24f, card.top + 24f, card.left + 24f + 200f, card.top + 24f + 200f)
    private val textX = cover.right + 24f
    private val textW = card.right - 24f - textX
    private val tTitle = TextUtils.ellipsize(song.title, tt, textW, TextUtils.TruncateAt.END).toString()
    private val tArtist = TextUtils.ellipsize(song.artist, ta, textW, TextUtils.TruncateAt.END).toString()
    private val brand = label.ifBlank { "T MUSIC" }.take(26).uppercase().let { s ->
        while (head.textSize > 16f && head.measureText(s) > textW) head.textSize -= 1f
        s
    }
    private val bars = FloatArray(30)
    private val croppedArt: Bitmap? = art

    init {
        runCatching {
            ctx.assets.openFd("reelbg/bg${index + 1}.mp4").use { fd ->
                mmr.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            }
            durUs = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 1000L) * 1000L
            durUs = max(durUs, 1_000_000L)
            ready = true
        }
    }

    private fun grab(t: Float) {
        if (!ready) return
        // نكرّر المقطع بالتناوب (للأمام ثم للخلف) فلا يظهر قفز عند نهايته
        val tu = (t * 1_000_000f).toLong()
        val cyc = durUs * 2
        val m = ((tu % cyc) + cyc) % cyc
        val pos = if (m < durUs) m else cyc - m
        val idx = (pos / 33_333L).toInt()
        if (idx == lastIdx && frame != null) return
        lastIdx = idx
        val bmp = runCatching {
            if (Build.VERSION.SDK_INT >= 27) mmr.getScaledFrameAtTime(pos.coerceAtMost(durUs - 1), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 720, 406)
            else mmr.getFrameAtTime(pos.coerceAtMost(durUs - 1), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        }.getOrNull()
        if (bmp != null) { val old = frame; frame = bmp; if (old != null && old !== bmp) old.recycle() }
    }

    override fun draw(c: Canvas, t: Float) {
        grab(t)
        val fr = frame
        // الخلفية: الإطار نفسه مصغّرًا ومكبّرًا (تمويه رخيص) ثم تعتيم
        c.drawColor(Color.BLACK)
        if (fr != null) {
            tinyCanvas.drawBitmap(fr, null, Rect(0, 0, tiny.width, tiny.height), paint)
            c.drawBitmap(tiny, null, RectF(0f, 0f, W, H), paint)
        }
        c.drawColor(Color.argb(110, 0, 0, 0))

        // الفيديو في الوسط بحافتين ناعمتين
        val bh = if (fr != null) W * fr.height / fr.width else 406f
        val top = 250f
        val dst = RectF(0f, top, W, top + bh)
        if (fr != null) c.drawBitmap(fr, null, dst, paint)
        val fade = 70f
        paint.shader = LinearGradient(0f, top - 4f, 0f, top + fade, Color.argb(235, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, top - 4f, W, top + fade, paint)
        paint.shader = LinearGradient(0f, top + bh - fade, 0f, top + bh + 4f, Color.TRANSPARENT, Color.argb(235, 0, 0, 0), Shader.TileMode.CLAMP)
        c.drawRect(0f, top + bh - fade, W, top + bh + 4f, paint)
        paint.shader = null

        // العلامة العلوية
        logo?.let {
            val h = 64f; val w = h * it.width / it.height
            c.drawBitmap(it, null, RectF(W / 2f - w / 2f, 70f, W / 2f + w / 2f, 70f + h), paint)
        }
        c.drawText("T Music", W / 2f, 190f, tag)

        // البطاقة الزجاجية
        paint.color = Color.argb(70, 10, 10, 16); c.drawRoundRect(card, 44f, 44f, paint)
        paint.color = Color.argb(34, 255, 255, 255); c.drawRoundRect(card, 44f, 44f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.argb(90, 255, 255, 255)
        c.drawRoundRect(card, 44f, 44f, paint); paint.style = Paint.Style.FILL

        // الغلاف (ينبض مع الجهير)
        val k = 1f + 0.035f * spec.bass(t)
        val cx = cover.centerX(); val cy = cover.centerY()
        val r = RectF(cx - cover.width() / 2 * k, cy - cover.height() / 2 * k, cx + cover.width() / 2 * k, cy + cover.height() / 2 * k)
        c.save()
        c.clipPath(Path().apply { addRoundRect(r, 32f, 32f, Path.Direction.CW) })
        val a = croppedArt
        if (a != null) c.drawBitmap(a, coverCrop(a, r), r, paint) else { paint.color = accent; c.drawRect(r, paint) }
        c.restore()

        // النصوص
        c.drawText(brand, textX, cover.top + 44f, head)
        c.drawText(tTitle, textX, cover.top + 110f, tt)
        c.drawText(tArtist, textX, cover.top + 152f, ta)

        // أعمدة الصوت الحقيقية
        spec.at(t, bars)
        val n = bars.size; val bw = 11f; val gap = (card.width() - 48f - n * bw) / (n - 1)
        var x = card.left + 24f
        val base = card.bottom - 70f
        paint.color = accent
        for (i in 0 until n) {
            val h = 10f + 80f * bars[i].coerceIn(0f, 1f)
            c.drawRoundRect(RectF(x, base - h, x + bw, base), 5f, 5f, paint)
            x += bw + gap
        }
        // شريط التقدم
        val py = card.bottom - 36f
        paint.color = Color.argb(80, 255, 255, 255); c.drawRoundRect(RectF(card.left + 24f, py, card.right - 24f, py + 8f), 4f, 4f, paint)
        paint.color = Color.WHITE
        c.drawRoundRect(RectF(card.left + 24f, py, card.left + 24f + (card.width() - 48f) * (t / lenSec).coerceIn(0f, 1f), py + 8f), 4f, 4f, paint)

        c.drawText("استمع إلى المزيد على T Music", W / 2f, 1210f, cta)
    }

    override fun recycle() {
        runCatching { mmr.release() }
        runCatching { frame?.recycle() }
        runCatching { tiny.recycle() }
    }
}
