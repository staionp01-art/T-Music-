package com.tmusic.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.Brush
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** إعدادات التطبيق العامة (تُحفظ في SharedPreferences وتُقرأ فورًا من أي شاشة). */
object AppPrefs {
    private var prefs: SharedPreferences? = null
    private var inited = false

    /** سرعة التشغيل: 0.5 .. 2.0 */
    var speed by mutableFloatStateOf(1f)
    /** إبقاء طبقة الصوت ثابتة عند تغيير السرعة (بدون «صوت سنجاب»). */
    var keepPitch by mutableStateOf(true)
    /** جودة بثّ أغاني الإنترنت: true = عالية، false = منخفضة لتوفير الباقة. */
    var streamHigh by mutableStateOf(true)
    var introSound by mutableStateOf(true)
    var logoTilt by mutableStateOf(true)
    var keepOn by mutableStateOf(false)
    /** التبويب الذي يفتح عليه التطبيق (0 الرئيسية .. 3 التنزيلات). */
    var startTab by mutableIntStateOf(0)
    var autoUpdate by mutableStateOf(true)

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val p = ctx.applicationContext.getSharedPreferences("tm_settings", Context.MODE_PRIVATE)
        prefs = p
        speed = p.getFloat("speed", 1f).coerceIn(0.5f, 3f)
        keepPitch = p.getBoolean("pitch", true)
        streamHigh = p.getBoolean("stream_high", true)
        introSound = p.getBoolean("intro_sound", true)
        logoTilt = p.getBoolean("logo_tilt", true)
        keepOn = p.getBoolean("keep_on", false)
        startTab = p.getInt("start_tab", 0).coerceIn(0, 3)
        autoUpdate = p.getBoolean("auto_update", true)
    }

    fun updateSpeed(v: Float) { speed = v; prefs?.edit()?.putFloat("speed", v)?.apply(); activeUi?.applySpeed() }
    fun updateKeepPitch(v: Boolean) { keepPitch = v; prefs?.edit()?.putBoolean("pitch", v)?.apply(); activeUi?.applySpeed() }
    fun updateStreamHigh(v: Boolean) { streamHigh = v; prefs?.edit()?.putBoolean("stream_high", v)?.apply() }
    fun updateIntroSound(v: Boolean) { introSound = v; prefs?.edit()?.putBoolean("intro_sound", v)?.apply() }
    fun updateLogoTilt(v: Boolean) { logoTilt = v; prefs?.edit()?.putBoolean("logo_tilt", v)?.apply() }
    fun updateKeepOn(v: Boolean) { keepOn = v; prefs?.edit()?.putBoolean("keep_on", v)?.apply() }
    fun updateStartTab(v: Int) { startTab = v; prefs?.edit()?.putInt("start_tab", v)?.apply() }
    fun updateAutoUpdate(v: Boolean) { autoUpdate = v; prefs?.edit()?.putBoolean("auto_update", v)?.apply() }

    fun speedLabel(v: Float = speed): String = v.toString().removeSuffix(".0") + "×"
}

/** مؤقّت النوم: يوقف التشغيل بعد عدد من الدقائق. */
object SleepTimer {
    var endAt by mutableLongStateOf(0L)
        private set
    private val handler = Handler(Looper.getMainLooper())
    private val fire = Runnable { activeUi?.controller?.pause(); endAt = 0L }

    fun start(minutes: Int) {
        handler.removeCallbacks(fire)
        endAt = System.currentTimeMillis() + minutes * 60_000L
        handler.postDelayed(fire, minutes * 60_000L)
    }

    fun cancel() { handler.removeCallbacks(fire); endAt = 0L }
}

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f)

@Composable
private fun SpeedChips() {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SPEEDS.forEach { v ->
            FilterChip(AppPrefs.speed == v, { AppPrefs.updateSpeed(v) }, label = { Text(AppPrefs.speedLabel(v)) })
        }
    }
}

/** نافذة سريعة لاختيار السرعة من شاشة التشغيل. */
@Composable
fun SpeedDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, containerColor = TM.Surface,
        title = { Text("سرعة التشغيل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SpeedChips()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("إبقاء طبقة الصوت", Modifier.weight(1f))
                    Switch(AppPrefs.keepPitch, { AppPrefs.updateKeepPitch(it) })
                }
            }
        },
        confirmButton = { TextButton(onClose) { Text("تم", color = TM.VioletSoft) } }
    )
}

/** شعار T-Music يُكتب بالفرشاة كما في شاشة الافتتاح، ويتحرك مع ميلان الهاتف. اضغط عليه لإعادة الحركة. */
@Composable
fun LogoHero(modifier: Modifier = Modifier) {
    val brush = ImageBitmap.imageResource(R.drawable.tm_brush)
    val text = ImageBitmap.imageResource(R.drawable.tm_text)
    val glyph = ImageBitmap.imageResource(R.drawable.tm_t)
    val white = remember { ColorFilter.tint(Color.White) }
    val black = remember { ColorFilter.tint(Color.Black) }
    val rnd = remember { java.util.Random(7) }
    val rb0 = remember { FloatArray(64) { rnd.nextFloat() } }
    val rb1 = remember { FloatArray(64) { rnd.nextFloat() } }
    val rs0 = remember { FloatArray(90) { rnd.nextFloat() } }
    val t = remember { Animatable(0f) }
    var replay by remember { mutableIntStateOf(0) }
    val tilt = rememberTilt()

    LaunchedEffect(replay) {
        t.snapTo(0f)
        t.animateTo(4.9f, tween(4900, easing = LinearEasing))
    }
    Canvas(
        modifier.fillMaxWidth().height(230.dp)
            .pointerInput(Unit) { detectTapGestures { replay++ } }
            .graphicsLayer {
                if (AppPrefs.logoTilt) {
                    cameraDistance = 14f * density
                    rotationY = tilt.x * 16f
                    rotationX = -tilt.y * 12f
                    translationX = tilt.x * 28f * density
                    translationY = tilt.y * 10f * density
                }
            }
    ) {
        tmLogoDraw(t.value, brush, text, glyph, white, black, rb0, rb1, rs0, fill = .9f, heightFill = 1f)
    }
}

// ---------- لبنات الواجهة ----------
private val GroupTints = listOf(
    Color(0xFF7C9CFF), Color(0xFF5CE0B0), Color(0xFFFFB86B),
    Color(0xFFFF7A9A), Color(0xFFB69CFF), Color(0xFF6ED3FF)
)

/** أيقونة داخل مربع مدوّر بتدرّج لوني ناعم (بدل الأيقونة الرمادية المجرّدة). */
@Composable
private fun IconBadge(icon: ImageVector, tint: Color, size: androidx.compose.ui.unit.Dp = 36.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.32f))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.34f), tint.copy(alpha = 0.10f)))),
        Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.54f), tint = tint) }
}

/** مجموعة إعدادات: اضغط العنوان لتطويها أو تفتحها. */
@Composable
private fun Group(title: String, icon: ImageVector, index: Int, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(true) }
    val rot by animateFloatAsState(if (open) 180f else 0f, label = "group-chevron")
    val tint = GroupTints[index % GroupTints.size]
    Column(
        Modifier.fadeUp(index).rubberDrag().fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(24.dp)).background(TM.Surface).padding(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).bounceClick(0.98f) { open = !open },
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(icon, tint)
            Spacer(Modifier.width(12.dp))
            Text(title, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Icon(Icons.Rounded.ExpandMore, null, Modifier.size(24.dp).graphicsLayer { rotationZ = rot }, tint = TM.Muted)
        }
        AnimatedVisibility(open, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, color = TM.Muted, fontSize = 11.sp)
        }
        GlassSwitch(checked, onChange)
    }
}

@Composable
private fun Label(text: String) = Text(text, color = TM.Muted, fontSize = 13.sp)

@Composable
private fun ActionRow(icon: ImageVector, title: String, sub: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).bounceClick(0.97f, onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon, GroupTints[(title.length + (sub?.length ?: 0)) % GroupTints.size], 34.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, color = TM.Muted, fontSize = 11.sp)
        }
        Icon(Icons.Rounded.ChevronLeft, null, tint = TM.Muted)
    }
}

/** القرآن دون إنترنت: تنزيل نص كل السور مرة واحدة. */
@Composable
private fun QuranOfflineGroup() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { QuranOffline.refresh(ctx) }
    Group("القرآن دون إنترنت", Icons.Rounded.MenuBook, 4) {
        val n = QuranOffline.ready
        Text(
            if (n >= QuranOffline.TOTAL) "النص كامل على جهازك ✔ (114 سورة)" else "المحفوظ على الجهاز: $n من ${QuranOffline.TOTAL} سورة",
            color = if (n >= QuranOffline.TOTAL) TM.Emerald else TM.Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
        )
        Text(
            "بعد التنزيل تُقرأ كل السور دون اتصال. التلاوة الصوتية ما زالت تحتاج إنترنت.",
            color = TM.Muted, fontSize = 12.sp
        )
        if (QuranOffline.failed) Text("تعذّر التنزيل، تأكد من الإنترنت ثم أعد المحاولة.", color = TM.Gold, fontSize = 12.sp)
        if (n < QuranOffline.TOTAL) {
            Button({ scope.launch { QuranOffline.downloadAll(ctx) } }, Modifier.fillMaxWidth(), enabled = !QuranOffline.busy) {
                Text(if (QuranOffline.busy) "جارٍ التنزيل… $n / ${QuranOffline.TOTAL}" else "تنزيل القرآن كاملًا")
            }
        }
    }
}

/** إعدادات Now Bar: حالة إذن الإشعارات + أزرار الصلاحيات. */
@Composable
private fun NowBarGroup(toast: (String) -> Unit) {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(NowBar.notifOk(ctx)) }
    val launcher = rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { ok = NowBar.notifOk(ctx) }
    LaunchedEffect(Unit) { while (true) { ok = NowBar.notifOk(ctx); delay(1000) } }
    Group("Now Bar والنشاط الجاري", Icons.Rounded.NotificationsActive, 3) {
        Text(
            if (ok) "إذن الإشعارات: مفعّل ✔" else "إذن الإشعارات: غير مفعّل",
            color = if (ok) TM.Emerald else TM.Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
        )
        Text(
            "ليظهر التشغيل في Now Bar وشريحة شريط الحالة (سامسونج One UI 7/8) أو الإشعار المميّز (أندرويد 16): اسمح بالإشعارات ثم فعّل «الإشعارات الحيّة» لـ T Music من الصفحة التالية. إن لم يدعمها نظامك فلن تظهر، ويبقى إشعار التشغيل العادي.",
            color = TM.Muted, fontSize = 12.sp
        )
        if (!ok) {
            Button({
                if (android.os.Build.VERSION.SDK_INT >= 33) launcher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                else NowBar.openSettings(ctx)
            }, Modifier.fillMaxWidth()) { Text("السماح بالإشعارات") }
        }
        ActionRow(Icons.Rounded.OpenInNew, "فتح إعدادات الإشعارات الحيّة", "فعّل Now Bar / الإشعار المميّز لـ T Music") {
            NowBar.openSettings(ctx)
            if (!ok) toast("اسمح بالإشعارات أولًا")
        }
    }
}

/** التبويب الخامس: كل الإعدادات في مكان واحد. */
@Composable
fun SettingsTab(ui: PlayerUi) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showAccount by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    if (showAccount) AccountDialog { showAccount = false }
    if (showProfile) ProfileEditDialog { showProfile = false }

    val wp = remember { ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE) }
    var wAlpha by remember { mutableFloatStateOf(wp.getInt("alpha", 255) / 255f) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(SleepTimer.endAt) {
        while (SleepTimer.endAt > 0L) { now = System.currentTimeMillis(); delay(1000) }
    }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        LogoHero(Modifier.padding(top = 4.dp))
        Text(
            "الإعدادات", Modifier.fadeUp(0).padding(horizontal = 16.dp),
            style = MaterialTheme.typography.headlineMedium
        )
        Text("اضغط الشعار لإعادة الحركة، وحرّك هاتفك ليتحرك", Modifier.fadeUp(1).padding(horizontal = 16.dp, vertical = 2.dp), color = TM.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))

        // بلاطات سريعة: اسحبها بإصبعك فتتبعك وترجع بنابض
        Row(Modifier.fadeUp(2).fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile(Icons.Rounded.Equalizer, "الإيكولايزر", if (Eq.enabled) "مفعّل" else "متوقف", Modifier.weight(1f)) { EqUi.show(ctx) }
            QuickTile(Icons.Rounded.Speed, "السرعة", AppPrefs.speedLabel(), Modifier.weight(1f)) {
                val i = SPEEDS.indexOf(AppPrefs.speed)
                AppPrefs.updateSpeed(SPEEDS[(i + 1).mod(SPEEDS.size)])
            }
            QuickTile(Icons.Rounded.Bedtime, "مؤقّت النوم", if (SleepTimer.endAt > 0L) "يعمل" else "30 د", Modifier.weight(1f)) {
                if (SleepTimer.endAt > 0L) { SleepTimer.cancel(); toast("أُلغي المؤقّت") } else { SleepTimer.start(30); toast("سيتوقف التشغيل بعد 30 دقيقة") }
            }
        }
        Spacer(Modifier.height(8.dp))

        // الحساب
        Group("الحساب", Icons.Rounded.AccountCircle, 2) {
            Row(Modifier.fillMaxWidth().clickable { showProfile = true }, verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(Profile.name.ifBlank { "اكتب اسمك" }, fontWeight = FontWeight.SemiBold)
                    Text(if (Cloud.signedIn) "متصل · نسخك الاحتياطي محفوظ" else "غير مسجّل الدخول", color = TM.Muted, fontSize = 11.sp)
                }
                Icon(Icons.Rounded.Edit, null, tint = TM.Muted)
            }
            ActionRow(Icons.Rounded.CloudSync, "الحساب والنسخ الاحتياطي", "تسجيل الدخول واستعادة بياناتك") { showAccount = true }
        }

        // التشغيل
        Group("التشغيل", Icons.Rounded.PlayCircle, 3) {
            Label("سرعة التشغيل (تعمل أيضًا مع القرآن والمحاضرات)")
            SpeedChips()
            SwitchRow("إبقاء طبقة الصوت", "تغيير السرعة بدون تغيير نغمة الصوت", AppPrefs.keepPitch) { AppPrefs.updateKeepPitch(it) }
            SwitchRow("انتقال متلاشٍ بين الأغاني", "يخفت الصوت في نهاية الأغنية ويرتفع في بداية التالية", TM.fade) { TM.applyFade(it) }
            Label("مؤقّت النوم")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    AssistChip({ SleepTimer.start(m); toast("سيتوقف التشغيل بعد $m دقيقة") }, label = { Text("$m د") })
                }
            }
            if (SleepTimer.endAt > 0L) {
                val rem = ((SleepTimer.endAt - now) / 60_000L).coerceAtLeast(0L) + 1
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("سيتوقف التشغيل بعد نحو $rem دقيقة", Modifier.weight(1f), color = TM.VioletSoft, fontSize = 13.sp)
                    TextButton({ SleepTimer.cancel() }) { Text("إلغاء", color = TM.Muted) }
                }
            }
            ActionRow(Icons.Rounded.Equalizer, "الإيكولايزر", "ضبط الأصوات والباس") { EqUi.show(ctx) }
        }

        // الزجاج السائل والأداء
        Group("الزجاج السائل والأداء", Icons.Rounded.AutoAwesome, 3) {
            val act = remember(ctx) { ctx.hostActivity() }
            val rates = remember(act) { act?.let { Glass.supportedRates(it) } ?: listOf(60) }
            val cur = remember(act, Glass.fps) { act?.let { Glass.currentRate(it) } ?: 60 }
            Text("المستوى الحالي: ${Glass.tierName} · شاشتك تعمل الآن بـ $cur هرتز", color = TM.Muted, fontSize = 12.sp)
            Label("جودة الزجاج")
            GlassSegmented(listOf("تلقائي", "أداء", "زجاج", "سائل"), Glass.quality.coerceIn(0, 3), { Glass.quality = it; Glass.save() })
            Label("معدل الإطارات (الشاشة تدعم: ${rates.joinToString(" / ")} هرتز)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(Glass.fps == 0, { Glass.fps = 0; Glass.save(); act?.let { Glass.applyRefresh(it) } }, label = { Text("تلقائي") })
                listOf(30, 60, 90, 120).forEach { r ->
                    FilterChip(Glass.fps == r, {
                        Glass.fps = r; Glass.save(); act?.let { Glass.applyRefresh(it) }
                        if (r !in rates) toast("شاشتك لا تدعم $r هرتز بالضبط، اخترتُ أقرب معدل مدعوم")
                    }, label = { Text("$r") })
                }
                FilterChip(Glass.fps == -1, { Glass.fps = -1; Glass.save(); act?.let { Glass.applyRefresh(it) } }, label = { Text("الأقصى") })
            }
            SwitchRow("عدّاد الفريمات", "يعرض الفريمات الحقيقية فوق الشاشة لتتأكد أن المعدل مطبّق", Glass.showFps) { Glass.showFps = it; Glass.save() }
            SwitchRow("حركة الخلفية واللمعان", "أوقفها لتوفير البطارية وتخفيف الحمل", Glass.motion) { Glass.motion = it; Glass.save() }
            SwitchRow("خفض الجودة تلقائيًا عند التقطيع", "يراقب سلاسة الرسم ويخفّض المؤثرات وحده إن تعثّر الجهاز", Glass.adaptive) { Glass.adaptive = it; Glass.save() }
            if (Glass.penalty > 0) ActionRow(Icons.Rounded.Refresh, "إعادة ضبط الأداء التلقائي", "رجوع إلى أعلى مستوى يناسب جهازك") { Glass.resetAuto(); toast("أُعيد الضبط") }
        }

        // Now Bar / النشاط الجاري
        NowBarGroup { toast(it) }
        QuranOfflineGroup()

        // الصوت
        Group("الصوت", Icons.Rounded.VolumeUp, 3) {
            SwitchRow("شريط الصوت الخاص بالتطبيق", "أزرار الهاتف تُظهر شريط T Music في الأعلى بدل لوحة النظام", VolBoost.hudOn) { VolBoost.hudOn = it; VolBoost.saveSettings() }
            Label("أقصى تعزيز للصوت فوق 100%")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("معطّل" to 100, "150%" to 150, "200%" to 200, "300%" to 300).forEach { (n, v) ->
                    FilterChip(VolBoost.maxPercent == v, {
                        VolBoost.maxPercent = v; if (VolBoost.percent > v) VolBoost.set(v); VolBoost.saveSettings()
                    }, label = { Text(n) })
                }
            }
            Text("اضغط زر رفع الصوت وهو في أقصاه ليبدأ التعزيز. فوق 150% قد يتشوه الصوت ويرهق السمع.", color = TM.Muted, fontSize = 11.sp)
        }

        // الجودة
        Group("الجودة", Icons.Rounded.HighQuality, 4) {
            Label("جودة تنزيل MP3 (كيلوبت/ثانية) — الأعلى أفضل صوتًا وأكبر حجمًا")
            QualityChips()
            Label("جودة بثّ أغاني الإنترنت")
            GlassSegmented(listOf("عالية", "منخفضة · توفير باقة"), if (AppPrefs.streamHigh) 0 else 1, { AppPrefs.updateStreamHigh(it == 0) })
            Text("تُطبَّق جودة البث على نتائج البحث الجديدة.", color = TM.Muted, fontSize = 11.sp)
        }

        // المظهر
        Group("المظهر", Icons.Rounded.Palette, 5) {
            GlassSegmented(listOf("افتراضي", "داكن", "AMOLED", "حسب الوقت"), TM.mode.coerceIn(0, 3), { TM.applyMode(it) })
            SwitchRow("غلاف دائري يدور كأسطوانة", null, TM.vinyl) { TM.applyVinyl(it) }
            SwitchRow("حركة الشعار مع ميلان الهاتف", "يتحرك الشعار هنا عند إمالة الهاتف", AppPrefs.logoTilt) { AppPrefs.updateLogoTilt(it) }
            Label("هالة تيكو")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TikoLook.auraNames.forEachIndexed { i, n -> FilterChip(TikoLook.aura == i, { TikoLook.chooseAura(i) }, label = { Text(n) }) }
            }
            Label("قبعة تيكو")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TikoLook.hatNames.forEachIndexed { i, n -> FilterChip(TikoLook.hat == i, { TikoLook.chooseHat(i) }, label = { Text(n) }) }
            }
            SwitchRow("إظهار تيكو", "الشخصية المتحركة في التطبيق", TikoKit.enabled) { TikoKit.chooseEnabled(it) }
            SwitchRow("أصوات تيكو", "مؤثرات قصيرة عند التفاعل", TikoKit.soundOn) { TikoKit.chooseSound(it) }
            SwitchRow("نغمة الافتتاح", "الصوت القصير عند فتح التطبيق", AppPrefs.introSound) { AppPrefs.updateIntroSound(it) }
            SwitchRow("إبقاء الشاشة مضاءة", "أثناء فتح شاشة التشغيل (مفيد مع الكلمات)", AppPrefs.keepOn) { AppPrefs.updateKeepOn(it) }
            Label("التبويب الذي يفتح عليه التطبيق")
            GlassSegmented(listOf("الرئيسية", "بحث", "مكتبتي", "التنزيلات"), AppPrefs.startTab.coerceIn(0, 3), { AppPrefs.updateStartTab(it) })
        }

        // الويدجت
        Group("الويدجت", Icons.Rounded.Widgets, 6) {
            Label("شفافية الويدجت")
            Slider(
                wAlpha, { wAlpha = it }, valueRange = 0.2f..1f,
                onValueChangeFinished = {
                    wp.edit().putInt("alpha", (wAlpha * 255).toInt()).apply()
                    PlayerWidget.push(ctx, null); QuranWidget.push(ctx)
                }
            )
        }

        // التحديثات
        Group("التحديثات", Icons.Rounded.SystemUpdate, 7) {
            Text("الإصدار الحالي: ${Updater.LABEL}  (${BuildConfig.VERSION_NAME})", fontWeight = FontWeight.SemiBold)
            if (Updater.status.isNotBlank()) Text(Updater.status, color = TM.Muted, fontSize = 12.sp)
            if (Updater.progress >= 0f || Updater.busy) UpdateProgressBar(Updater.progress)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ scope.launch { runCatching { Updater.check(ctx.applicationContext, true) } } }, enabled = !Updater.busy) { Text("تحقّق الآن") }
                if (Updater.available) Button({ scope.launch { runCatching { Updater.apply(ctx.applicationContext) } } }, enabled = !Updater.busy) { Text("حدّث الآن") }
            }
            SwitchRow("التحقق التلقائي من التحديثات", "عند فتح التطبيق، وتظهر لك لافتة «حدّث الآن» في الأسفل", AppPrefs.autoUpdate) { AppPrefs.updateAutoUpdate(it); Updater.schedule(ctx) }
        }

        // البيانات
        Group("البيانات والتخزين", Icons.Rounded.Storage, 8) {
            if (Cloud.ready(ctx) && Cloud.signedIn) ActionRow(Icons.Rounded.CloudUpload, "نسخ احتياطي الآن", "حفظ المفضلة والألبومات والإعدادات") {
                scope.launch { runCatching { Cloud.backup(ctx.applicationContext, true) }; toast("تم طلب النسخ الاحتياطي") }
            }
            ActionRow(Icons.Rounded.CleaningServices, "مسح الملفات المؤقتة", "ملفات التحديث القديمة وذاكرة الصور") {
                val n = runCatching { ctx.cacheDir.listFiles()?.filter { it.isFile }?.onEach { it.delete() }?.size ?: 0 }.getOrDefault(0)
                toast(if (n > 0) "تم مسح $n ملف" else "لا توجد ملفات مؤقتة")
            }
            ActionRow(Icons.Rounded.Refresh, "إعادة فحص المكتبة", "إن لم تظهر أغانٍ جديدة نسختها للجهاز") { Mp3Dl.refreshLibrary(); toast("جاري تحديث المكتبة") }
        }

        // حول
        Group("حول التطبيق", Icons.Rounded.Info, 9) {
            Text("T Music · ${Updater.LABEL}", fontWeight = FontWeight.SemiBold)
            Text("مشغّل موسيقى وقرآن وتنزيلات، يعمل بدون إعلانات.", color = TM.Muted, fontSize = 12.sp)
        }
    }
}
