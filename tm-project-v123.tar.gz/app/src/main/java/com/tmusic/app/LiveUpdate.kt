package com.tmusic.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player

/**
 * إشعار «Live Update» ثانٍ يظهر كشريحة (كبسولة) في شريط الحالة أثناء التشغيل.
 * إشعار الوسائط (MediaStyle) لا يمكن ترقيته في أندرويد 16، لذلك ننشر إشعارًا عاديًا مستمرًا
 * (بدون MediaStyle وبدون تلوين) ونطلب ترقيته. يُحذف عند الإيقاف المؤقت أو إيقاف الخدمة.
 */
class LiveUpdateNotifier(private val ctx: Context, private val player: Player) : Player.Listener {
    private val nm = NotificationManagerCompat.from(ctx)
    private var lastKey = ""

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            val sys = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (sys.getNotificationChannel(CH) == null) {
                val ch = NotificationChannel(CH, "شريحة التشغيل (شريط الحالة)", NotificationManager.IMPORTANCE_LOW)
                ch.setShowBadge(false)
                sys.createNotificationChannel(ch)
            }
        }
        player.addListener(this)
        refresh()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()
    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refresh()
    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refresh()

    fun release() {
        player.removeListener(this)
        runCatching { nm.cancel(ID) }
        lastKey = ""
    }

    private fun refresh() {
        runCatching {
            if (!player.isPlaying || !NowBar.notifOk(ctx)) {
                if (lastKey.isNotEmpty()) { nm.cancel(ID); lastKey = "" }
                return
            }
            val md = player.mediaMetadata
            val title = md.title?.toString().orEmpty().ifBlank { "T Music" }
            val artist = md.artist?.toString().orEmpty()
            val key = "$title|$artist"
            if (key == lastKey) return
            lastKey = key

            val art = ArtLoader.load(ctx, md, 160)
            val color = ArtLoader.accent(art)
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat_tmusic)
                .setContentTitle(title)
                .setContentText(artist.ifBlank { "يُشغَّل الآن" })
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(open)
                .setColor(color)           // لون الأيقونة فقط (بدون setColorized لأنه يمنع الترقية)
            if (art != null) b.setLargeIcon(art)

            val x = Bundle()
            // أندرويد 16+: طلب الترقية إلى Live Update + نص قصير يظهر داخل الشريحة
            x.putBoolean("android.requestPromotedOngoing", true)
            x.putString("android.shortCriticalText", title.take(10))
            // سامسونج One UI 7/8: النشاط الجاري (شريحة + Now Bar)
            x.putInt("android.ongoingActivityNoti.style", 1)
            x.putString("android.ongoingActivityNoti.primaryInfo", title)
            x.putString("android.ongoingActivityNoti.secondaryInfo", artist)
            x.putString("android.ongoingActivityNoti.nowbarPrimaryInfo", title)
            x.putString("android.ongoingActivityNoti.nowbarSecondaryInfo", artist)
            x.putString("android.ongoingActivityNoti.chipExpandedText", title)
            x.putInt("android.ongoingActivityNoti.chipBgColor", color)
            runCatching { x.putParcelable("android.ongoingActivityNoti.chipIcon", Icon.createWithResource(ctx, R.drawable.ic_stat_tmusic)) }
            x.putString("android.substName", "T Music")
            b.addExtras(x)

            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < 33)
                nm.notify(ID, b.build())
        }
    }

    companion object {
        private const val CH = "tm_live_chip"
        private const val ID = 7701
    }
}
