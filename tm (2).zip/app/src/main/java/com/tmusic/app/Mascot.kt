package com.tmusic.app

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * «تيكو»: مرافق T Music. شخصية ثلاثية الأبعاد مُصيَّرة مسبقًا (شيتات إطارات شفافة في res/drawable-nodpi/tk_*.webp).
 * كل شيت 6×4 إطارًا بحجم 320 بكسل. الحركات: idle هادئ، music يرقص مع الإيقاع، tap ردّة فعل عند اللمس،
 * sleep نائم، alert متحمّس (تحديث/تنزيل).
 */
enum class Tk(val key: String, val fps: Int, val loop: Boolean) {
    Idle("idle", 12, true),
    Music("music", 24, true),
    Tap("tap", 24, false),
    Sleep("sleep", 8, true),
    Alert("alert", 24, true)
}

object TikoSprites {
    const val COLS = 6
    const val FRAMES = 24
    const val SIZE = 320

    // نحتفظ بثلاثة شيتات فقط في الذاكرة (كل واحد ~10MB) والأقدم يُهمَل تلقائيًا.
    private val cache = object : LinkedHashMap<String, ImageBitmap>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ImageBitmap>?): Boolean = size > 3
    }

    @Synchronized fun peek(k: String): ImageBitmap? = cache[k]

    private fun resId(k: String): Int = when (k) {
        "idle" -> R.drawable.tk_idle
        "music" -> R.drawable.tk_music
        "tap" -> R.drawable.tk_tap
        "sleep" -> R.drawable.tk_sleep
        else -> R.drawable.tk_alert
    }

    suspend fun load(ctx: Context, k: String): ImageBitmap? {
        peek(k)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                val o = BitmapFactory.Options().apply { inScaled = false }
                BitmapFactory.decodeResource(ctx.resources, resId(k), o)?.asImageBitmap()
            }.getOrNull()
        } ?: return null
        synchronized(this) { cache[k] = bmp }
        return bmp
    }
}

/** يرسم إطار الحركة الحالي. onDone يُستدعى عند انتهاء الحركات غير المتكررة (tap). */
@Composable
fun Tiko(anim: Tk, modifier: Modifier = Modifier, onDone: () -> Unit = {}) {
    val ctx = LocalContext.current.applicationContext
    var sheet by remember { mutableStateOf(TikoSprites.peek(anim.key)) }
    LaunchedEffect(anim) { sheet = TikoSprites.peek(anim.key) ?: TikoSprites.load(ctx, anim.key) ?: sheet }
    val frame = remember { mutableIntStateOf(0) }
    val done by rememberUpdatedState(onDone)
    LaunchedEffect(anim, sheet) {
        if (sheet == null) return@LaunchedEffect
        frame.intValue = 0
        val t0 = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            val f = ((now - t0) * anim.fps / 1_000_000_000L).toInt()
            if (!anim.loop && f >= TikoSprites.FRAMES) { done(); break }
            frame.intValue = f % TikoSprites.FRAMES
        }
    }
    Canvas(modifier) {
        val sh = sheet ?: return@Canvas
        val f = frame.intValue
        drawImage(
            sh,
            srcOffset = IntOffset((f % TikoSprites.COLS) * TikoSprites.SIZE, (f / TikoSprites.COLS) * TikoSprites.SIZE),
            srcSize = IntSize(TikoSprites.SIZE, TikoSprites.SIZE),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.High
        )
    }
}

private class TikoTask(val label: String, val icon: ImageVector, val run: () -> String)

/** فقاعة كلام بذيل يشير إلى تيكو. */
@Composable
private fun Bubble(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val fill = TM.Raised
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.width(9.dp).height(16.dp)) {
            val p = Path()
            if (rtl) { p.moveTo(0f, 0f); p.lineTo(size.width, size.height / 2); p.lineTo(0f, size.height) }
            else { p.moveTo(size.width, 0f); p.lineTo(0f, size.height / 2); p.lineTo(size.width, size.height) }
            p.close()
            drawPath(p, fill)
        }
        Box(Modifier.weight(1f, fill = false).clip(RoundedCornerShape(18.dp)).background(fill).padding(horizontal = 14.dp, vertical = 11.dp)) { content() }
    }
}

/**
 * رأس الصفحة الرئيسية: تيكو يرحّب بك بالاسم ويتفاعل.
 * مهامه: ترحيب حسب الوقت، يرقص مع الأغنية الحالية، يستلم أخبار التحديثات (بدل الشريط القديم)، يراقب التنزيلات،
 * يعلّق على ذوقك (أكثر أغنية)، وعند الضغط يفتح لك اختصارات: مفاجأة، أكمل، اقتراح اليوم، ألبوم لك، الأكثر استماعًا.
 * الضغط المطوّل = مفاجأة فورية.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TikoHero(songs: List<Song>, albums: List<Album>, byId: Map<Long, Song>, ui: PlayerUi, onAccount: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = when { hour < 5 -> "ليلة هادئة"; hour < 12 -> "صباح الخير"; hour < 18 -> "طاب يومك"; else -> "مساء الخير" }
    val name = Profile.name
    val hello = if (name.isNotBlank()) "$greet يا $name" else greet

    var reaction by remember { mutableStateOf(false) }
    var lineIdx by remember { mutableIntStateOf(0) }
    var custom by remember { mutableStateOf<String?>(null) }
    var showTasks by remember { mutableStateOf(false) }
    var sleepy by remember { mutableStateOf(false) }
    var lastTouch by remember { mutableLongStateOf(0L) }

    val update = Updater.available && !Updater.dismissed
    val anim = when {
        reaction -> Tk.Tap
        update -> Tk.Alert
        Mp3Dl.busy -> Tk.Alert
        ui.isPlaying -> Tk.Music
        sleepy -> Tk.Sleep
        else -> Tk.Idle
    }

    // ينام بعد 45 ثانية من الهدوء ويستيقظ باللمس أو عند تشغيل أغنية
    LaunchedEffect(lastTouch, ui.isPlaying, update) {
        sleepy = false
        if (!ui.isPlaying && !update) { delay(45_000); sleepy = true }
    }
    LaunchedEffect(custom) { if (custom != null) { delay(5200); custom = null } }
    LaunchedEffect(showTasks) { if (showTasks) { delay(12_000); showTasks = false } }

    // رسائل متناوبة حسب الحال
    val lines = remember(hello, ui.isPlaying, ui.currentId, songs.size, ui.plays) {
        buildList {
            add("$hello 👋")
            if (ui.isPlaying) {
                byId[ui.currentId]?.let { add("أسمع معك «${it.title}» 🎧") }
                add("الإيقاع حلو.. صح؟ 🎶")
            } else {
                add("اضغط عليّ وأقترح لك شيئًا يناسب مزاجك")
                add("اضغط مطوّلًا وأفاجئك بأغنية 🎲")
            }
            add("في مكتبتك ${songs.size} أغنية جاهزة")
            val top = songs.maxByOrNull { ui.plays[it.id] ?: 0 }
            if (top != null && (ui.plays[top.id] ?: 0) > 1) add("أكثر أغنية كررتها: «${top.title}» 🔁")
            val total = ui.plays.values.sum()
            if (total > 0) add("سمعنا معًا $total تشغيلة حتى الآن 📈")
            if (hour < 5 || hour >= 23) add("الوقت متأخر.. أغنية هادئة قبل النوم؟ 🌙")
        }
    }
    LaunchedEffect(lines.size) { while (true) { delay(6500); lineIdx++ } }

    // التنزيلات: عند اكتمال حفظ أغنية يفرح
    val savedBase = remember { Mp3Dl.savedCount }
    LaunchedEffect(Mp3Dl.savedCount) {
        if (Mp3Dl.savedCount > savedBase) { custom = "تم! حفظت لك الأغنية في مكتبتك 🎉"; reaction = true }
    }

    fun touch() { lastTouch = System.currentTimeMillis() }

    val tasks = remember(songs, albums, byId, ui.recents, ui.plays) {
        listOf(
            TikoTask("فاجئني", Icons.Rounded.Shuffle) {
                val i = songs.indices.random(); ui.play(songs, i, true); "اخترت لك «${songs[i].title}» 🎲"
            },
            TikoTask("أكمل من حيث توقفت", Icons.Rounded.PlayArrow) {
                val last = ui.recents.firstNotNullOfOrNull { byId[it] }
                if (last == null) { val i = songs.indices.random(); ui.play(songs, i); "لا يوجد سجل بعد، ابدأ بـ«${songs[i].title}»" }
                else { ui.play(songs, songs.indexOfFirst { it.id == last.id }.coerceAtLeast(0)); "نكمل مع «${last.title}» ▶️" }
            },
            TikoTask("اقتراح اليوم", Icons.Rounded.AutoAwesome) {
                val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                val d = songs.shuffled(java.util.Random(day.toLong() * 7919L)).take(12)
                ui.play(d, 0, false); "اقتراحي لك اليوم: «${d.first().title}» ✨"
            },
            TikoTask("ألبوم لك", Icons.Rounded.Album) {
                if (albums.isEmpty()) "لا توجد ألبومات بعد"
                else { val a = albums.random(); ui.play(a.songs, 0, false); "جرّب ألبوم «${a.name}» 💿" }
            },
            TikoTask("الأكثر استماعًا", Icons.Rounded.TrendingUp) {
                val top = songs.filter { (ui.plays[it.id] ?: 0) > 0 }.sortedByDescending { ui.plays[it.id] ?: 0 }.take(30)
                if (top.isEmpty()) "اسمع أكثر قليلًا وأعرف ذوقك 😉" else { ui.play(top, 0, false); "قائمة أكثر ما سمعته 🔥" }
            }
        )
    }

    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "tikoPress")

    Column(Modifier.fadeUp(0).fillMaxWidth().padding(top = 6.dp, bottom = 4.dp)) {
        Box(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(158.dp).graphicsLayer { scaleX = press; scaleY = press }
                        .combinedClickable(
                            interactionSource = interaction, indication = null,
                            onClick = {
                                touch(); reaction = true; showTasks = !showTasks
                                custom = if (showTasks) "ماذا تحب أن أفعل لك؟" else null
                            },
                            onLongClick = {
                                touch(); haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                reaction = true
                                if (songs.isNotEmpty()) { val i = songs.indices.random(); ui.play(songs, i, true); custom = "مفاجأة! «${songs[i].title}» 🎲" }
                            }
                        )
                ) {
                    Canvas(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).width(84.dp).height(14.dp)) {
                        drawOval(Brush.radialGradient(listOf(Color.Black.copy(0.55f), Color.Transparent), center = center, radius = size.width / 2f), Offset.Zero, size)
                    }
                    Tiko(anim, Modifier.fillMaxSize(), onDone = { reaction = false })
                    if (anim == Tk.Sleep) {
                        val a by rememberInfiniteTransition(label = "z").animateFloat(0.25f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse), label = "za")
                        Text("z Z", Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 10.dp).graphicsLayer { alpha = a }, color = TM.Muted, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.width(2.dp))
                Bubble(Modifier.weight(1f).padding(end = 40.dp)) {
                    if (update) {
                        Column {
                            Text("وصلني تحديث جديد 🎁", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                if (Updater.progress >= 0f) "أنزّله لك الآن… ${(Updater.progress * 100).toInt()}%"
                                else if (Updater.busy) "أجهّز التحديث لك…" else "${Updater.LABEL} جاهز، لمسة واحدة وأحدّث لك التطبيق",
                                color = TM.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)
                            )
                            if (Updater.progress >= 0f || Updater.busy) UpdateProgressBar(Updater.progress, Modifier.padding(top = 8.dp))
                            else Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { Updater.scope.launch { Updater.apply(ctx) } }) { Text("حدّث الآن") }
                                TextButton(onClick = { Updater.dismissed = true }) { Text("لاحقًا", color = TM.Muted) }
                            }
                        }
                    } else {
                        val msg = custom
                            ?: if (Mp3Dl.busy) "أنزّل لك الأغنية… ${(Mp3Dl.progress * 100).toInt()}% ⬇️"
                            else lines[lineIdx % lines.size]
                        Crossfade(msg, animationSpec = tween(350), label = "tikoLine") {
                            Text(it, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }
            }
            IconButton(onClick = onAccount, Modifier.align(Alignment.TopEnd)) {
                if (Cloud.signedIn) ProfileAvatar(34.dp)
                else Icon(Icons.Rounded.AccountCircle, "الحساب", Modifier.size(32.dp), tint = TM.Muted)
            }
        }
        AnimatedVisibility(showTasks, enter = fadeIn(tween(250)) + expandVertically(), exit = fadeOut(tween(200)) + shrinkVertically()) {
            LazyRow(Modifier.padding(top = 6.dp), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks) { t ->
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(TM.Raised)
                            .bounceClick(0.94f) {
                                touch(); reaction = true
                                custom = runCatching { t.run() }.getOrDefault("حدث خطأ بسيط، جرّب مرة ثانية")
                                showTasks = false
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(t.icon, null, Modifier.size(18.dp), tint = TM.VioletSoft)
                        Spacer(Modifier.width(6.dp))
                        Text(t.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
