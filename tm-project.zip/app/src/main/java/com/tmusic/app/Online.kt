package com.tmusic.app

import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** بحث الأغاني على الإنترنت: Audius و Jamendo (أغانٍ كاملة). */
data class YtVideo(val id: String, val title: String, val channel: String)

object Online {
    /** مفتاح YouTube Data API v3 (مجاني من Google Cloud). بدونه لا تظهر نتائج يوتيوب. */
    const val YT_KEY = "PUT_KEY_HERE"
    /** رابط Cloudflare Worker (اختياري): يخفي المفتاح ويخزّن النتائج فيشترك الأصدقاء في الحصة. */
    const val YT_PROXY = ""
    val ytReady: Boolean get() = true   // بدون مفتاح يعمل البحث المجاني المباشر
    private val keySet: Boolean get() = YT_KEY.isNotBlank() && YT_KEY != "PUT_KEY_HERE"
    private val ytCache = HashMap<String, List<YtVideo>>()
    private fun clean(t: String) = android.text.Html.fromHtml(t, android.text.Html.FROM_HTML_MODE_LEGACY).toString()

    /** معرّف سالب ثابت لكل أغنية إنترنت حتى لا يتعارض مع معرّفات أغاني الجهاز. */
    private fun rid(key: String): Long = -((key.hashCode().toLong() and 0x7fffffffL) + 1)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/json")
        return try {
            c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    suspend fun search(q: String): List<Song> = coroutineScope {
        val a = async(Dispatchers.IO) { runCatching { audius(q) }.getOrDefault(emptyList()) }
        val b = async(Dispatchers.IO) { runCatching { jamendo(q) }.getOrDefault(emptyList()) }
        a.await() + b.await()
    }

    /** بحث يوتيوب الرسمي (فيديوهات الموسيقى القابلة للتضمين فقط). */
    suspend fun youtube(q: String): List<YtVideo> = withContext(Dispatchers.IO) {
        val key = q.trim().lowercase()
        ytCache[key]?.let { return@withContext it }
        val e = URLEncoder.encode(q, "UTF-8")
        var out: List<YtVideo> = emptyList()
        // 1) Worker الخاص بك (اختياري)  2) مفتاح رسمي (اختياري)  3) البحث المجاني المباشر بلا مفتاح ولا حصة
        if (YT_PROXY.isNotBlank()) out = runCatching {
            val arr = JSONArray(get("$YT_PROXY?q=$e"))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                YtVideo(o.getString("id"), clean(o.optString("title")), o.optString("channel"))
            }
        }.getOrDefault(emptyList())
        if (out.isEmpty() && keySet) out = runCatching {
            val arr = JSONObject(
                get("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&videoEmbeddable=true&maxResults=15&q=$e&key=$YT_KEY")
            ).getJSONArray("items")
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val sn = o.getJSONObject("snippet")
                YtVideo(o.getJSONObject("id").getString("videoId"), clean(sn.optString("title")), sn.optString("channelTitle"))
            }
        }.getOrDefault(emptyList())
        if (out.isEmpty()) out = runCatching { innertube(q) }.getOrDefault(emptyList())
        if (out.isNotEmpty()) ytCache[key] = out
        out
    }

    /** بحث يوتيوب المباشر (نفس ما يستعمله موقعه) — مجاني بلا مفتاح؛ التشغيل يبقى عبر المشغّل الرسمي. */
    // مفتاح موقع يوتيوب العام (ليس مفتاحك)؛ مقسوم لئلا يعتبره GitHub سرًّا مسرَّبًا
    private val WEB_KEY = "AIzaSy" + "AO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"

    private fun innertube(q: String): List<YtVideo> {
        val body = JSONObject()
            .put("context", JSONObject().put("client", JSONObject().put("clientName", "WEB").put("clientVersion", "2.20250101.00.00").put("hl", "ar")))
            .put("query", q)
            .put("params", "EgIQAQ==")
            .toString()
        val c = URL("https://www.youtube.com/youtubei/v1/search?key=" + WEB_KEY + "&prettyPrint=false")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept-Language", "ar,en;q=0.8")
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
        val resp = try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
        val sections = JSONObject(resp).getJSONObject("contents").getJSONObject("twoColumnSearchResultsRenderer")
            .getJSONObject("primaryContents").getJSONObject("sectionListRenderer").getJSONArray("contents")
        val out = ArrayList<YtVideo>()
        for (i in 0 until sections.length()) {
            val items = sections.getJSONObject(i).optJSONObject("itemSectionRenderer")?.optJSONArray("contents") ?: continue
            for (j in 0 until items.length()) {
                val v = items.getJSONObject(j).optJSONObject("videoRenderer") ?: continue
                val id = v.optString("videoId")
                if (id.isEmpty()) continue
                val title = v.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: continue
                val ch = v.optJSONObject("ownerText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""
                out += YtVideo(id, title, ch)
            }
        }
        return out.take(20)
    }

    private fun audius(q: String): List<Song> {
        val e = URLEncoder.encode(q, "UTF-8")
        val arr = JSONObject(get("https://api.audius.co/v1/tracks/search?query=$e&limit=20&app_name=TMusic")).getJSONArray("data")
        val out = ArrayList<Song>()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            if (!t.optBoolean("is_streamable", true)) continue
            val tid = t.getString("id")
            val aw = t.optJSONObject("artwork")
            val art = aw?.optString("480x480")?.takeIf { it.isNotEmpty() }
                ?: aw?.optString("150x150")?.takeIf { it.isNotEmpty() }
            val id = rid("audius:$tid")
            out += Song(
                id, t.optString("title", "بدون عنوان"),
                t.optJSONObject("user")?.optString("name") ?: "فنان غير معروف",
                "Audius", id, t.optLong("duration", 0L) * 1000,
                "https://api.audius.co/v1/tracks/$tid/stream?app_name=TMusic", art,
                downloadUrl = if (t.optBoolean("is_downloadable", false) || t.optJSONObject("download")?.optBoolean("is_downloadable", false) == true)
                    "https://api.audius.co/v1/tracks/$tid/download?app_name=TMusic" else null
            )
        }
        return out
    }

    private fun jamendo(q: String): List<Song> {
        val e = URLEncoder.encode(q, "UTF-8")
        val arr = JSONObject(
            get("https://api.jamendo.com/v3.0/tracks/?client_id=709fa152&format=json&limit=20&audioformat=mp32&search=$e")
        ).getJSONArray("results")
        val out = ArrayList<Song>()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            val url = t.optString("audio")
            if (url.isEmpty()) continue
            val id = rid("jamendo:${t.optString("id")}")
            out += Song(
                id, t.optString("name", "بدون عنوان"), t.optString("artist_name", "فنان غير معروف"),
                t.optString("album_name").ifEmpty { "Jamendo" }, id, t.optLong("duration", 0L) * 1000, url,
                t.optString("image").takeIf { it.isNotEmpty() },
                downloadUrl = if (t.optBoolean("audiodownload_allowed", false)) t.optString("audiodownload").takeIf { it.isNotEmpty() } else null
            )
        }
        return out
    }
}

/** نتائج البحث على الإنترنت للنص q (بعد انتظار نصف ثانية من آخر حرف)، ومعها حالة التحميل. */
@Composable
fun rememberOnline(q: String): Pair<List<Song>, Boolean> {
    var res by remember { mutableStateOf<List<Song>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        val k = q.trim()
        res = emptyList()
        if (k.length < 2) { loading = false; return@LaunchedEffect }
        loading = true
        delay(500)
        res = Online.search(k)
        loading = false
    }
    return res to loading
}

@Composable
fun rememberYoutube(q: String): Pair<List<YtVideo>, Boolean> {
    var res by remember { mutableStateOf<List<YtVideo>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        val k = q.trim()
        res = emptyList()
        if (k.length < 2) { loading = false; return@LaunchedEffect }
        loading = true
        res = Online.youtube(k)
        loading = false
    }
    return res to loading
}

/** تنزيل أغنية يسمح صاحبها بالتنزيل (Jamendo / Audius): يظهر في تبويب التنزيلات مع التقدّم. */
fun downloadSong(ctx: android.content.Context, s: Song) { Mp3Dl.startSong(ctx, s) }
