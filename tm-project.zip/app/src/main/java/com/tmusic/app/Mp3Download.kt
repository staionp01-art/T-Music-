package com.tmusic.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** عنصر تنزيل واحد يظهر في تبويب «التنزيلات». */
class DlItem(val id: Long, val url: String?, val song: Song? = null) {
    var title by mutableStateOf(song?.title ?: "جاري التجهيز…")
    var artist by mutableStateOf(song?.artist ?: "")
    var art by mutableStateOf<Bitmap?>(null)
    var artUrl by mutableStateOf<String?>(song?.artUrl)
    var progress by mutableFloatStateOf(-1f)
    var state by mutableIntStateOf(0)          // 0 انتظار، 1 جارٍ، 2 تم، 3 فشل، 4 أُلغي
    var note by mutableStateOf("")
    var startedAt by mutableLongStateOf(0L)
    var elapsedMs by mutableLongStateOf(0L)    // مدة التحميل بعد الانتهاء
    var sizeBytes by mutableLongStateOf(0L)
    var etaSec by mutableIntStateOf(-1)
    var savedUri: Uri? = null
    var savedPath: String? = null
}

/**
 * تنزيل MP3 عبر yt-dlp + ffmpeg (رابط)، أو تنزيل مباشر لأغاني Jamendo/Audius.
 * كل تنزيل يُحفظ في Music/TMusic ومعه الفنان والعنوان والغلاف داخل الملف نفسه،
 * ويظهر في تبويب التنزيلات مع التقدّم والوقت المتبقي وزرّ الإلغاء والحذف.
 */
object Mp3Dl {
    val items = mutableStateListOf<DlItem>()
    var status by mutableStateOf(""); private set
    var savedCount by mutableIntStateOf(0); private set

    val busy: Boolean get() = items.any { it.state == 1 }
    val progress: Float get() = items.firstOrNull { it.state == 1 }?.progress ?: 0f
    val activeCount: Int get() = items.count { it.state == 0 || it.state == 1 }

    private var ready = false
    private var nextId = 1L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var current: DlItem? = null
    private const val PID = "tm-mp3"
    private const val CH = "tm_downloads"

    fun start(ctx: Context, url: String) {
        val app = ctx.applicationContext
        val it = DlItem(nextId++, url)
        val wait = busy
        items.add(0, it)
        if (wait) android.widget.Toast.makeText(app, "أُضيف إلى طابور التنزيل", android.widget.Toast.LENGTH_SHORT).show()
        pump(app)
    }

    fun startSong(ctx: Context, s: Song) {
        val app = ctx.applicationContext
        if (s.downloadUrl == null) return
        items.add(0, DlItem(nextId++, null, s))
        android.widget.Toast.makeText(app, "أُضيف إلى التنزيلات", android.widget.Toast.LENGTH_SHORT).show()
        pump(app)
    }

    fun retry(ctx: Context, d: DlItem) {
        items.remove(d)
        if (d.song != null) startSong(ctx, d.song) else d.url?.let { start(ctx, it) }
    }

    private fun pump(app: Context) {
        if (job?.isActive == true) return
        val d = items.lastOrNull { it.state == 0 } ?: return
        current = d; d.state = 1; d.startedAt = System.currentTimeMillis(); d.progress = -1f
        val tmp = File(app.cacheDir, "mp3dl/${d.id}")
        job = scope.launch {
            try {
                status = "جاري التنزيل…"
                if (d.song != null) direct(app, d, tmp) else ytdl(app, d, tmp)
                d.elapsedMs = System.currentTimeMillis() - d.startedAt
                d.progress = 1f; d.state = 2; d.note = ""
                savedCount++
                status = "تم! حُفظ في Music/TMusic: " + d.title
                notifyDone(app, d, true)
            } catch (e: CancellationException) {
                d.state = 4; d.note = "أُلغي التنزيل"; status = "أُلغي التنزيل"
                notifyClear(app)
                throw e
            } catch (t: Throwable) {
                d.state = 3; d.note = "فشل التنزيل: " + (t.message ?: t.javaClass.simpleName).take(160)
                status = d.note
                notifyDone(app, d, false)
            } finally {
                runCatching { tmp.deleteRecursively() }
                current = null; job = null
                pump(app)
            }
        }
    }

    private suspend fun ytdl(app: Context, d: DlItem, tmp: File) {
        if (!ready) {
            d.note = "تجهيز أدوات التنزيل (أول مرة فقط)…"
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            ready = true
            runCatching { YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE) }
            d.note = ""
        }
        tmp.deleteRecursively(); tmp.mkdirs()
        // اسم الأغنية والفنان والغلاف قبل التنزيل ليظهروا في القائمة فورًا
        runCatching {
            val info = YoutubeDL.getInstance().getInfo(YoutubeDLRequest(d.url!!).apply { addOption("--no-playlist") })
            info.title?.let { d.title = it }
            info.uploader?.let { d.artist = it }
            d.artUrl = info.thumbnail
        }
        d.artUrl?.let { u -> runCatching { d.art = Art.remote(u) } }
        val req = YoutubeDLRequest(d.url!!).apply {
            addOption("--no-playlist")
            addOption("-f", "bestaudio/best")
            addOption("-x")
            addOption("--audio-format", "mp3")
            addOption("--audio-quality", "320K")
            addOption("--embed-metadata")          // العنوان والفنان داخل الملف
            addOption("--embed-thumbnail")         // الغلاف داخل الملف
            addOption("--convert-thumbnails", "jpg")
            addOption("-o", tmp.absolutePath + "/%(title).150B.%(ext)s")
        }
        YoutubeDL.getInstance().execute(req, PID) { p, eta, _ ->
            d.progress = if (p >= 0f) p / 100f else -1f
            d.etaSec = eta.toInt()
            d.note = if (p >= 100f) "جاري التحويل إلى MP3…" else ""
            updateNotif(app, d)
        }
        val f = tmp.listFiles()?.firstOrNull { it.extension.equals("mp3", true) } ?: error("لم يُنتج ملف MP3")
        finish(app, d, f)
    }

    private suspend fun direct(app: Context, d: DlItem, tmp: File) {
        val s = d.song!!
        tmp.deleteRecursively(); tmp.mkdirs()
        val name = ("${s.artist} - ${s.title}").replace(Regex("""[\\/:*?"<>|]"""), "_") + ".mp3"
        val out = File(tmp, name)
        s.artUrl?.let { u -> runCatching { d.art = Art.remote(u) } }
        val c = URL(s.downloadUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
        try {
            val total = c.contentLengthLong
            c.inputStream.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(32 * 1024); var done = 0L; var n: Int
                    val t0 = System.currentTimeMillis(); var lastUi = 0L
                    while (ins.read(buf).also { n = it } >= 0) {
                        currentCoroutineContext().ensureActive()
                        os.write(buf, 0, n); done += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 250) {
                            lastUi = now
                            if (total > 0) {
                                d.progress = done.toFloat() / total
                                val speed = done / ((now - t0).coerceAtLeast(1) / 1000f)
                                d.etaSec = ((total - done) / speed.coerceAtLeast(1f)).toInt()
                            }
                            updateNotif(app, d)
                        }
                    }
                }
            }
        } finally { c.disconnect() }
        finish(app, d, out, s)
    }

    /** يقرأ الوسوم من الملف النهائي، يحدّث العنصر، ويحفظه في الموسيقى مع الوسوم في MediaStore. */
    private fun finish(app: Context, d: DlItem, f: File, song: Song? = null) {
        var title = song?.title ?: f.nameWithoutExtension
        var artist = song?.artist.orEmpty()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }?.let { artist = it }
            r.embeddedPicture?.let { b ->
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)?.let { d.art = it }
            }
        } catch (_: Throwable) {} finally { runCatching { r.release() } }
        if (artist.isBlank()) artist = d.artist
        d.title = title; d.artist = artist; d.sizeBytes = f.length()
        saveToMusic(app, d, f, title, artist)
    }

    fun cancel(d: DlItem) {
        if (d.state == 0) { d.state = 4; d.note = "أُلغي"; return }
        if (d.state == 1) {
            runCatching { YoutubeDL.getInstance().destroyProcessById(PID) }
            job?.cancel()
        }
    }

    fun cancel() { items.toList().forEach { cancel(it) } }

    /** يحذف الأغنية من الهاتف (إن كانت محفوظة) ويزيلها من القائمة. */
    fun delete(app: Context, d: DlItem) {
        if (d.state == 0 || d.state == 1) cancel(d)
        scope.launch {
            runCatching { d.savedUri?.let { app.contentResolver.delete(it, null, null) } }
            runCatching { d.savedPath?.let { File(it).delete() } }
            items.remove(d)
            if (d.savedUri != null || d.savedPath != null) savedCount++   // لتحديث المكتبة
        }
    }

    fun refreshLibrary() { savedCount++ }

    fun clearFinished() { items.removeAll { it.state >= 3 } }

    private fun saveToMusic(ctx: Context, d: DlItem, f: File, title: String, artist: String) {
        val album = artist.ifBlank { "TMusic" }
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, f.name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/TMusic")
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.ARTIST, album)
                put(MediaStore.Audio.Media.ALBUM, album)
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv) ?: error("تعذّر إنشاء الملف في الموسيقى")
            ctx.contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            cv.clear(); cv.put(MediaStore.Audio.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, cv, null, null)
            d.savedUri = uri
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "TMusic").apply { mkdirs() }
            val out = File(dir, f.name)
            f.copyTo(out, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), null, null)
            d.savedPath = out.absolutePath
        }
    }

    // ---------- إشعارات ----------
    private fun nm(ctx: Context): NotificationManager {
        val m = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && m.getNotificationChannel(CH) == null)
            m.createNotificationChannel(NotificationChannel(CH, "التنزيلات", NotificationManager.IMPORTANCE_LOW))
        return m
    }

    private fun updateNotif(ctx: Context, d: DlItem) {
        runCatching {
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(d.title).setContentText(d.artist.ifBlank { "جاري التنزيل…" })
                .setOngoing(true).setOnlyAlertOnce(true)
                .setProgress(100, (d.progress.coerceAtLeast(0f) * 100).toInt(), d.progress < 0f)
            nm(ctx).notify(7001, b.build())
        }
    }

    private fun notifyDone(ctx: Context, d: DlItem, ok: Boolean) {
        runCatching {
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
                .setContentTitle(if (ok) "اكتمل التنزيل" else "فشل التنزيل")
                .setContentText(d.title).setAutoCancel(true)
            nm(ctx).notify(7001, b.build())
        }
    }

    private fun notifyClear(ctx: Context) { runCatching { nm(ctx).cancel(7001) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Mp3Sheet(onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val t = clip.getText()?.text?.trim().orEmpty()
        if (t.startsWith("http")) url = t
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("تنزيل MP3 من رابط", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text("الصق رابط الفيديو أو الأغنية. نزّل فقط ما يحق لك تنزيله.", color = TM.Muted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true, enabled = !Mp3Dl.busy,
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://…") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Uri),
                trailingIcon = {
                    IconButton({ clip.getText()?.text?.let { url = it.trim() } }) { Icon(Icons.Rounded.ContentPaste, null) }
                }
            )
            Spacer(Modifier.height(12.dp))
            if (Mp3Dl.busy) {
                if (Mp3Dl.progress < 0f) LinearProgressIndicator(Modifier.fillMaxWidth(), color = TM.Violet)
                else LinearProgressIndicator(progress = { Mp3Dl.progress }, modifier = Modifier.fillMaxWidth(), color = TM.Violet)
                Spacer(Modifier.height(8.dp))
            }
            if (Mp3Dl.status.isNotBlank()) Text(Mp3Dl.status, fontWeight = FontWeight.SemiBold, color = if (Mp3Dl.status.startsWith("فشل")) TM.Muted else TM.VioletSoft)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { Mp3Dl.start(ctx, url.trim()) },
                    enabled = !Mp3Dl.busy && url.trim().startsWith("http"),
                    modifier = Modifier.weight(1f)
                ) { Text("تنزيل MP3") }
                if (Mp3Dl.busy) OutlinedButton({ Mp3Dl.cancel() }) { Text("إلغاء") }
            }
        }
    }
}
