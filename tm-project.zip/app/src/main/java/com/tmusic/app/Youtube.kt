package com.tmusic.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun YtRow(v: YtVideo, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val thumb by produceState<Bitmap?>(null, v.id) { value = Art.remote("https://i.ytimg.com/vi/${v.id}/mqdefault.jpg") }
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB3261E), Color(0xFF4A0F0C)))),
            contentAlignment = Alignment.Center
        ) {
            val t = thumb
            if (t != null) Image(t.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.PlayArrow, null, tint = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(v.channel, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = TM.Muted)
        }
        val ctx = LocalContext.current
        IconButton({
            Mp3Dl.start(ctx, "https://www.youtube.com/watch?v=${v.id}")
            android.widget.Toast.makeText(ctx, "بدأ تنزيل MP3 …", android.widget.Toast.LENGTH_SHORT).show()
        }) { Icon(Icons.Rounded.Download, null, tint = TM.VioletSoft) }
    }
}

/** تشغيل الأغنية الكاملة عبر مشغّل يوتيوب الرسمي المضمّن (يتوقف عند الإغلاق). */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YoutubeDialog(v: YtVideo, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(TM.Ink).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Rounded.Close, null) }
                Text(v.title, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                val dctx = LocalContext.current
                IconButton({
                    Mp3Dl.start(dctx, "https://www.youtube.com/watch?v=${v.id}")
                    android.widget.Toast.makeText(dctx, "بدأ تنزيل MP3 …", android.widget.Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Rounded.Download, null) }
            }
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        loadUrl(
                            "https://www.youtube.com/embed/${v.id}?autoplay=1&playsinline=1&rel=0",
                            mapOf("Referer" to "https://com.tmusic.app")
                        )
                    }
                },
                onRelease = { it.loadUrl("about:blank"); it.destroy() },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
            Text(
                "يُشغَّل عبر مشغّل يوتيوب الرسمي، ويتوقف عند إغلاق هذه النافذة.",
                color = TM.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)
            )
            val ctx = LocalContext.current
            TextButton(
                { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${v.id}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                Modifier.padding(horizontal = 8.dp)
            ) { Text("إن ظهر خطأ في التشغيل: افتحها في يوتيوب") }
            TextButton(
                { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=${v.id}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                Modifier.padding(horizontal = 8.dp)
            ) { Text("للتشغيل في الخلفية وشاشة القفل: افتحها في YouTube Music") }
        }
    }
}
