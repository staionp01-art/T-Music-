package com.tmusic.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** تحديث تلقائي من GitHub Releases: يتحقق، ينزّل ملف APK، ثم يثبّته عبر PackageInstaller. */
object Updater {
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    val current: Int get() = BuildConfig.VERSION_CODE

    private class Rel(val num: Int, val url: String, val size: Long)

    private fun latest(repo: String): Rel? {
        return try {
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "TMusic")
            c.connectTimeout = 10000; c.readTimeout = 15000
            try {
                if (c.responseCode != 200) return null
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val num = j.optString("tag_name").substringAfterLast('-').toIntOrNull() ?: return null
                val assets = j.optJSONArray("assets") ?: return null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) return Rel(num, a.optString("browser_download_url"), a.optLong("size"))
                }
                null
            } finally { c.disconnect() }
        } catch (e: Exception) { null }
    }

    private fun download(url: String, out: File, onProgress: (Float) -> Unit): Boolean {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "TMusic")
            c.instanceFollowRedirects = true
            c.connectTimeout = 15000; c.readTimeout = 30000
            try {
                if (c.responseCode != 200) return false
                val total = c.contentLengthLong
                val tmp = File(out.parentFile, out.name + ".part")
                var done = 0L
                c.inputStream.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (total > 0) onProgress(done.toFloat() / total)
                        }
                    }
                }
                tmp.renameTo(out)
            } finally { c.disconnect() }
        } catch (e: Exception) { false }
    }

    suspend fun check(ctx: Context, manual: Boolean) {
        if (busy) return
        val repo = BuildConfig.GH_REPO
        if (repo.isBlank()) { if (manual) status = "رابط المستودع غير معروف: ابنِ التطبيق من GitHub Actions"; return }
        val sp = ctx.getSharedPreferences("tm_update", Context.MODE_PRIVATE)
        if (!manual && System.currentTimeMillis() - sp.getLong("last", 0L) < 3 * 3600_000L) return
        busy = true
        try {
            status = "جاري التحقق من التحديثات…"
            val info = withContext(Dispatchers.IO) { latest(repo) }
            sp.edit().putLong("last", System.currentTimeMillis()).apply()
            if (info == null) { status = "تعذّر التحقق من التحديث (تأكد من الإنترنت وأن المستودع عام)"; return }
            if (info.num <= current) { status = "أنت على آخر إصدار (build $current)"; return }
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                status = "اسمح لـ T Music بتثبيت التطبيقات ثم اضغط «تحقق من التحديث»"
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            status = "جاري تنزيل التحديث build ${info.num}…"
            progress = 0f
            val f = File(ctx.cacheDir, "update-${info.num}.apk")
            val ok = withContext(Dispatchers.IO) {
                if (f.exists() && f.length() == info.size) true else download(info.url, f) { progress = it }
            }
            if (!ok) { status = "فشل تنزيل التحديث"; return }
            status = "جاري تثبيت التحديث…"
            withContext(Dispatchers.IO) { install(ctx, f) }
        } catch (e: Exception) {
            status = "تعذّر التحديث: ${e.message}"
        } finally {
            busy = false; progress = -1f
        }
    }

    private fun install(ctx: Context, f: File) {
        val pi = ctx.packageManager.packageInstaller
        val p = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        p.setAppPackageName(ctx.packageName)
        if (Build.VERSION.SDK_INT >= 31) p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = pi.createSession(p)
        pi.openSession(id).use { s ->
            f.inputStream().use { i ->
                s.openWrite("tm.apk", 0, f.length()).use { o -> i.copyTo(o); s.fsync(o) }
            }
            val intent = Intent(ctx, InstallReceiver::class.java).setPackage(ctx.packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
    }
}

class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val c = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (c != null) runCatching { ctx.startActivity(c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            PackageInstaller.STATUS_SUCCESS -> Updater.status = "تم التحديث"
            else -> Updater.status = "فشل التثبيت: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "")
        }
    }
}
