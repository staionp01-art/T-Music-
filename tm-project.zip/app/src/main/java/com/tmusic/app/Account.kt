package com.tmusic.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.gms.tasks.Task
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
    addOnCompleteListener { t ->
        if (t.isSuccessful) c.resume(t.result) else c.resumeWithException(t.exception ?: Exception("failed"))
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** حساب Google + نسخة احتياطية سحابية (Firestore) لمفضلتك وقوائمك وإعداداتك. */
object Cloud {
    var name by mutableStateOf("")
    var email by mutableStateOf("")
    var signedIn by mutableStateOf(false)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    private var lastHash = 0

    private val NAMES = listOf("tm", "tm_albums", "tm_eq", "tm_theme")

    fun ready(ctx: Context) = FirebaseApp.getApps(ctx).isNotEmpty()

    fun refreshUser(ctx: Context) {
        if (!ready(ctx)) return
        val u = FirebaseAuth.getInstance().currentUser
        signedIn = u != null
        name = u?.displayName ?: ""
        email = u?.email ?: ""
    }

    private fun snapshot(ctx: Context): String {
        val root = JSONObject()
        for (n in NAMES) {
            val o = JSONObject()
            for ((k, v) in ctx.getSharedPreferences(n, Context.MODE_PRIVATE).all) {
                val e = JSONObject()
                when (v) {
                    is Boolean -> { e.put("t", "b"); e.put("v", v) }
                    is Int -> { e.put("t", "i"); e.put("v", v) }
                    is Long -> { e.put("t", "l"); e.put("v", v) }
                    is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                    is String -> { e.put("t", "s"); e.put("v", v) }
                    is Set<*> -> { e.put("t", "ss"); e.put("v", JSONArray(v.map { it.toString() })) }
                    else -> continue
                }
                o.put(k, e)
            }
            root.put(n, o)
        }
        return root.toString()
    }

    private fun restoreJson(ctx: Context, json: String) {
        val root = JSONObject(json)
        for (n in NAMES) {
            val o = root.optJSONObject(n) ?: continue
            val ed = ctx.getSharedPreferences(n, Context.MODE_PRIVATE).edit().clear()
            for (k in o.keys()) {
                val e = o.getJSONObject(k)
                when (e.getString("t")) {
                    "b" -> ed.putBoolean(k, e.getBoolean("v"))
                    "i" -> ed.putInt(k, e.getInt("v"))
                    "l" -> ed.putLong(k, e.getLong("v"))
                    "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                    "s" -> ed.putString(k, e.getString("v"))
                    "ss" -> { val a = e.getJSONArray("v"); ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
                }
            }
            ed.apply()
        }
    }

    suspend fun signIn(act: Activity) {
        if (!ready(act)) { status = "الحساب غير مفعّل: ضع ملف google-services.json في مجلد app ثم أعد البناء"; return }
        val rid = act.resources.getIdentifier("default_web_client_id", "string", act.packageName)
        if (rid == 0) { status = "فعّل Google من Firebase ← Authentication ثم نزّل google-services.json من جديد"; return }
        busy = true
        try {
            val opt = GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(act.getString(rid)).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
            val cred = CredentialManager.create(act).getCredential(act, req).credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                val res = FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null)).await()
                registerUser(res.user)
                refreshUser(act)
                status = if (hasBackup()) "تم تسجيل الدخول. وُجدت نسخة محفوظة، اضغط «استرجاع» لتحميلها." else "تم تسجيل الدخول"
            } else status = "نوع الحساب غير مدعوم"
        } catch (e: Exception) {
            status = "تعذّر تسجيل الدخول: ${e.message}"
        } finally { busy = false }
    }

    suspend fun signOut(ctx: Context) {
        runCatching { FirebaseAuth.getInstance().signOut() }
        runCatching { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) }
        refreshUser(ctx); status = "تم تسجيل الخروج"
    }

    /** يسجّل في قاعدة البيانات أن هذا المستخدم أنشأ حسابًا في التطبيق (مرة واحدة)، ويحدّث آخر دخول. */
    private suspend fun registerUser(u: FirebaseUser?) {
        u ?: return
        try {
            val ref = FirebaseFirestore.getInstance().collection("tmusic_users").document(u.uid)
            val data = hashMapOf<String, Any>(
                "name" to (u.displayName ?: ""), "email" to (u.email ?: ""),
                "lastLogin" to FieldValue.serverTimestamp()
            )
            val snap = runCatching { ref.get().await() }.getOrNull()
            if (snap != null && !snap.contains("createdAt")) {
                data["createdAt"] = FieldValue.serverTimestamp()
                data["accountCreated"] = true
            }
            ref.set(data, SetOptions.merge()).await()
        } catch (e: Exception) { /* التسجيل اختياري: لا نمنع الدخول إن فشل */ }
    }

    private suspend fun hasBackup(): Boolean = try {
        val u = FirebaseAuth.getInstance().currentUser ?: return false
        FirebaseFirestore.getInstance().collection("tmusic_users").document(u.uid).get().await().contains("backup")
    } catch (e: Exception) { false }

    suspend fun backup(ctx: Context, manual: Boolean) {
        if (!ready(ctx)) return
        val u = FirebaseAuth.getInstance().currentUser ?: return
        val json = withContext(Dispatchers.Default) { snapshot(ctx) }
        if (!manual && json.hashCode() == lastHash) return
        if (json.length > 900_000) { status = "البيانات أكبر من حدّ التخزين"; return }
        try {
            if (manual) busy = true
            FirebaseFirestore.getInstance().collection("tmusic_users").document(u.uid)
                .set(mapOf("backup" to json, "updated" to System.currentTimeMillis(), "name" to (u.displayName ?: ""), "email" to (u.email ?: "")), SetOptions.merge()).await()
            lastHash = json.hashCode()
            if (manual) status = "تم حفظ النسخة في حسابك"
        } catch (e: Exception) {
            if (manual) status = "تعذّر الحفظ: ${e.message}"
        } finally { if (manual) busy = false }
    }

    suspend fun restore(ctx: Context) {
        if (!ready(ctx)) return
        val u = FirebaseAuth.getInstance().currentUser ?: return
        busy = true
        try {
            val d = FirebaseFirestore.getInstance().collection("tmusic_users").document(u.uid).get().await()
            val json = d.getString("backup")
            if (json.isNullOrBlank()) status = "لا توجد نسخة محفوظة في حسابك"
            else { restoreJson(ctx, json); lastHash = json.hashCode(); status = "تم الاسترجاع. أغلق التطبيق وافتحه من جديد لتظهر البيانات." }
        } catch (e: Exception) {
            status = "تعذّر الاسترجاع: ${e.message}"
        } finally { busy = false }
    }
}

@Composable
fun AccountDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { Cloud.refreshUser(ctx) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = TM.Surface,
        title = { Text("الحساب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (Cloud.signedIn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(TM.Violet), Alignment.Center) {
                            Text((Cloud.name.ifBlank { Cloud.email }.take(1)).uppercase(), color = androidx.compose.ui.graphics.Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(Cloud.name.ifBlank { "حسابي" }, fontWeight = FontWeight.SemiBold)
                            Text(Cloud.email, color = TM.Muted, fontSize = 12.sp)
                        }
                    }
                    Text("تُحفظ نسخة من مفضلتك وقوائمك وسجلّك وإعداداتك تلقائيًا في حسابك.", color = TM.Muted, fontSize = 12.sp)
                    Button(onClick = { scope.launch { Cloud.backup(ctx, true) } }, enabled = !Cloud.busy, modifier = Modifier.fillMaxWidth()) { Text("حفظ نسخة الآن") }
                    OutlinedButton(onClick = { scope.launch { Cloud.restore(ctx) } }, enabled = !Cloud.busy, modifier = Modifier.fillMaxWidth()) { Text("استرجاع من حسابي") }
                    TextButton(onClick = { scope.launch { Cloud.signOut(ctx) } }, enabled = !Cloud.busy) { Text("تسجيل الخروج", color = TM.Muted) }
                } else {
                    Text("سجّل الدخول بحساب Google لتحتفظ بمفضلتك وقوائمك على أي هاتف.", color = TM.Muted, fontSize = 13.sp)
                    Button(
                        onClick = { ctx.findActivity()?.let { a -> scope.launch { Cloud.signIn(a) } } },
                        enabled = !Cloud.busy, modifier = Modifier.fillMaxWidth()
                    ) { Text("تسجيل الدخول بحساب Google") }
                }
                if (Cloud.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = TM.VioletSoft)
                if (Cloud.status.isNotBlank()) Text(Cloud.status, fontSize = 12.sp, color = TM.VioletSoft)

                HorizontalDivider(Modifier.padding(top = 4.dp), color = TM.Muted.copy(alpha = 0.25f))
                Text("التحديثات", color = TM.VioletSoft, fontWeight = FontWeight.SemiBold)
                Text("الإصدار الحالي: build ${Updater.current}", color = TM.Muted, fontSize = 12.sp)
                if (Updater.progress >= 0f) LinearProgressIndicator(progress = { Updater.progress }, modifier = Modifier.fillMaxWidth(), color = TM.VioletSoft)
                else if (Updater.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = TM.VioletSoft)
                if (Updater.status.isNotBlank()) Text(Updater.status, fontSize = 12.sp, color = TM.VioletSoft)
                OutlinedButton(onClick = { scope.launch { Updater.check(ctx, true) } }, enabled = !Updater.busy, modifier = Modifier.fillMaxWidth()) { Text("تحقق من التحديث") }
            }
        },
        confirmButton = { TextButton(onClose) { Text("إغلاق", color = TM.VioletSoft) } }
    )
}
