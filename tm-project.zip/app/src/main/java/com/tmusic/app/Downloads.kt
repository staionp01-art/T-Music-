package com.tmusic.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs

/** تبويب التنزيلات: كل التنزيلات الجارية والمكتملة مع التقدّم والوقت وحذف الأغنية. */
@Composable
fun DownloadsTab() {
    val ctx = LocalContext.current.applicationContext
    val list = Mp3Dl.items
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Mp3Dl.activeCount) { while (Mp3Dl.activeCount > 0) { now = System.currentTimeMillis(); delay(1000) } }
    var sheet by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf<DlItem?>(null) }
    if (sheet) Mp3Sheet { sheet = false }
    askDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { askDelete = null },
            containerColor = TM.Surface,
            title = { Text("حذف الأغنية؟") },
            text = { Text("ستُحذف «${d.title}» من هاتفك نهائيًا.", color = TM.Muted) },
            confirmButton = { TextButton({ Mp3Dl.delete(ctx, d); askDelete = null }) { Text("حذف", color = Color(0xFFFF6B8A)) } },
            dismissButton = { TextButton({ askDelete = null }) { Text("إلغاء") } }
        )
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("التنزيلات", style = MaterialTheme.typography.headlineMedium)
                val act = Mp3Dl.activeCount; val done = list.count { it.state == 2 }
                Text(if (list.isEmpty()) "لا يوجد شيء بعد" else "$act جارٍ · $done مكتمل", color = TM.Muted, fontSize = 13.sp)
            }
            if (list.any { it.state >= 3 }) TextButton({ Mp3Dl.clearFinished() }) { Text("مسح السجل", color = TM.VioletSoft) }
            FilledTonalIconButton({ sheet = true }) { Icon(Icons.Rounded.Add, null) }
        }
        if (list.isEmpty()) {
            EmptyState(Icons.Rounded.Download, "لا توجد تنزيلات", "اضغط + والصق رابط أغنية، أو نزّل من نتائج البحث وستظهر هنا مع التقدّم.")
        } else LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { d -> DlRow(d, now, onDelete = { askDelete = d }, onRetry = { Mp3Dl.retry(ctx, d) }) }
        }
    }
}

@Composable
private fun DlRow(d: DlItem, now: Long, onDelete: () -> Unit, onRetry: () -> Unit) {
    val hue = abs(d.id * 61 % 360).toFloat()
    val frac by animateFloatAsState(d.progress.coerceAtLeast(0f), tween(300, easing = LinearEasing), label = "dl-frac")
    val active = d.state == 0 || d.state == 1
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(TM.Raised).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(Color.hsv(hue, 0.55f, 0.5f), Color.hsv((hue + 40) % 360, 0.6f, 0.22f)))),
            contentAlignment = Alignment.Center
        ) {
            val b = d.art
            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(0.6f))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(d.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.artist.ifBlank { "—" }, color = TM.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            when (d.state) {
                0 -> Text("في الطابور…", color = TM.Muted, fontSize = 12.sp)
                1 -> {
                    if (d.progress < 0f) LinearProgressIndicator(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = TM.Violet, trackColor = Color.White.copy(0.1f))
                    else LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = TM.VioletSoft, trackColor = Color.White.copy(0.1f))
                    Spacer(Modifier.height(3.dp))
                    val pct = if (d.progress >= 0f) "${(d.progress * 100).toInt()}%" else "…"
                    val eta = if (d.etaSec >= 0 && d.progress in 0f..0.995f) " · متبقي " + fmt(d.etaSec * 1000L) else ""
                    Text(d.note.ifBlank { "$pct$eta" } + " · منذ " + fmt(now - d.startedAt), color = TM.VioletSoft, fontSize = 12.sp)
                }
                2 -> Text(
                    "تم · " + sizeText(d.sizeBytes) + " · استغرق " + fmt(d.elapsedMs),
                    color = TM.Emerald, fontSize = 12.sp
                )
                3 -> Text(d.note, color = Color(0xFFFF8FA3), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                else -> Text("أُلغي", color = TM.Muted, fontSize = 12.sp)
            }
        }
        when {
            active -> IconButton({ Mp3Dl.cancel(d) }) { Icon(Icons.Rounded.Close, "إلغاء", tint = TM.Text) }
            d.state == 2 -> IconButton(onDelete) { Icon(Icons.Rounded.DeleteOutline, "حذف", tint = Color(0xFFFF8FA3)) }
            else -> IconButton(onRetry) { Icon(Icons.Rounded.Refresh, "إعادة", tint = TM.VioletSoft) }
        }
    }
}

private fun sizeText(b: Long): String =
    if (b <= 0) "—" else if (b >= 1_048_576) String.format(java.util.Locale.US, "%.1f MB", b / 1_048_576f) else "${b / 1024} KB"
