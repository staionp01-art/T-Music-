package com.tmusic.app

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.roundToInt

/** إيكولايزر النظام مرتبط بجلسة صوت المشغّل، مع ضبط مسبق وتعزيز للباس، ويحفظ إعداداته. */
object Eq {
    class Preset(val name: String, val gains: List<Float>)

    val presets = listOf(
        Preset("عادي", listOf(0f, 0f, 0f, 0f, 0f)),
        Preset("باس", listOf(6f, 4f, 0f, 0f, 0f)),
        Preset("روك", listOf(5f, 3f, -1f, 3f, 5f)),
        Preset("بوب", listOf(-1f, 3f, 4f, 2f, -1f)),
        Preset("صوتيات", listOf(-2f, 0f, 4f, 3f, 1f)),
        Preset("إلكترونيك", listOf(5f, 2f, 0f, 3f, 5f)),
        Preset("كلاسيك", listOf(4f, 2f, -1f, 2f, 4f))
    )

    private var eq: Equalizer? = null
    private var boost: BassBoost? = null
    private var prefs: android.content.SharedPreferences? = null

    var available by mutableStateOf(false); private set
    var enabled by mutableStateOf(false); private set
    var minMb by mutableIntStateOf(-1500); private set
    var maxMb by mutableIntStateOf(1500); private set
    val levels = mutableStateListOf<Int>()
    val labels = mutableStateListOf<String>()
    var bass by mutableIntStateOf(0); private set          // 0..1000
    var bassOk by mutableStateOf(false); private set
    var preset by mutableIntStateOf(0); private set        // -1 = مخصص

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tm_eq", Context.MODE_PRIVATE)
        prefs = p
        enabled = p.getBoolean("on", false)
        bass = p.getInt("bass", 0)
        preset = p.getInt("preset", 0)
    }

    fun attach(ctx: Context, sessionId: Int) {
        init(ctx)
        release()
        if (sessionId == 0) return
        try {
            val e = Equalizer(0, sessionId)
            val n = e.numberOfBands.toInt()
            val r = e.bandLevelRange
            minMb = r[0].toInt(); maxMb = r[1].toInt()
            val saved = (prefs?.getString("levels", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
            levels.clear(); labels.clear()
            for (i in 0 until n) {
                levels.add(if (saved.size == n) saved[i].coerceIn(minMb, maxMb) else 0)
                val hz = e.getCenterFreq(i.toShort()) / 1000
                labels.add(
                    if (hz >= 1000) (if (hz % 1000 == 0) "${hz / 1000} kHz" else String.format(Locale.US, "%.1f kHz", hz / 1000f))
                    else "$hz Hz"
                )
                e.setBandLevel(i.toShort(), levels[i].toShort())
            }
            e.setEnabled(enabled)
            eq = e
            available = true
        } catch (t: Throwable) { available = false }
        try {
            val b = BassBoost(0, sessionId)
            bassOk = b.strengthSupported
            if (bassOk) b.setStrength(bass.toShort())
            b.setEnabled(enabled)
            boost = b
        } catch (t: Throwable) { bassOk = false }
    }

    fun release() {
        runCatching { eq?.release() }; runCatching { boost?.release() }
        eq = null; boost = null; available = false
    }

    private fun save() {
        prefs?.edit()?.putBoolean("on", enabled)?.putInt("bass", bass)?.putInt("preset", preset)
            ?.putString("levels", levels.joinToString(","))?.apply()
    }

    fun enable(on: Boolean) {
        enabled = on
        runCatching { eq?.setEnabled(on) }; runCatching { boost?.setEnabled(on) }
        save()
    }

    fun setLevel(band: Int, mb: Int) {
        if (band !in levels.indices) return
        levels[band] = mb.coerceIn(minMb, maxMb)
        runCatching { eq?.setBandLevel(band.toShort(), levels[band].toShort()) }
        preset = -1
        save()
    }

    fun applyPreset(idx: Int) {
        val p = presets.getOrNull(idx) ?: return
        val n = levels.size
        for (i in 0 until n) {
            val t = if (n == 1) 0f else i / (n - 1f)
            val pos = t * (p.gains.size - 1)
            val lo = pos.toInt().coerceIn(0, p.gains.size - 1)
            val hi = (lo + 1).coerceAtMost(p.gains.size - 1)
            val db = p.gains[lo] + (p.gains[hi] - p.gains[lo]) * (pos - lo)
            levels[i] = (db * 100).roundToInt().coerceIn(minMb, maxMb)
            runCatching { eq?.setBandLevel(i.toShort(), levels[i].toShort()) }
        }
        preset = idx
        save()
    }

    fun changeBass(v: Int) {
        bass = v.coerceIn(0, 1000)
        runCatching { boost?.setStrength(bass.toShort()) }
        save()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(onDismiss: () -> Unit) {
    val sliderColors = SliderDefaults.colors(
        thumbColor = TM.VioletSoft, activeTrackColor = TM.Violet, inactiveTrackColor = TM.Raised
    )
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الإيكولايزر", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Switch(
                    checked = Eq.enabled, onCheckedChange = { Eq.enable(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = TM.Violet, checkedThumbColor = Color.White)
                )
            }
            if (!Eq.available || Eq.levels.isEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("الإيكولايزر لم يبدأ بعد. شغّل أغنية ثم افتحه من جديد.", color = TM.Muted)
                Spacer(Modifier.height(24.dp))
                return@Column
            }
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(Eq.presets) { i, p ->
                    FilterChip(
                        selected = Eq.preset == i, onClick = { Eq.applyPreset(i) }, label = { Text(p.name) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TM.Violet.copy(alpha = 0.35f))
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            EqCurve(Modifier.fillMaxWidth().height(90.dp), Eq.enabled)
            Spacer(Modifier.height(6.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Eq.levels.forEachIndexed { i, mb ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Eq.labels.getOrElse(i) { "" }, Modifier.width(64.dp), fontSize = 12.sp, color = TM.Muted)
                        Slider(
                            value = mb / 100f, onValueChange = { Eq.setLevel(i, (it * 100).roundToInt()) },
                            valueRange = Eq.minMb / 100f..Eq.maxMb / 100f, colors = sliderColors, modifier = Modifier.weight(1f)
                        )
                        Text(
                            (if (mb > 0) "+" else "") + (mb / 100) + " dB", Modifier.width(56.dp), fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, color = TM.VioletSoft
                        )
                    }
                }
            }
            if (Eq.bassOk) {
                Spacer(Modifier.height(8.dp))
                Text("تعزيز الباس", fontWeight = FontWeight.SemiBold)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Slider(
                        value = Eq.bass / 1000f, onValueChange = { Eq.changeBass((it * 1000).roundToInt()) },
                        colors = sliderColors
                    )
                }
            }
        }
    }
}

/** منحنى ناعم يرسم شكل الإيكولايزر الحالي. */
@Composable
private fun EqCurve(modifier: Modifier, on: Boolean) {
    val levels = Eq.levels.toList()
    val lo = Eq.minMb.toFloat(); val hi = Eq.maxMb.toFloat()
    val alpha = if (on) 1f else 0.35f
    Canvas(modifier) {
        if (levels.size < 2) return@Canvas
        val pts = levels.mapIndexed { i, v ->
            Offset(size.width * i / (levels.size - 1f), size.height * (1f - (v - lo) / (hi - lo)).coerceIn(0.06f, 0.94f))
        }
        val line = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            for (i in 1 until pts.size) {
                val mx = (pts[i - 1].x + pts[i].x) / 2f
                cubicTo(mx, pts[i - 1].y, mx, pts[i].y, pts[i].x, pts[i].y)
            }
        }
        val fill = Path().apply {
            addPath(line); lineTo(size.width, size.height); lineTo(0f, size.height); close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(TM.Violet.copy(alpha = 0.35f * alpha), Color.Transparent)))
        drawPath(line, Brush.horizontalGradient(listOf(TM.Violet.copy(alpha = alpha), TM.Blue.copy(alpha = alpha))), style = Stroke(width = 4.dp.toPx()))
        pts.forEach { drawCircle(Color.White.copy(alpha = alpha), 4.dp.toPx(), it) }
    }
}
