package com.tmusic.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun YtRow(v: YtVideo, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val thumb by produceState<Bitmap?>(null, v.id) { value = Art.remote("https://i.ytimg.com/vi/${v.id}/mqdefault.jpg") }
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB3261E), Color(0xFF4A0F0C)))),
            contentAlignment = Alignment.Center
        ) {
            val t = thumb
            if (t != null) Image(t.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.PlayArrow, null, tint = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(v.channel, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = TM.Muted)
        }
        val ctx = LocalContext.current
        IconButton({
            Mp3Dl.start(ctx, "https://www.youtube.com/watch?v=${v.id}")
            android.widget.Toast.makeText(ctx, "بدأ تنزيل MP3 …", android.widget.Toast.LENGTH_SHORT).show()
        }) { Icon(Icons.Rounded.Download, null, tint = TM.VioletSoft) }
    }
}

@Composable
private fun YtAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(TM.Raised).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = TM.VioletSoft, modifier = Modifier.size(24.dp))
        Text(label, fontSize = 11.sp, color = TM.Text, maxLines = 1)
    }
}

@Composable
private fun SpecRow(icon: androidx.compose.ui.graphics.vector.ImageVector, k: String, v: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(18.dp), tint = TM.Muted)
        Spacer(Modifier.width(10.dp))
        Text(k, color = TM.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(v, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** تشغيل الأغنية الكاملة عبر مشغّل يوتيوب الرسمي المضمّن (يتوقف عند الإغلاق)، مع إجراءات ومواصفات منظّمة تحته. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YoutubeDialog(v: YtVideo, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    val ytUrl = "https://www.youtube.com/watch?v=${v.id}"
    var queued by remember { mutableStateOf(false) }
    fun view(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(TM.Ink).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Rounded.Close, null) }
                Text("تشغيل", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            }
            AndroidView(
                factory = { c ->
                    WebView(c).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        loadUrl(
                            "https://www.youtube.com/embed/${v.id}?autoplay=1&playsinline=1&rel=0",
                            mapOf("Referer" to "https://com.tmusic.app")
                        )
                    }
                },
                onRelease = { it.loadUrl("about:blank"); it.destroy() },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(v.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text(v.channel, color = TM.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Button(
                    onClick = {
                        if (!queued) {
                            queued = true
                            Mp3Dl.start(ctx, ytUrl)
                            android.widget.Toast.makeText(ctx, "بدأ تنزيل MP3 …", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !queued, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(if (queued) Icons.Rounded.CheckCircle else Icons.Rounded.Download, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (queued) "أُضيفت إلى التنزيلات" else "تنزيل MP3 · ${Mp3Dl.quality} kbps", fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    YtAction(Icons.Rounded.Share, "مشاركة", Modifier.weight(1f)) {
                        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${v.title}\n$ytUrl") }
                        ctx.startActivity(Intent.createChooser(i, "مشاركة الأغنية"))
                    }
                    YtAction(Icons.Rounded.ContentCopy, "نسخ الرابط", Modifier.weight(1f)) {
                        clip.setText(androidx.compose.ui.text.AnnotatedString(ytUrl))
                        android.widget.Toast.makeText(ctx, "تم نسخ الرابط", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    YtAction(Icons.Rounded.OndemandVideo, "يوتيوب", Modifier.weight(1f)) { view(ytUrl) }
                    YtAction(Icons.Rounded.LibraryMusic, "YT Music", Modifier.weight(1f)) { view("https://music.youtube.com/watch?v=${v.id}") }
                }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(TM.Raised).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("مواصفات التنزيل", fontWeight = FontWeight.SemiBold, color = TM.VioletSoft)
                    SpecRow(Icons.Rounded.AudioFile, "الصيغة", "MP3")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.GraphicEq, null, Modifier.size(18.dp), tint = TM.Muted)
                        Spacer(Modifier.width(10.dp))
                        Text("الجودة (kbps)", color = TM.Muted, fontSize = 13.sp)
                    }
                    QualityChips()
                    SpecRow(Icons.Rounded.Image, "الغلاف والوسوم", "مضمّنة في الملف")
                    SpecRow(Icons.Rounded.Folder, "مكان الحفظ", "Music/TMusic")
                }
                Text(
                    "للاستماع في الخلفية وعلى شاشة القفل: نزّل الأغنية أو افتحها في YT Music.",
                    color = TM.Muted, fontSize = 12.sp
                )
            }
        }
    }
}
