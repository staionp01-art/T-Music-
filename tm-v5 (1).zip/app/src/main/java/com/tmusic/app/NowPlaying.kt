package com.tmusic.app

import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import kotlin.math.abs
import kotlin.math.sin
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * خلفية سينمائية: لون الغلاف الأكثر حضورًا فاتحًا، وغلاف مموّه يتحرك ببطء (Ken Burns) ويتبدّل بتلاشٍ،
 * وتوهّجان يخفقان بإيقاع منتظم أثناء التشغيل ويخفتان عند الإيقاف، وإطار معتم أعلى وأسفل.
 */
@Composable
private fun CinematicBackdrop(song: Song, pal: CoverPalette, playing: Boolean) {
    val inf = rememberInfiniteTransition(label = "backdrop")
    val drift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "drift")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val live by animateFloatAsState(if (playing) 1f else 0.3f, tween(900), label = "live")
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to pal.bg, 0.5f to lerp(pal.bg, TM.Ink, 0.6f), 0.9f to TM.Ink)
            )
        )
        if (Build.VERSION.SDK_INT >= 31) {
            Crossfade(song, animationSpec = tween(900), label = "backdrop-art") { sg ->
                val art by rememberArt(sg)
                val b = art
                if (b != null) Image(
                    b.asImageBitmap(), null,
                    Modifier.fillMaxSize().graphicsLayer {
                        val z = 1.5f + 0.15f * drift
                        scaleX = z; scaleY = z
                        translationX = (drift - 0.5f) * 90f
                        alpha = 0.34f * (0.5f + 0.5f * live)
                    }.blur(70.dp),
                    contentScale = ContentScale.Crop
                )
            }
        }
        Box(
            Modifier.fillMaxSize().drawBehind {
                val k = 1f + 0.12f * pulse * live
                drawRect(
                    Brush.radialGradient(
                        listOf(pal.accent.copy(alpha = 0.34f * live), Color.Transparent),
                        center = Offset(size.width * (0.2f + 0.6f * drift), size.height * 0.30f), radius = size.width * 0.9f * k
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(pal.accent.copy(alpha = 0.2f * live), Color.Transparent),
                        center = Offset(size.width * (0.9f - 0.6f * drift), size.height * 0.62f), radius = size.width * 0.8f * k
                    )
                )
                drawRect(Brush.verticalGradient(0f to Color.Black.copy(0.35f), 0.2f to Color.Transparent, 0.8f to Color.Transparent, 1f to Color.Black.copy(0.45f)))
            }
        )
    }
}


/** دخول متدرّج: كل عنصر يظهر بتأخير بسيط ويصعد من الأسفل. */
@Composable
private fun Modifier.stagger(index: Int): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(110L * index)
        a.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 60f }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlaying(song: Song, ui: PlayerUi, dragModifier: Modifier = Modifier, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pal = rememberCoverPalette(song, TM.Raised)
    var showLyrics by remember { mutableStateOf(false) }
    var cinema by remember { mutableStateOf(false) }
    var version by remember { mutableIntStateOf(0) }
    val lyrics = remember(song.id, version) { LyricsStore.load(ctx, song.id) }
    var showPaste by remember { mutableStateOf(false) }
    var fetching by remember { mutableStateOf(false) }
    val fetchScope = rememberCoroutineScope()
    LaunchedEffect(version, song.id) { ui.reloadLyrics() }
    var showEq by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val text = uri?.let {
            runCatching { ctx.contentResolver.openInputStream(it)?.bufferedReader(Charsets.UTF_8)?.use { r -> r.readText() } }.getOrNull()
        }
        if (!text.isNullOrBlank()) { LyricsStore.save(ctx, song.id, text); version++ }
    }

    // وميض سينمائي سريع عند تبديل الأغنية (تالي/سابق)
    val skipFlash = remember { Animatable(0f) }
    var firstSong by remember { mutableStateOf(true) }
    LaunchedEffect(song.id) {
        if (firstSong) { firstSong = false; return@LaunchedEffect }
        skipFlash.snapTo(0.12f)
        skipFlash.animateTo(0f, tween(600, easing = FastOutSlowInEasing))
    }

    Box(Modifier.fillMaxSize().background(TM.Ink).clickable(enabled = false) {}) {
        CinematicBackdrop(song, pal, ui.isPlaying)

        val cfg = androidx.compose.ui.platform.LocalConfiguration.current
        val land = cfg.screenWidthDp > cfg.screenHeightDp
        val topBar: @Composable () -> Unit = {
            // العنوان في المنتصف تمامًا: عدد الأزرار على الجانبين متساوٍ، والإيكولايزر بجانب الاسم مباشرة
            val sideBtns = if (song.downloadUrl != null) 3 else 2
            Row(Modifier.fillMaxWidth().then(dragModifier).padding(vertical = 4.dp).stagger(0), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.width(48.dp * sideBtns)) {
                    IconButton(onClose) { Icon(Icons.Rounded.KeyboardArrowDown, null, Modifier.size(32.dp)) }
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("يُشغَّل الآن", fontSize = 12.sp, color = Color.White.copy(0.65f))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Text(
                            song.album.ifBlank { song.artist }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            Icons.Rounded.Equalizer, "الإيكولايزر", tint = pal.accent,
                            modifier = Modifier.size(20.dp).clip(CircleShape).clickable { Eq.init(ctx); showEq = true }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            AppPrefs.speedLabel(), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = if (AppPrefs.speed == 1f) Color.White.copy(0.7f) else pal.accent,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { showSpeed = true }.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
                Row(Modifier.width(48.dp * sideBtns), horizontalArrangement = Arrangement.End) {
                    if (song.downloadUrl != null) IconButton({ downloadSong(ctx, song) }) {
                        Icon(Icons.Rounded.Download, null, Modifier.size(26.dp))
                    }
                    IconButton({ cinema = true }) { Icon(Icons.Rounded.Theaters, null, Modifier.size(26.dp)) }
                    IconButton({ showLyrics = !showLyrics }) {
                        Icon(Icons.Rounded.Lyrics, null, tint = if (showLyrics) pal.accent else Color.White, modifier = Modifier.size(26.dp))
                    }
                }
            }

        }
        val stage: @Composable ColumnScope.() -> Unit = {
            Box(Modifier.weight(1f).fillMaxWidth().stagger(1), contentAlignment = Alignment.Center) {
                Crossfade(showLyrics, label = "stage") { lyricsOn ->
                    if (lyricsOn) LyricsPanel(
                        lyrics, ui,
                        onPick = { picker.launch(arrayOf("*/*")) },
                        onPaste = { showPaste = true },
                        onClear = { LyricsStore.delete(ctx, song.id); version++ },
                        onFetch = {
                            fetching = true
                            fetchScope.launch {
                                val ok = Lrclib.fetch(ctx, song)
                                fetching = false
                                if (ok) version++ else android.widget.Toast.makeText(ctx, "لم أجد كلمات لهذه الأغنية", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        fetching = fetching
                    ) else CoverStage(song, ui, pal.accent)
                }
            }

        }
        val info: @Composable ColumnScope.() -> Unit = {
            AnimatedContent(
                targetState = song,
                modifier = Modifier.fillMaxWidth().then(dragModifier).padding(top = 12.dp).stagger(2),
                transitionSpec = {
                    (fadeIn(tween(450, delayMillis = 120)) + slideInVertically(tween(450)) { it / 3 }) togetherWith
                        fadeOut(tween(200))
                },
                label = "titles"
            ) { sg ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(48.dp))
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            sg.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            sg.artist, fontSize = 16.sp, color = Color.White.copy(0.7f), textAlign = TextAlign.Center,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    HeartButton(sg, Modifier.size(48.dp))
                }
            }

            // شريط التقدّم + الأزرار (دائمًا من اليسار لليمين)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp).stagger(3)) {
                    CinemaSeekBar(song, ui, pal.accent)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        ToggleIcon(Icons.Rounded.Shuffle, ui.shuffle, ui.shuffle, pal.accent, ui::toggleShuffle)
                        PressIcon(Icons.Rounded.SkipPrevious, 40.dp, Color.White, nudge = -18f, onClick = ui::previous)
                        PlayButton(ui.isPlaying, pal.accent, ui::togglePlay)
                        PressIcon(Icons.Rounded.SkipNext, 40.dp, Color.White, nudge = 18f, onClick = ui::next)
                        ToggleIcon(
                            if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            ui.repeat, ui.repeat != Player.REPEAT_MODE_OFF, pal.accent, ui::cycleRepeat
                        )
                    }
                }
            }
        }
        if (land) {
            Row(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)) {
                Column(Modifier.weight(1f)) { topBar(); stage() }
                Spacer(Modifier.width(24.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) { info() }
            }
        } else {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)) { topBar(); stage(); info() }
        }

        if (cinema) CinemaMode(song, lyrics, ui) { cinema = false }
        if (skipFlash.value > 0.002f) Box(Modifier.fillMaxSize().background(pal.accent.copy(alpha = skipFlash.value)))
    }

    if (showEq) EqualizerSheet { showEq = false }
    if (showSpeed) SpeedDialog { showSpeed = false }

    if (showPaste) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text("لصق الكلمات") },
            text = {
                OutlinedTextField(
                    text, { text = it }, minLines = 6, maxLines = 10,
                    placeholder = { Text("الصق الكلمات هنا. يدعم تنسيق LRC المتزامن.") }
                )
            },
            confirmButton = {
                TextButton({
                    if (text.isNotBlank()) { LyricsStore.save(ctx, song.id, text); version++ }
                    showPaste = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton({ showPaste = false }) { Text("إلغاء") } }
        )
    }
}

/**
 * الغلاف السينمائي:
 *  - الانتقال بين الأغاني: ينزلق الغلاف القديم ويصغر، ويدخل الجديد من الجهة المناسبة (التالي/السابق).
 *  - الإيقاف: يصغر الغلاف ويخفت لونه ويظلم، وتظهر أيقونة إيقاف تتلاشى.
 *  - التشغيل: يعود بنبضة مرنة، تظهر أيقونة تشغيل وحلقة ضوء تتسع وتتلاشى.
 *  - أثناء التشغيل: تقريب بطيء للصورة (Ken Burns) ولمعة ضوء تعبر الغلاف.
 */
@Composable
private fun CoverStage(song: Song, ui: PlayerUi, accent: Color) {
    val playing = ui.isPlaying
    val tilt = rememberTilt()
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing, TM.vinyl) {
        if (playing && TM.vinyl) {
            var last = withFrameNanos { it }
            while (true) { val t = withFrameNanos { it }; angle = (angle + (t - last) / 1e9f * 30f) % 360f; last = t }
        }
    }
    val coverShape = if (TM.vinyl) CircleShape else RoundedCornerShape(22.dp)
    val scale by animateFloatAsState(if (playing) 1f else 0.84f, spring(dampingRatio = 0.55f, stiffness = 220f), label = "cover-scale")
    val sat by animateFloatAsState(if (playing) 1f else 0.25f, tween(700), label = "cover-sat")
    val dim by animateFloatAsState(if (playing) 0f else 0.35f, tween(700), label = "cover-dim")
    val inf = rememberInfiniteTransition(label = "cover-fx")
    val zoom by inf.animateFloat(1f, 1.07f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "zoom")
    val sweep by inf.animateFloat(-0.6f, 1.6f, infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "sweep")

    val flash = remember { Animatable(1f) }
    val ring = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(playing) {
        if (first) { first = false; return@LaunchedEffect }
        flash.snapTo(0f); ring.snapTo(0f)
        if (playing) launch { ring.animateTo(1f, tween(900)) }
        flash.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }

    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val s = minOf(maxWidth, maxHeight)

        Canvas(Modifier.size(s)) {
            val p = ring.value
            if (p in 0.01f..0.99f) {
                drawCircle(
                    accent.copy(alpha = 0.5f * (1f - p)),
                    radius = size.minDimension / 2f * (0.9f + 0.6f * p),
                    style = Stroke(width = 6f)
                )
            }
        }

        AnimatedContent(
            targetState = song,
            transitionSpec = {
                val d = ui.dir
                (slideInHorizontally(tween(550, easing = FastOutSlowInEasing)) { d * it / 2 } +
                    fadeIn(tween(450)) + scaleIn(tween(550), initialScale = 0.85f)) togetherWith
                    (slideOutHorizontally(tween(450, easing = FastOutSlowInEasing)) { -d * it / 2 } +
                        fadeOut(tween(300)) + scaleOut(tween(450), targetScale = 0.85f))
            },
            label = "cover-swap"
        ) { sg ->
            Box(
                Modifier.size(s)
                    .graphicsLayer { scaleX = scale; scaleY = scale; rotationY = tilt.x * 14f; rotationX = -tilt.y * 14f; cameraDistance = 18f * density; rotationZ = if (TM.vinyl) angle else 0f }
                    .shadow(30.dp, coverShape, clip = false, ambientColor = accent, spotColor = accent)
                    .clip(coverShape)
                    .drawWithContent {
                        drawContent()
                        // تعتيم الإيقاف + إطار معتم خفيف (Vignette)
                        drawRect(Color.Black.copy(alpha = dim))
                        if (TM.vinyl) { drawCircle(Color.Black, size.minDimension * 0.07f); drawCircle(Color.White.copy(alpha = 0.25f), size.minDimension * 0.07f, style = Stroke(width = 3f)) }
                        drawRect(
                            Brush.radialGradient(
                                0.6f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.35f),
                                center = center, radius = size.maxDimension * 0.75f
                            )
                        )
                        // لمعة ضوء تعبر الغلاف أثناء التشغيل
                        if (playing) {
                            val x = size.width * sweep
                            drawRect(
                                Brush.linearGradient(
                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent),
                                    start = Offset(x - 140f, 0f), end = Offset(x + 140f, size.height)
                                )
                            )
                        }
                    }
            ) {
                Cover(sg, Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom }, corner = 0.dp, saturation = sat)
            }
        }

        // أيقونة تشغيل/إيقاف تظهر وتتلاشى عند الضغط
        if (flash.value in 0.001f..0.999f) {
            Box(
                Modifier.size(96.dp)
                    .graphicsLayer {
                        alpha = 1f - flash.value
                        scaleX = 0.7f + 0.6f * flash.value
                        scaleY = 0.7f + 0.6f * flash.value
                    }
                    .background(Color.Black.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (playing) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(54.dp), tint = Color.White)
            }
        }
    }
}

@Composable
private fun LyricsPanel(
    lyrics: Lyrics?, ui: PlayerUi,
    onPick: () -> Unit, onPaste: () -> Unit, onClear: () -> Unit,
    onFetch: () -> Unit = {}, fetching: Boolean = false
) {
    if (lyrics == null) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Rounded.Lyrics, null, Modifier.size(52.dp), tint = Color.White.copy(0.5f))
            Spacer(Modifier.height(14.dp))
            Text("لا توجد كلمات لهذه الأغنية", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "أضف ملف .lrc لتظهر الكلمات متزامنة مع الصوت، أو الصق النص.",
                color = Color.White.copy(0.65f), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
            Button(onFetch, enabled = !fetching) {
                Icon(Icons.Rounded.CloudDownload, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(if (fetching) "جارٍ البحث…" else "جلب الكلمات تلقائيًا")
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(onPick) {
                    Icon(Icons.Rounded.UploadFile, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("اختيار ملف")
                }
                OutlinedButton(onPaste) {
                    Icon(Icons.Rounded.ContentPaste, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("لصق نص")
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    val active by remember(lyrics) {
        derivedStateOf { if (lyrics.synced) lyrics.lines.indexOfLast { it.timeMs <= ui.position + 250 } else -1 }
    }
    LaunchedEffect(active) {
        if (active >= 0) listState.animateScrollToItem(active, -listState.layoutInfo.viewportSize.height / 3)
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(vertical = 90.dp),
        modifier = Modifier.fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 0.12f to Color.Black, 0.88f to Color.Black, 1f to Color.Transparent),
                    blendMode = BlendMode.DstIn
                )
            }
    ) {
        itemsIndexed(lyrics.lines) { i, line ->
            val on = lyrics.synced && i == active
            val color by animateColorAsState(
                when { !lyrics.synced -> Color.White.copy(0.9f); on -> Color.White; else -> Color.White.copy(0.32f) },
                tween(300), label = "lyric-color"
            )
            val size by animateFloatAsState(if (on) 28f else 24f, tween(300), label = "lyric-size")
            Text(
                line.text, color = color, fontSize = size.sp, lineHeight = (size * 1.3f).sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .then(if (lyrics.synced) Modifier.clickable { ui.seek(line.timeMs) } else Modifier)
                    .padding(horizontal = 4.dp, vertical = 9.dp)
            )
        }
        item {
            TextButton(onClear, Modifier.padding(top = 24.dp)) {
                Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("حذف الكلمات")
            }
        }
    }
}

private class Star(val fx: Float, val rise: Float, val r: Float, val max: Int, var life: Int = 0)

/**
 * شريط تقدّم بالنجوم: ألوانه من غلاف الأغنية، نجوم تولد من الخط وتصعد ثم تتلألأ وتختفي،
 * خيوط خافتة بينها تشكّل كوكبة، ونيزك يعبر كل بضع ثوانٍ ويصطدم بالنقطة. السحب والنقر للتقديم.
 */
@Composable
private fun CinemaSeekBar(song: Song, ui: PlayerUi, accent: Color) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val haptic = LocalHapticFeedback.current
    val dur = ui.duration.coerceAtLeast(1L).toFloat()
    val shown = (drag ?: ui.position.toFloat()).coerceIn(0f, dur)
    val frac by animateFloatAsState(shown / dur, if (drag != null) snap<Float>() else tween<Float>(240, easing = LinearEasing), label = "seek-frac")
    val grow by animateFloatAsState(if (drag != null) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 420f), label = "seek-grow")
    val accentAnim by animateColorAsState(accent, tween(700), label = "seek-accent")   // انتقال لوني سلس بين الأغاني

    val fracNow by rememberUpdatedState(frac)
    val playing by rememberUpdatedState(ui.isPlaying)
    val stars = remember { mutableListOf<Star>() }
    var tick by remember { mutableIntStateOf(0) }
    var meteor by remember { mutableFloatStateOf(-1f) }
    var ripple by remember { mutableFloatStateOf(-1f) }
    LaunchedEffect(Unit) {
        var last = 0L; var sinceMeteor = 0f
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                if (playing && fracNow > 0.02f && stars.size < 45 && kotlin.random.Random.nextFloat() < 0.3f)
                    stars.add(Star(kotlin.random.Random.nextFloat() * fracNow, 12f + kotlin.random.Random.nextFloat() * 28f, 0.8f + kotlin.random.Random.nextFloat() * 1.6f, 110 + kotlin.random.Random.nextInt(90)))
                val iter = stars.iterator()
                while (iter.hasNext()) { val s = iter.next(); s.life++; if (s.life >= s.max) iter.remove() }
                if (playing) sinceMeteor += dt
                if (meteor < 0f && sinceMeteor > 4.2f && fracNow > 0.03f) { meteor = 0f; sinceMeteor = 0f }
                if (meteor >= 0f) { meteor += dt / 0.9f; if (meteor >= 1f) { meteor = -1f; ripple = 0f } }
                if (ripple >= 0f) { ripple += dt / 0.8f; if (ripple >= 1f) ripple = -1f }
                if (playing || stars.isNotEmpty() || meteor >= 0f || ripple >= 0f) tick++
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(84.dp)) {
            val w = maxWidth
            Canvas(
                Modifier.fillMaxSize()
                    .pointerInput(dur) {
                        detectTapGestures(onTap = { off ->
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            ui.seek((off.x / size.width * dur).coerceIn(0f, dur).toLong())
                        })
                    }
                    .pointerInput(dur) {
                        var lastSec = -1L
                        detectHorizontalDragGestures(
                            onDragStart = {
                                val v = (it.x / size.width * dur).coerceIn(0f, dur)
                                drag = v; lastSec = (v / 1000).toLong()
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            onHorizontalDrag = { ch, _ ->
                                val v = (ch.position.x / size.width * dur).coerceIn(0f, dur)
                                drag = v
                                val sec = (v / 1000).toLong()
                                if (sec != lastSec) { lastSec = sec; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                            },
                            onDragEnd = { drag?.let { ui.seek(it.toLong()) }; drag = null },
                            onDragCancel = { drag = null }
                        )
                    }
            ) {
                val time = tick * 0.016f
                val cy = size.height * 0.80f
                val th = 4.dp.toPx() + 3.dp.toPx() * grow
                val x = (size.width * frac).coerceIn(0f, size.width)
                val ac = accentAnim

                // النجوم والكوكبة
                val pts = stars.map { s ->
                    val t = s.life / s.max.toFloat()
                    val a = sin(Math.PI * t).toFloat() * (0.65f + 0.35f * sin(time * 9f + s.fx * 20f))
                    Triple(Offset(s.fx * size.width, cy - 5.dp.toPx() - t * s.rise.dp.toPx()), a.coerceIn(0f, 1f), s.r.dp.toPx())
                }
                for (i in pts.indices) for (j in i + 1 until pts.size) {
                    val p = pts[i]; val q = pts[j]
                    val d = kotlin.math.hypot(p.first.x - q.first.x, p.first.y - q.first.y)
                    if (d < 56.dp.toPx()) drawLine(Color.White.copy(alpha = 0.18f * (1f - d / 56.dp.toPx()) * minOf(p.second, q.second)), p.first, q.first, strokeWidth = 1f)
                }
                pts.forEach { (o, a, r) ->
                    val c = Color.White.copy(alpha = a)
                    drawLine(c, Offset(o.x - r * 2.4f, o.y), Offset(o.x + r * 2.4f, o.y), strokeWidth = 1f)
                    drawLine(c, Offset(o.x, o.y - r * 2.4f), Offset(o.x, o.y + r * 2.4f), strokeWidth = 1f)
                    drawCircle(c, r * 0.75f, o)
                }

                // المسار والتوهج
                drawRoundRect(Color.White.copy(alpha = 0.16f), Offset(0f, cy - th / 2f), Size(size.width, th), CornerRadius(th / 2f))
                if (x > 0f) {
                    drawRoundRect(ac.copy(alpha = 0.22f), Offset(0f, cy - th * 1.5f), Size(x, th * 3f), CornerRadius(th * 1.5f))
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(ac.copy(alpha = 0.55f), ac), startX = 0f, endX = x.coerceAtLeast(1f)),
                        Offset(0f, cy - th / 2f), Size(x, th), CornerRadius(th / 2f)
                    )
                }

                // النيزك
                if (meteor >= 0f) {
                    val sx = size.width + 20.dp.toPx(); val sy = -10.dp.toPx()
                    val hx = sx + (x - sx) * meteor; val hy = sy + (cy - sy) * meteor
                    val tx = (sx - x) * 0.12f; val ty = (sy - cy) * 0.12f
                    for (i in 0 until 8) {
                        val f0 = i / 8f; val f1 = (i + 1) / 8f
                        drawLine(Color.White.copy(alpha = 0.9f * (1f - f0)), Offset(hx + tx * f0, hy + ty * f0), Offset(hx + tx * f1, hy + ty * f1), strokeWidth = 2.dp.toPx() * (1f - f0 * 0.6f))
                    }
                    drawCircle(Color.White, 2.6.dp.toPx(), Offset(hx, hy))
                }
                if (ripple >= 0f) drawCircle(Color.White.copy(alpha = (1f - ripple) * 0.7f), 6.dp.toPx() + ripple * 18.dp.toPx(), Offset(x, cy), style = Stroke(2.dp.toPx()))

                // المقبض
                if (grow > 0.01f) drawCircle(ac.copy(alpha = 0.28f * grow), radius = 10.dp.toPx() + 10.dp.toPx() * grow, center = Offset(x, cy))
                drawCircle(ac.copy(alpha = 0.35f), radius = 11.dp.toPx(), center = Offset(x, cy))
                drawCircle(Color.White, radius = 6.5.dp.toPx() + 3.dp.toPx() * grow, center = Offset(x, cy))
            }
            // فقاعة الوقت فوق المقبض أثناء اللمس
            val bubbleW = 52.dp
            val bx = (w * frac - bubbleW / 2).coerceIn(0.dp, w - bubbleW)
            Box(
                Modifier.offset(x = bx, y = 20.dp).width(bubbleW).height(24.dp)
                    .graphicsLayer { alpha = grow; scaleX = 0.7f + 0.3f * grow; scaleY = 0.7f + 0.3f * grow; translationY = (1f - grow) * 10f }
                    .clip(RoundedCornerShape(12.dp)).background(accentAnim),
                contentAlignment = Alignment.Center
            ) { Text(fmt(shown.toLong()), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black.copy(alpha = 0.85f)) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(shown.toLong()), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White.copy(0.85f))
            Text(fmt(ui.duration), fontSize = 12.sp, color = Color.White.copy(0.55f))
        }
    }
}

/** زر أيقونة بضغطة نابضية، ومع حركة دفع صغيرة باتجاه السهم (للسابق والتالي). */
@Composable
private fun PressIcon(icon: ImageVector, size: Dp, tint: Color, nudge: Float = 0f, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.8f else 1f, spring(dampingRatio = 0.45f, stiffness = 520f), label = "pi-scale")
    val shift = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Box(
        Modifier.size(56.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc; translationX = shift.value }
            .clickable(interactionSource = src, indication = null) {
                onClick()
                if (nudge != 0f) scope.launch {
                    shift.snapTo(0f)
                    shift.animateTo(nudge, tween(110))
                    shift.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = 400f))
                }
            },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size), tint = tint) }
}

/** زر تشغيل/إيقاف: تتحول الأيقونة بتكبير وتصغير، وهالة بلون الغلاف. */
@Composable
private fun PlayButton(playing: Boolean, accent: Color, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "pb-scale")
    Box(
        Modifier.size(76.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .shadow(18.dp, CircleShape, ambientColor = accent, spotColor = accent)
            .clip(CircleShape).background(Color.White)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = playing,
            transitionSpec = { (scaleIn(spring(0.5f, 500f), initialScale = 0.4f) + fadeIn(tween(140))) togetherWith (scaleOut(tween(120), targetScale = 0.4f) + fadeOut(tween(100))) },
            label = "pb-icon"
        ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(44.dp), tint = Color.Black) }
    }
}

/** زر تبديل (عشوائي/تكرار): اللون يتحول بنعومة، والأيقونة تقفز، ونقطة صغيرة تدل على التفعيل. */
@Composable
private fun ToggleIcon(icon: ImageVector, key: Any, on: Boolean, accent: Color, onClick: () -> Unit) {
    val tint by animateColorAsState(if (on) accent else Color.White.copy(0.6f), tween(300), label = "tg-tint")
    val dot by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "tg-dot")
    val pop = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(key) {
        if (first) { first = false; return@LaunchedEffect }
        pop.snapTo(0.6f)
        pop.animateTo(1f, spring(dampingRatio = 0.3f, stiffness = 380f))
    }
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }, tint = tint)
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).size(4.dp)
                .graphicsLayer { scaleX = dot; scaleY = dot; alpha = dot }
                .background(accent, CircleShape)
        )
    }
}
