package com.tmusic.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object TM {
    /** 0 الافتراضي، 1 داكن عميق، 2 AMOLED أسود، 3 ألوان حسب الوقت */
    var mode by mutableIntStateOf(0)
    var vinyl by mutableStateOf(false)
    var fade by mutableStateOf(false)
    fun applyFade(v: Boolean) { fade = v; prefs?.edit()?.putBoolean("fade", v)?.apply() }
    fun applyVinyl(v: Boolean) { vinyl = v; prefs?.edit()?.putBoolean("vinyl", v)?.apply() }
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("tm_theme", Context.MODE_PRIVATE)
        mode = prefs!!.getInt("mode", 0)
        vinyl = prefs!!.getBoolean("vinyl", false)
        fade = prefs!!.getBoolean("fade", false)
    }
    fun applyMode(m: Int) { mode = m; prefs?.edit()?.putInt("mode", m)?.apply() }

    /** النمط الفعلي: في وضع الوقت: نهارًا افتراضي، مساءً عميق، ليلًا أسود. */
    private fun eff(): Int = if (mode != 3) mode else {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when { h in 6..16 -> 0; h in 17..21 -> 1; else -> 2 }
    }
    private fun hour() = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)

    val Ink: Color get() = when (eff()) { 2 -> Color(0xFF000000); 1 -> Color(0xFF07070B); else -> Color(0xFF0C0C11) }
    val Surface: Color get() = when (eff()) { 2 -> Color(0xFF0A0A0A); 1 -> Color(0xFF0E0E14); else -> Color(0xFF15151C) }
    val Raised: Color get() = when (eff()) { 2 -> Color(0xFF151515); 1 -> Color(0xFF181822); else -> Color(0xFF1F1F29) }
    val Deep: Color get() = when (eff()) { 2 -> Color(0xFF110B22); 1 -> Color(0xFF1F1440); else -> Color(0xFF2B1B55) }
    val Violet: Color get() = if (mode != 3) Color(0xFF9C6BFF) else when (hour()) { in 6..16 -> Color(0xFF9C6BFF); in 17..21 -> Color(0xFFFF8A5B); else -> Color(0xFF5B8CFF) }
    val VioletSoft: Color get() = if (mode != 3) Color(0xFFB794FF) else when (hour()) { in 6..16 -> Color(0xFFB794FF); in 17..21 -> Color(0xFFFFB08A); else -> Color(0xFF8FB0FF) }
    val Blue: Color get() = if (mode != 3) Color(0xFF6E8BFF) else when (hour()) { in 6..16 -> Color(0xFF6E8BFF); in 17..21 -> Color(0xFFFFC857); else -> Color(0xFF7C6BFF) }
    val Emerald = Color(0xFF3DDBA0)
    val Gold = Color(0xFFE2B86B)
    val Text = Color(0xFFF2F0FA)
    val Muted = Color(0xFFA6A3B8)
}

@Composable
fun TMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = TM.Violet, onPrimary = Color.Black,
            background = TM.Ink, onBackground = TM.Text,
            surface = TM.Surface, onSurface = TM.Text,
            surfaceVariant = TM.Raised, onSurfaceVariant = TM.Muted
        ),
        typography = Typography(
            headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 30.sp),
            titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp),
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
            bodyMedium = TextStyle(fontSize = 14.sp),
            bodySmall = TextStyle(fontSize = 12.sp)
        ),
        content = content
    )
}
