package com.tmusic.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.Close
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** تحديث تلقائي من GitHub Releases: يتحقق، ينزّل ملف APK، ثم يثبّته عبر PackageInstaller. */
object Updater {
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    var available by mutableStateOf(false)
    var dismissed by mutableStateOf(false)
    private var pending: Rel? = null
    val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main)
    val current: Int get() = BuildConfig.VERSION_CODE
    /** رقم الإصدار الذي يراه المستخدم. غيّره هنا عند كل إصدار رئيسي جديد (المقارنة الداخلية تبقى برقم البناء). */
    const val LABEL = "T 3.0"

    private class Rel(val num: Int, val url: String, val size: Long)

    private fun latest(repo: String): Rel? {
        return try {
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "TMusic")
            c.connectTimeout = 10000; c.readTimeout = 15000
            try {
                if (c.responseCode != 200) return null
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val num = j.optString("tag_name").substringAfterLast('-').toIntOrNull() ?: return null
                val assets = j.optJSONArray("assets") ?: return null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) return Rel(num, a.optString("browser_download_url"), a.optLong("size"))
                }
                null
            } finally { c.disconnect() }
        } catch (e: Exception) { null }
    }

    private fun download(url: String, out: File, onProgress: (Float) -> Unit): Boolean {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "TMusic")
            c.instanceFollowRedirects = true
            c.connectTimeout = 15000; c.readTimeout = 30000
            try {
                if (c.responseCode != 200) return false
                val total = c.contentLengthLong
                val tmp = File(out.parentFile, out.name + ".part")
                var done = 0L
                c.inputStream.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (total > 0) onProgress(done.toFloat() / total)
                        }
                    }
                }
                tmp.renameTo(out)
            } finally { c.disconnect() }
        } catch (e: Exception) { false }
    }

    /** يتحقق فقط: إن وُجد إصدار أحدث يظهر شريط «حدّث الآن» ولا يُنزَّل شيء قبل أن يضغط المستخدم. */
    suspend fun check(ctx: Context, manual: Boolean) {
        if (busy) return
        val repo = BuildConfig.GH_REPO
        if (repo.isBlank()) { if (manual) status = "رابط المستودع غير معروف: ابنِ التطبيق من GitHub Actions"; return }
        val sp = ctx.getSharedPreferences("tm_update", Context.MODE_PRIVATE)
        if (!manual && System.currentTimeMillis() - sp.getLong("last", 0L) < 3 * 3600_000L) return
        busy = true
        try {
            status = "جاري التحقق من التحديثات…"
            val info = withContext(Dispatchers.IO) { latest(repo) }
            sp.edit().putLong("last", System.currentTimeMillis()).apply()
            if (info == null) { status = "تعذّر التحقق من التحديث (تأكد من الإنترنت وأن المستودع عام)"; return }
            if (info.num <= current) { available = false; pending = null; status = "أنت على آخر إصدار ($LABEL)"; return }
            val isNew = pending?.num != info.num
            pending = info; available = true
            if (isNew) dismissed = false
            status = "يوجد إصدار أحدث، اضغط «حدّث الآن»"
            Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تحديث جديد متاح", "افتح T Music واضغط «حدّث الآن»", android.R.drawable.stat_sys_download_done)
        } catch (e: Exception) {
            status = "تعذّر التحقق: ${e.message}"
        } finally { busy = false }
    }

    /** ينزّل التحديث الذي وُجد ويثبّته (يُستدعى من زر «حدّث الآن»). */
    suspend fun apply(ctx: Context) {
        if (busy) return
        val info = pending ?: return
        busy = true
        try {
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                status = "اسمح لـ T Music بتثبيت التطبيقات ثم اضغط «حدّث الآن»"
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            status = "جاري تنزيل التحديث…"
            progress = 0f
            Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تحديث T Music", "جاري تنزيل التحديث…", android.R.drawable.stat_sys_download, ongoing = true, indeterminate = true)
            val f = File(ctx.cacheDir, "update-${info.num}.apk")
            var lastPct = -1
            val ok = withContext(Dispatchers.IO) {
                if (f.exists() && f.length() == info.size) true
                else download(info.url, f) { p ->
                    progress = p
                    val pct = (p * 100).toInt()
                    if (pct != lastPct) {
                        lastPct = pct
                        Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تحديث T Music", "جاري التنزيل… $pct%", android.R.drawable.stat_sys_download, ongoing = true, progress = pct)
                    }
                }
            }
            if (!ok) {
                status = "فشل تنزيل التحديث"
                Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "فشل تنزيل التحديث", "افتح التطبيق وأعد المحاولة", android.R.drawable.stat_notify_error)
                return
            }
            status = "تم تنزيل التحديث، جاري التثبيت…"
            Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تم تنزيل التحديث", "جاري تثبيت التحديث…", android.R.drawable.stat_sys_download_done)
            withContext(Dispatchers.IO) { install(ctx, f) }
        } catch (e: Exception) {
            status = "تعذّر التحديث: ${e.message}"
            Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تعذّر التحديث", (e.message ?: "").take(100), android.R.drawable.stat_notify_error)
        } finally {
            busy = false; progress = -1f
        }
    }

    private fun install(ctx: Context, f: File) {
        val pi = ctx.packageManager.packageInstaller
        val p = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        p.setAppPackageName(ctx.packageName)
        if (Build.VERSION.SDK_INT >= 31) p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = pi.createSession(p)
        pi.openSession(id).use { s ->
            f.inputStream().use { i ->
                s.openWrite("tm.apk", 0, f.length()).use { o -> i.copyTo(o); s.fsync(o) }
            }
            val intent = Intent(ctx, InstallReceiver::class.java).setPackage(ctx.packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
    }
}

class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val c = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (c != null) runCatching { ctx.startActivity(c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                Updater.status = "تم التحديث"
                Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "تم تحديث T Music", "أنت الآن على ${Updater.LABEL}", android.R.drawable.stat_sys_download_done)
            }
            else -> {
                val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                Updater.status = "فشل التثبيت: $msg"
                Notify.post(ctx, Notify.ID_UPDATE, Notify.CH_UPDATES, "فشل تثبيت التحديث", msg.take(100), android.R.drawable.stat_notify_error)
            }
        }
    }
}


/** شريط «حدّث الآن» في أسفل التطبيق: يظهر فقط عند وجود إصدار أحدث. */
@androidx.compose.runtime.Composable
fun UpdateBanner() {
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    if (!Updater.available || Updater.dismissed) return
    androidx.compose.foundation.layout.Row(
        androidx.compose.ui.Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(TM.Violet.copy(alpha = 0.35f), TM.Blue.copy(alpha = 0.3f))))
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.SystemUpdate, null, tint = TM.VioletSoft)
        androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.width(10.dp))
        androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.weight(1f)) {
            androidx.compose.material3.Text("تحديث جديد متاح", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 14.sp)
            if (Updater.progress >= 0f) androidx.compose.material3.LinearProgressIndicator(progress = { Updater.progress }, modifier = androidx.compose.ui.Modifier.fillMaxWidth().padding(top = 4.dp), color = TM.VioletSoft)
            else if (Updater.busy) androidx.compose.material3.LinearProgressIndicator(androidx.compose.ui.Modifier.fillMaxWidth().padding(top = 4.dp), color = TM.VioletSoft)
            else androidx.compose.material3.Text("اضغط للتحديث الآن", fontSize = 12.sp, color = TM.Muted)
        }
        androidx.compose.material3.Button(onClick = { Updater.scope.launch { Updater.apply(ctx) } }, enabled = !Updater.busy) {
            androidx.compose.material3.Text("حدّث الآن")
        }
        if (!Updater.busy) androidx.compose.material3.IconButton({ Updater.dismissed = true }) {
            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.Close, "إخفاء", Modifier.size(18.dp), tint = TM.Muted)
        }
    }
}
