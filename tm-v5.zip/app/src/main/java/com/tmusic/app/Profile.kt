package com.tmusic.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

/** الملف الشخصي داخل التطبيق: اسم يختاره المستخدم (ليس اسم حساب Google) وصورة اختيارية. */
object Profile {
    var name by mutableStateOf("")
    var avatar by mutableStateOf<Bitmap?>(null)
    private var prefs: SharedPreferences? = null
    private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("tm_profile", Context.MODE_PRIVATE)
        name = prefs!!.getString("name", "") ?: ""
        val f = File(app.filesDir, "avatar.jpg")
        if (f.exists()) avatar = runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull()
    }

    fun setName(n: String) {
        name = n.trim()
        prefs?.edit()?.putString("name", name)?.apply()
    }

    /** يقصّ الصورة مربعة ويحفظها بحجم صغير داخل التطبيق. */
    fun saveAvatar(ctx: Context, uri: Uri): Boolean = runCatching {
        val app = ctx.applicationContext
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / s > 1024 || bounds.outHeight / s > 1024) s *= 2
        val opt = BitmapFactory.Options().apply { inSampleSize = s }
        val src = app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
        if (src == null) false
        else {
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 384, 384, true)
            File(app.filesDir, "avatar.jpg").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            avatar = out
            true
        }
    }.getOrDefault(false)

    fun clearAvatar(ctx: Context) {
        runCatching { File(ctx.applicationContext.filesDir, "avatar.jpg").delete() }
        avatar = null
    }
}

@Composable
fun ProfileAvatar(size: Dp, modifier: Modifier = Modifier) {
    val b = Profile.avatar
    Box(modifier.size(size).clip(CircleShape).background(TM.Violet), Alignment.Center) {
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(
            Profile.name.take(1).ifBlank { "T" }.uppercase(), color = Color.Black,
            fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp
        )
    }
}

/** تعديل الاسم والصورة. يظهر تلقائيًا بعد أول تسجيل دخول إن لم يُكتب اسم. */
@Composable
fun ProfileEditDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(Profile.name) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch(Dispatchers.IO) { Profile.saveAvatar(ctx, uri) }
    }
    AlertDialog(
        onDismissRequest = onClose, containerColor = TM.Surface,
        title = { Text("ملفك الشخصي") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.clickable { pick.launch("image/*") }) {
                    ProfileAvatar(96.dp)
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(30.dp).clip(CircleShape).background(TM.Raised),
                        Alignment.Center
                    ) { Icon(Icons.Rounded.PhotoCamera, null, Modifier.size(16.dp), tint = TM.VioletSoft) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton({ pick.launch("image/*") }) { Text(if (Profile.avatar == null) "إضافة صورة (اختياري)" else "تغيير الصورة", color = TM.VioletSoft) }
                    if (Profile.avatar != null) TextButton({ Profile.clearAvatar(ctx) }) { Text("إزالة", color = TM.Muted) }
                }
                OutlinedTextField(
                    name, { if (it.length <= 24) name = it }, singleLine = true,
                    label = { Text("اسمك في T Music") }, modifier = Modifier.fillMaxWidth()
                )
                Text("يظهر هذا الاسم داخل التطبيق فقط، وليس اسم حساب Google.", color = TM.Muted, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                Profile.setName(name)
                val app = ctx.applicationContext
                Cloud.scope.launch { Cloud.backup(app, false) }
                onClose()
            }) { Text("حفظ", color = if (name.isNotBlank()) TM.VioletSoft else TM.Muted) }
        },
        dismissButton = { TextButton(onClose) { Text("لاحقًا") } }
    )
}
