package com.tmusic.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** الرأس: تيكو + اسم التطبيق، ثم خط فاصل ناعم، ثم مبدّل T Music | T Quran. */
@Composable
fun AppHeader(section: Int, onSelect: (Int) -> Unit, onEq: () -> Unit) {
    Column(Modifier.fillMaxWidth().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.tk_icon), "تيكو", Modifier.size(40.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(10.dp))
            Text("T Music", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(40.dp).glass(CircleShape, strength = 0.8f).clickable { onEq() },
                Alignment.Center
            ) { Icon(Icons.Rounded.Equalizer, "الإيكولايزر", Modifier.size(22.dp), tint = Color.White) }
        }
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.30f), Color.Transparent)))
        )
        SectionSwitch(section, onSelect)
    }
}
