package com.tmusic.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player

/**
 * إشعار «Live Update» ثانٍ يظهر كشريحة (كبسولة) في شريط الحالة أثناء التشغيل.
 * إشعار الوسائط (MediaStyle) لا يمكن ترقيته في أندرويد 16، لذلك ننشر إشعارًا عاديًا مستمرًا
 * (بدون MediaStyle وبدون تلوين) ونطلب ترقيته. يُحذف عند الإيقاف المؤقت أو إيقاف الخدمة.
 */
class LiveUpdateNotifier(private val ctx: Context, private val player: Player) : Player.Listener {
    private val nm = NotificationManagerCompat.from(ctx)
    private var lastKey = ""
    private var closed = false   // أغلقه المستخدم بزر ✕ (يعود مع الأغنية التالية أو عند استئناف التشغيل)

    private val rx = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACT_CLOSE -> { closed = true; runCatching { nm.cancel(ID) }; lastKey = "" }
                // حذفه بالسحب: يبقى ثابتًا ولا يُغلق إلا بزر ✕
                ACT_REPOST -> { lastKey = ""; refresh() }
            }
        }
    }

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            val sys = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            runCatching { sys.deleteNotificationChannel("tm_live_chip") }
            if (sys.getNotificationChannel(CH) == null) {
                val ch = NotificationChannel(CH, "شريحة التشغيل (شريط الحالة)", NotificationManager.IMPORTANCE_DEFAULT)
                ch.setSound(null, null); ch.enableVibration(false)
                ch.setShowBadge(false)
                sys.createNotificationChannel(ch)
            }
        }
        val f = android.content.IntentFilter().apply { addAction(ACT_CLOSE); addAction(ACT_REPOST) }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else ctx.registerReceiver(rx, f)
        player.addListener(this)
        refresh()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying) closed = false; refresh() }
    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refresh()
    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { closed = false; refresh() }

    fun release() {
        player.removeListener(this)
        runCatching { ctx.unregisterReceiver(rx) }
        runCatching { nm.cancel(ID) }
        lastKey = ""
    }

    private fun bc(action: String, code: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, code, Intent(action).setPackage(ctx.packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun refresh() {
        if (!ENABLED) { runCatching { nm.cancel(ID) }; return }
        runCatching {
            if (closed || !player.isPlaying || !NowBar.notifOk(ctx)) {
                if (lastKey.isNotEmpty()) { nm.cancel(ID); lastKey = "" }
                return
            }
            val md = player.mediaMetadata
            val title = md.title?.toString().orEmpty().ifBlank { "T Music" }
            val artist = md.artist?.toString().orEmpty()
            val key = "$title|$artist"
            if (key == lastKey) return
            lastKey = key

            val art = ArtLoader.load(ctx, md, 160)
            val color = ArtLoader.accent(art)
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat_tmusic)
                .setContentTitle(title)
                .setContentText(artist.ifBlank { "يُشغَّل الآن" })
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(open)
                .setDeleteIntent(bc(ACT_REPOST, 2))
                .addAction(NotificationCompat.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "✕ إغلاق", bc(ACT_CLOSE, 1)).build())
                .setColor(color)           // لون الأيقونة فقط (بدون setColorized لأنه يمنع الترقية)
            if (art != null) b.setLargeIcon(art)

            val x = Bundle()
            // أندرويد 16+: طلب الترقية إلى Live Update + نص قصير يظهر داخل الشريحة
            x.putBoolean("android.requestPromotedOngoing", true)
            x.putString("android.shortCriticalText", title.take(10))
            // ملاحظة: حذفنا إضافات سامسونج (ongoingActivityNoti) لأنها تحوّل البطاقة إلى نمط يخفي الأزرار؛
            // نعتمد على مسار Live Updates القياسي في أندرويد 16+ فقط.
            b.addExtras(x)

            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < 33)
                nm.notify(ID, b.build())
        }
    }

    companion object {
        /** الإشعار الثاني معطّل افتراضيًا (التجربة: الاعتماد على إشعار الوسائط كما يفعل Lark). غيّرها إلى true لإعادته. */
        private const val ENABLED = false
        /** فحص حيّ: هل الإشعار منشور؟ هل هو قابل للترقية؟ هل رقّاه النظام فعلًا؟ */
        fun diagnose(ctx: Context): String = runCatching {
            val sys = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val flag = runCatching { Notification::class.java.getField("FLAG_PROMOTED_ONGOING").getInt(null) }.getOrNull()
            val list = sys.activeNotifications.filter { it.packageName == ctx.packageName }
            if (list.isEmpty()) return "بناء v130 | لا توجد إشعارات: شغّل أغنية أولًا."
            "بناء v130 | أندرويد ${Build.VERSION.SDK_INT}\n" + list.joinToString("\n") { sbn ->
                val n = sbn.notification
                val promotable = runCatching { n.javaClass.getMethod("hasPromotableCharacteristics").invoke(n) as Boolean }.getOrNull()
                val promoted = flag?.let { (n.flags and it) != 0 }
                val colorized = n.extras.getBoolean("android.colorized")
                "#${sbn.id}: قابل للترقية=${promotable ?: "؟"} | مرقّى=${promoted ?: "؟"} | ملوّن=$colorized | أزرار=${n.actions?.size ?: 0}"
            }
        }.getOrElse { "تعذّر الفحص: ${it.message}" }
    }
}
