package com.tmusic.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object TM {
    /** 0 الافتراضي، 1 داكن عميق، 2 AMOLED أسود، 3 ألوان حسب الوقت */
    var mode by mutableIntStateOf(0)
    var vinyl by mutableStateOf(false)
    var fade by mutableStateOf(false)
    fun applyFade(v: Boolean) { fade = v; prefs?.edit()?.putBoolean("fade", v)?.apply() }
    fun applyVinyl(v: Boolean) { vinyl = v; prefs?.edit()?.putBoolean("vinyl", v)?.apply() }
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("tm_theme", Context.MODE_PRIVATE)
        mode = prefs!!.getInt("mode", 0)
        vinyl = prefs!!.getBoolean("vinyl", false)
        fade = prefs!!.getBoolean("fade", false)
    }
    fun applyMode(m: Int) { mode = m; prefs?.edit()?.putInt("mode", m)?.apply() }

    /** النمط الفعلي: في وضع الوقت: نهارًا افتراضي، مساءً عميق، ليلًا أسود. */
    private fun eff(): Int = if (mode != 3) mode else {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when { h in 6..16 -> 0; h in 17..21 -> 1; else -> 2 }
    }
    private fun hour() = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)

    // هوية iOS: خلفية سوداء (systemBackground)، طبقات رمادية (grouped)، لون واحد للتمييز (systemBlue).
    // اللون الملوّن الإضافي يأتي من غلاف الأغنية فقط.
    val Ink: Color get() = when (eff()) { 2 -> Color(0xFF000000); 1 -> Color(0xFF000000); else -> Color(0xFF000000) }
    val Surface: Color get() = when (eff()) { 2 -> Color(0xFF0A0A0C); 1 -> Color(0xFF141416); else -> Color(0xFF1C1C1E) }
    val Raised: Color get() = when (eff()) { 2 -> Color(0xFF1C1C1E); 1 -> Color(0xFF232325); else -> Color(0xFF2C2C2E) }
    val Deep: Color get() = when (eff()) { 2 -> Color(0xFF0A0A0C); 1 -> Color(0xFF1C1C1E); else -> Color(0xFF1C1C1E) }
    val Signal = Color(0xFF0A84FF)          // systemBlue — غيّر هذا السطر لتغيير لون التطبيق كله
    val Violet: Color get() = Signal
    val VioletSoft: Color get() = Color(0xFF64A8FF)
    val Blue: Color get() = Color(0xFF5E5CE6)
    val Emerald = Color(0xFF30D158)         // systemGreen
    val Gold = Color(0xFFFFD60A)            // systemYellow
    val Text = Color(0xFFFFFFFF)            // label
    val Muted = Color(0xFF8E8E93)           // secondaryLabel
    val Separator = Color(0x29EBEBF5)       // separator
}

@Composable
fun TMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = TM.Violet, onPrimary = Color.White,
            background = TM.Ink, onBackground = TM.Text,
            surface = TM.Surface, onSurface = TM.Text,
            surfaceVariant = TM.Raised, onSurfaceVariant = TM.Muted
        ),
        typography = Typography(
            headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp),   // Large Title
            titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp),       // Title 2
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp),  // Headline
            bodyMedium = TextStyle(fontSize = 15.sp),                                     // Subheadline
            bodySmall = TextStyle(fontSize = 13.sp)                                       // Footnote
        ),
        shapes = androidx.compose.material3.Shapes(
            small = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            large = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
