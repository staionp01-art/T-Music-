package com.tmusic.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** أنواع الترتيب كما في قائمة «Songs sort» في Lark، مع اتجاه تصاعدي/تنازلي لكل نوع. */
enum class SongSort(val label: String) {
    NEWEST("الأحدث"), MOST_PLAYED("الأكثر تشغيلًا"), TITLE("أ إلى ي"), ARTIST("الفنان"),
    ALBUM("الألبوم"), LONGEST("الأطول مدة"), SHUFFLE("عشوائي")
}

object SongSortPrefs {
    private var prefs: android.content.SharedPreferences? = null
    var sort by mutableStateOf(SongSort.NEWEST); private set
    /** true = الاتجاه الافتراضي للنوع (الأحدث أولًا، الأكثر أولًا، أ→ي ...) */
    var natural by mutableStateOf(true); private set
    var seed by mutableIntStateOf(1); private set
    /** يُطلب من زر الترتيب في الرأس: تفتح صفحة الأغاني نافذة الترتيب مرة واحدة. */
    var openSheet by mutableStateOf(false)

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tm_songsort", Context.MODE_PRIVATE)
        prefs = p
        sort = SongSort.values().getOrElse(p.getInt("sort", 0)) { SongSort.NEWEST }
        natural = p.getBoolean("natural", true)
    }

    fun choose(s: SongSort) {
        if (s == sort) natural = !natural else { sort = s; natural = true }
        if (s == SongSort.SHUFFLE) seed = (System.nanoTime() % 100000).toInt()
        prefs?.edit()?.putInt("sort", sort.ordinal)?.putBoolean("natural", natural)?.apply()
    }

    fun apply(list: List<Song>, plays: Map<Long, Int>): List<Song> {
        val base = when (sort) {
            SongSort.NEWEST -> list.sortedByDescending { it.added }
            SongSort.MOST_PLAYED -> list.sortedByDescending { plays[it.id] ?: 0 }
            SongSort.TITLE -> list.sortedBy { it.title.lowercase() }
            SongSort.ARTIST -> list.sortedBy { it.artist.lowercase() }
            SongSort.ALBUM -> list.sortedBy { it.album.lowercase() }
            SongSort.LONGEST -> list.sortedByDescending { it.duration }
            SongSort.SHUFFLE -> list.shuffled(java.util.Random(seed.toLong()))
        }
        return if (natural || sort == SongSort.SHUFFLE) base else base.reversed()
    }
}

/** صفحة «الأغاني»: بحث سريع + ترتيب + قائمة كبيرة الأغلفة. */
@Composable
fun SongsPage(all: List<Song>, ui: PlayerUi) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { SongSortPrefs.init(ctx) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf(false) }
    LaunchedEffect(SongSortPrefs.openSheet) { if (SongSortPrefs.openSheet) { sheet = true; SongSortPrefs.openSheet = false } }
    val sorted = remember(all, SongSortPrefs.sort, SongSortPrefs.natural, SongSortPrefs.seed, ui.plays.size) {
        SongSortPrefs.apply(all, ui.plays)
    }
    val shown = remember(sorted, query) {
        if (query.isBlank()) sorted else sorted.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (searching) {
                OutlinedTextField(
                    query, { query = it }, Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("ابحث في أغانيك") },
                    shape = RoundedCornerShape(20.dp)
                )
            } else {
                Column(Modifier.weight(1f)) {
                    Text("${shown.size} أغنية", fontWeight = FontWeight.SemiBold)
                    Text(
                        SongSortPrefs.sort.label + if (SongSortPrefs.sort == SongSort.SHUFFLE) "" else if (SongSortPrefs.natural) " ↓" else " ↑",
                        color = TM.Muted, fontSize = 12.sp
                    )
                }
            }
            IconButton({ searching = !searching; if (!searching) query = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, null)
            }
            IconButton({ sheet = true }) { Icon(Icons.Rounded.SortByAlpha, "ترتيب") }
            IconButton({ ui.play(shown, 0, true) }, enabled = shown.isNotEmpty()) { Icon(Icons.Rounded.Shuffle, "عشوائي") }
        }
        LazyColumn(contentPadding = PaddingValues(top = 6.dp, bottom = 12.dp)) {
            items(shown, key = { it.id }) { s ->
                BigSongRow(s, ui.currentId == s.id, ui.isPlaying) { ui.play(shown, shown.indexOf(s)) }
            }
        }
    }
    if (sheet) SortSheet { sheet = false }
}

/** صف أغنية بغلاف كبير (مثل Lark). */
@Composable
fun BigSongRow(song: Song, active: Boolean, playing: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(song, Modifier.size(78.dp), 16.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (active) Color.White else TM.Text
            )
            Spacer(Modifier.height(3.dp))
            Text(
                song.artist + if (song.album.isNotBlank()) " - ${song.album}" else "",
                color = TM.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (active) Icon(if (playing) Icons.Rounded.GraphicEq else Icons.Rounded.Pause, null, tint = Color.White)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SortSheet(onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss, sheetState = state,
        containerColor = Color(0xFF1B1B1D), contentColor = Color.White,
        dragHandle = { Icon(Icons.Rounded.KeyboardArrowDown, null, Modifier.padding(top = 10.dp).size(30.dp), tint = Color.White.copy(0.6f)) }
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 18.dp)) {
            Text("ترتيب الأغاني", Modifier.padding(horizontal = 24.dp, vertical = 14.dp), fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            SongSort.values().forEach { s ->
                val sel = SongSortPrefs.sort == s
                Row(
                    Modifier.fillMaxWidth().clickable { SongSortPrefs.choose(s) }.padding(horizontal = 24.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        s.label, Modifier.weight(1f), fontSize = 18.sp,
                        color = if (sel) Color(0xFF4DB6FF) else Color.White.copy(0.75f),
                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                    )
                    if (sel && s != SongSort.SHUFFLE) {
                        Icon(Icons.Rounded.SwapVert, "عكس الاتجاه", tint = Color(0xFF4DB6FF), modifier = Modifier.size(26.dp))
                    }
                    if (sel && s == SongSort.SHUFFLE) Icon(Icons.Rounded.Shuffle, null, tint = Color(0xFF4DB6FF))
                }
            }
            Text("اضغط على النوع المحدد مرة أخرى لعكس الاتجاه.", Modifier.padding(horizontal = 24.dp), color = TM.Muted, fontSize = 12.sp)
        }
    }
}

/** المجلدات: الأغاني مجمّعة حسب مجلدها على الجهاز. */
@Composable
fun FoldersPage(all: List<Song>, ui: PlayerUi) {
    val groups = remember(all) {
        all.groupBy { s ->
            val p = s.path
            val i = p.lastIndexOf('/')
            if (i > 0) p.substring(0, i) else "غير معروف"
        }.toList().sortedBy { it.first.lowercase() }
    }
    var open by remember { mutableStateOf<String?>(null) }
    val cur = groups.firstOrNull { it.first == open }
    if (cur != null) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().clickable { open = null }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.ArrowForward, null)
                Spacer(Modifier.width(10.dp))
                Text(cur.first.substringAfterLast('/').ifBlank { cur.first }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                items(cur.second, key = { it.id }) { s ->
                    SongRow(s, ui.currentId == s.id, ui.isPlaying) { ui.play(cur.second, cur.second.indexOf(s)) }
                }
            }
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
            items(groups, key = { it.first }) { (path, list) ->
                Row(
                    Modifier.fillMaxWidth().clickable { open = path }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(52.dp).background(Color.White.copy(0.08f), RoundedCornerShape(14.dp)), Alignment.Center) {
                        Icon(Icons.Rounded.Folder, null, tint = Color.White.copy(0.85f))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(path.substringAfterLast('/').ifBlank { path }, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${list.size} أغنية · $path", color = TM.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
