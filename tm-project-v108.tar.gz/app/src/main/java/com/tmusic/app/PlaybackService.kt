package com.tmusic.app

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        Eq.attach(applicationContext, player.audioSessionId)
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Eq.attach(applicationContext, audioSessionId) }
        })
        session = MediaSession.Builder(this, player).build()
        // أيقونة التطبيق في إشعار التشغيل وشريط الحالة (وفي شريحة سامسونج)
        // إشعار ملوّن بلون الأغنية + إضافات سامسونج/أندرويد 16 للشريحة العلوية
        setMediaNotificationProvider(LiveMediaProvider(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.tmusic.app.SEEK") {
            val p = session?.player
            if (p == null || p.mediaItemCount == 0) { stopSelf(startId); return START_NOT_STICKY }
            val d = p.duration
            if (d != C.TIME_UNSET && d > 0) {
                val pos = (d * intent.getFloatExtra("f", 0f)).toLong()
                p.seekTo(pos)
                PlayerWidget.pushProgress(applicationContext, pos, d)
            }
            return START_NOT_STICKY
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        AppState.onChange = null
        session?.run { player.release(); release() }
        session = null
        Eq.release()
        super.onDestroy()
    }
}
