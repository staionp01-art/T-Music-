package com.tmusic.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.isActive
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle

/** الرأس: شعار T Music (أسطوانة زجاجية) + الاسم، ثم خط فاصل ناعم، ثم مبدّل T Music | T Quran. */
@Composable
fun AppHeader(section: Int, onSelect: (Int) -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxWidth().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TMDisc(42.dp)
            Spacer(Modifier.width(12.dp))
            TMWordmark()
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(42.dp).liquidPress(0.86f) { onSettings() }.glass(CircleShape, strength = 1.2f),
                Alignment.Center
            ) { Icon(Icons.Rounded.SwapVert, "ترتيب الأغاني", Modifier.size(24.dp), tint = Color.White) }
        }
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.30f), Color.Transparent)))
        )
        SectionSwitch(section, onSelect)
    }
}

private val BlackFace = FontFamily(android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL))
private val CondensedFace = FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD))

/** اسم التطبيق: «T» كريمي بخط Black ثم «-MUSIC» بخط مكثّف متباعد الأحرف. */
@Composable
fun TMWordmark() {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = TM.Signal, fontFamily = BlackFace, fontSize = 30.sp)) { append("T") }
            withStyle(SpanStyle(color = Color.White.copy(alpha = 0.5f), fontFamily = CondensedFace, fontSize = 22.sp)) { append("-") }
            withStyle(SpanStyle(color = Color.White, fontFamily = CondensedFace, fontSize = 23.sp, letterSpacing = 3.sp)) { append("MUSIC") }
        }
    )
}

/**
 * شعار أسطوانة تفاعلي: تدور وحدها أثناء التشغيل وتتوقف مع الإيقاف، اضغط عليها تأخذ دفعة دوران،
 * وجرّ الإصبع فوقها لـ«خدش» الأسطوانة (تدور مع إصبعك وتكمل بالقصور الذاتي عند الإفلات).
 */
@Composable
fun TMDisc(size: androidx.compose.ui.unit.Dp) {
    val haptic = LocalHapticFeedback.current
    var angle by remember { mutableFloatStateOf(0f) }
    var omega by remember { mutableFloatStateOf(0f) }      // درجة/ثانية
    var dragging by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var kick by remember { mutableIntStateOf(0) }
    val playing = activeUi?.isPlaying == true
    val squish by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.4f, stiffness = 380f), label = "disc-squish")

    LaunchedEffect(playing, kick) {
        var last = 0L
        while (isActive && (playing || abs(omega) > 1f || dragging)) {
            val t = withFrameNanos { it }
            if (last != 0L && !dragging) {
                val dt = ((t - last) / 1_000_000_000f).coerceAtMost(0.05f)
                val target = if (activeUi?.isPlaying == true && Glass.motion) 140f else 0f
                omega += (target - omega) * (1f - exp(-1.8f * dt))
                angle = (angle + omega * dt) % 360f
            }
            last = t
        }
    }

    Canvas(
        Modifier.size(size).graphicsLayer { scaleX = squish; scaleY = squish }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    var lastX = down.position.x
                    var vel = 0f
                    var moved = false
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        val dx = ch.position.x - lastX
                        lastX = ch.position.x
                        if (!moved && abs(ch.position.x - down.position.x) > viewConfiguration.touchSlop) { moved = true; dragging = true }
                        if (moved) {
                            angle += dx * 1.4f
                            vel = vel * 0.6f + dx * 0.4f
                            ch.consume()
                        }
                    }
                    pressed = false
                    if (moved) { dragging = false; omega = (vel * 110f).coerceIn(-1400f, 1400f) }
                    else { omega += 900f; haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
                    kick++
                }
            }
    ) {
        val r = this.size.minDimension / 2f
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF2A2A2A), Color(0xFF0A0A0A)), center = c, radius = r), r, c)
        for (k in 1..3) drawCircle(Color.White.copy(alpha = 0.07f), r * (0.45f + 0.15f * k), c, style = Stroke(0.8.dp.toPx()))
        val a = angle
        val tl = Offset(c.x - r * 0.9f, c.y - r * 0.9f)
        val sz = Size(r * 1.8f, r * 1.8f)
        drawArc(Color.White.copy(alpha = 0.40f), a, 40f, false, tl, sz, style = Stroke(2.4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
        drawArc(Color.White.copy(alpha = 0.20f), a + 180f, 40f, false, tl, sz, style = Stroke(2.4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
        // نقطة تدور على الحافة لتُرى الحركة بوضوح
        val rad = Math.toRadians(a.toDouble())
        drawCircle(TM.Signal, 2.2.dp.toPx(), Offset(c.x + (r * 0.74f * cos(rad)).toFloat(), c.y + (r * 0.74f * sin(rad)).toFloat()))
        drawCircle(Color.White.copy(alpha = 0.22f), r, c, style = Stroke(1.dp.toPx()))
        // لمعة زجاجية ثابتة
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Transparent), center = Offset(c.x - r * 0.4f, c.y - r * 0.5f), radius = r * 0.9f),
            r, c
        )
        // الملصق الكريمي وحرف T
        val lr = r * 0.46f
        drawCircle(TM.Signal, lr, c)
        val bw = lr * 1.1f; val bh = lr * 0.26f
        drawRoundRect(Color.Black, Offset(c.x - bw / 2f, c.y - lr * 0.5f), Size(bw, bh), CornerRadius(bh / 2f))
        drawRoundRect(Color.Black, Offset(c.x - bh / 2f, c.y - lr * 0.5f), Size(bh, lr * 1.05f), CornerRadius(bh / 2f))
    }
}

/** تحية الرئيسية بدل تيكو: نص قصير + زر الحساب. */
@Composable
fun HomeGreeting(onAccount: () -> Unit) {
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greet = when { hour < 5 -> "ليلة هادئة"; hour < 12 -> "صباح الخير"; hour < 18 -> "طاب يومك"; else -> "مساء الخير" }
    val hello = if (Profile.name.isNotBlank()) "$greet يا ${Profile.name}" else greet
    Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(hello, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onAccount) {
            if (Cloud.signedIn) ProfileAvatar(34.dp)
            else Icon(Icons.Rounded.AccountCircle, "الحساب", Modifier.size(32.dp), tint = TM.Muted)
        }
    }
}
