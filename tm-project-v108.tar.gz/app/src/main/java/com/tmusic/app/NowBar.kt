package com.tmusic.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

/** مساعد صلاحيات Now Bar (سامسونج) والإشعارات المميّزة (أندرويد 16). */
object NowBar {
    fun notifOk(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun isSamsung(): Boolean = Build.MANUFACTURER.equals("samsung", ignoreCase = true)

    /** يفتح أنسب صفحة إعدادات متاحة على الجهاز: الإشعارات المميّزة ثم إشعارات التطبيق ثم تفاصيل التطبيق. */
    fun openSettings(ctx: Context) {
        val pkg = ctx.packageName
        val tries = listOf(
            Intent("android.settings.MANAGE_APP_PROMOTED_NOTIFICATIONS").putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg),
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg),
            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
        for (i in tries) {
            val ok = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
            if (ok) return
        }
    }
}

/** نافذة تظهر مرة واحدة على أجهزة سامسونج وأندرويد 16: تطلب إذن الإشعارات وتفتح صفحة تفعيل Now Bar. */
@Composable
fun NowBarPrompt() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("tm_nowbar", Context.MODE_PRIVATE) }
    var show by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { NowBar.openSettings(ctx) }
    LaunchedEffect(Unit) {
        if (!sp.getBoolean("asked", false) && (NowBar.isSamsung() || Build.VERSION.SDK_INT >= 36)) {
            delay(2500)
            show = true
        }
    }
    if (!show) return
    fun done() { sp.edit().putBoolean("asked", true).apply(); show = false }
    AlertDialog(
        onDismissRequest = { done() },
        containerColor = TM.Surface,
        title = { Text("تفعيل Now Bar") },
        text = { Text("لتظهر أغنيتك في شريط Now Bar وشريحة شريط الحالة: اسمح بالإشعارات، ثم فعّل «الإشعارات الحيّة» لـ T Music من الصفحة التي ستُفتح. يمكنك فعل ذلك لاحقًا من الإعدادات.") },
        confirmButton = {
            TextButton({
                done()
                if (!NowBar.notifOk(ctx)) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else NowBar.openSettings(ctx)
            }) { Text("تفعيل الآن", color = TM.VioletSoft) }
        },
        dismissButton = { TextButton({ done() }) { Text("لاحقًا", color = TM.Muted) } }
    )
}
