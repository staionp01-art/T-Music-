package com.tmusic.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * لمس «زجاج سائل» على طريقة iOS: العنصر ينضغط بنابض مرن، ينحرف قليلًا نحو الإصبع،
 * وتلمع نقطة ضوء تتبع الإصبع أثناء اللمس ثم تتلاشى. يلغي النقر إذا سحب الإصبع أو أخذ التمرير الحدث.
 */
fun Modifier.liquidPress(scaleDown: Float = 0.94f, onClick: () -> Unit): Modifier = composed {
    var pos by remember { mutableStateOf(Offset.Zero) }
    var pressed by remember { mutableStateOf(false) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val cb by rememberUpdatedState(onClick)
    val s by animateFloatAsState(if (pressed) scaleDown else 1f, spring(dampingRatio = 0.42f, stiffness = 420f), label = "lp-scale")
    val glow by animateFloatAsState(if (pressed) 1f else 0f, tween(if (pressed) 90 else 420), label = "lp-glow")
    this
        .onSizeChanged { box = it }
        .graphicsLayer {
            val w = box.width.coerceAtLeast(1); val h = box.height.coerceAtLeast(1)
            val dx = pos.x / w - 0.5f
            val dy = pos.y / h - 0.5f
            scaleX = s * (1f + 0.025f * glow)
            scaleY = s * (1f - 0.012f * glow)
            translationX = dx * 8f * glow
            translationY = dy * 8f * glow
        }
        .drawWithContent {
            drawContent()
            if (glow > 0.01f && Glass.tier >= 1) {
                val r = size.minDimension * 0.95f
                drawCircle(
                    Brush.radialGradient(listOf(Color.White.copy(alpha = 0.34f * glow), Color.White.copy(alpha = 0.10f * glow), Color.Transparent), center = pos, radius = r),
                    radius = r, center = pos
                )
            }
        }
        .semantics(mergeDescendants = true) { role = Role.Button; onClick { cb(); true } }
        .pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                pos = down.position
                pressed = true
                var ok = false
                val slop = viewConfiguration.touchSlop * 4f
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (ch.isConsumed) break
                    pos = ch.position
                    if ((ch.position - down.position).getDistance() > slop) break
                    if (!ch.pressed) { ok = true; break }
                }
                pressed = false
                if (ok) cb()
            }
        }
}

/** عدّاد الإطارات الحقيقي (يظهر من الإعدادات) ليتأكد المستخدم أن معدل الفريمات مطبّق فعلًا. */
@Composable
fun FpsMeter() {
    if (!Glass.showFps) return
    var fps by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var n = 0
        var t0 = 0L
        while (true) {
            val t = withFrameNanos { it }
            if (t0 == 0L) t0 = t
            n++
            if (t - t0 >= 500_000_000L) {
                fps = (n * 1_000_000_000L / (t - t0)).toInt()
                n = 0; t0 = t
            }
        }
    }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(start = 12.dp, top = 2.dp), Alignment.TopStart) {
        Text(
            "$fps FPS", color = Color(0xFF7CFFB2), fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.glass(RoundedCornerShape(10.dp), tint = Color.Black, strength = 1.4f).padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
