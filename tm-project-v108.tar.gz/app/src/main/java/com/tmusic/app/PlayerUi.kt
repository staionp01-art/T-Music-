package com.tmusic.app

import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

@Stable
class PlayerUi(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("tm", Context.MODE_PRIVATE)
    private val appCtx = ctx.applicationContext
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var lyr: Lyrics? = null
    private var lastLine = -2
    private var baseId = ""
    private var baseArtist = ""
    private var restoring = false
    private var restored = false
    private var saveTick = 0

    var controller by mutableStateOf<MediaController?>(null)
        private set
    var currentId by mutableLongStateOf(-1L)
    var isPlaying by mutableStateOf(false)
    /** الأغنية التي أغلق المستخدم مشغّلها المصغّر (يعود عند تشغيل أي شيء). */
    var dismissedId by mutableLongStateOf(-1L)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var recents by mutableStateOf(readRecents())
    var plays by mutableStateOf(readPlays())

    /** يزداد كلما اختار المستخدم أغنية، لتفتح شاشة التشغيل مباشرة. */
    var openRequest by mutableIntStateOf(0)
        private set

    /** أغاني الإنترنت التي شُغّلت، لنجد الأغنية الحالية بمعرّفها. */
    val online = HashMap<Long, Song>()

    /** اتجاه آخر تغيير للأغنية: 1 = التالي، -1 = السابق (يستعمله تأثير الانتقال). */
    var dir by mutableIntStateOf(1)
        private set

    // قسم القرآن: السورة والآية الجاري تشغيلهما (0 = لا شيء / البسملة)
    var quranSurah by mutableIntStateOf(0)
        private set
    var quranAyah by mutableIntStateOf(0)
        private set
    var reciterIdx by mutableIntStateOf(prefs.getInt("reciter", 0).coerceIn(0, Quran.reciters.lastIndex))
        private set

    fun setReciter(i: Int) {
        reciterIdx = i.coerceIn(0, Quran.reciters.lastIndex)
        prefs.edit().putInt("reciter", reciterIdx).apply()
    }

    private fun readRecents(): List<Long> =
        (prefs.getString("recent", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    private fun readPlays(): Map<Long, Int> =
        (prefs.getString("plays", "") ?: "").split(",").mapNotNull {
            val p = it.split(":"); val i = p.getOrNull(0)?.toLongOrNull(); val n = p.getOrNull(1)?.toIntOrNull()
            if (i != null && n != null) i to n else null
        }.toMap()

    private fun countPlay(id: Long) {
        plays = plays + (id to ((plays[id] ?: 0) + 1))
        prefs.edit().putString("plays", plays.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    private fun pushRecent(id: Long) {
        countPlay(id)
        recents = (listOf(id) + recents.filter { it != id }).take(12)
        prefs.edit().putString("recent", recents.joinToString(",")).apply()
    }

    /** معرّف القرآن بصيغة q:السورة:الآية، وأي معرّف آخر فهو أغنية. */
    private fun onItem(mediaId: String?, record: Boolean) {
        if (mediaId == null) return
        if (mediaId.startsWith("q:")) {
            val p = mediaId.split(":")
            quranSurah = p.getOrNull(1)?.toIntOrNull() ?: 0
            quranAyah = p.getOrNull(2)?.toIntOrNull() ?: 0
            currentId = -1L
            prefs.edit().putString("lastq", "$quranSurah:${quranAyah.coerceAtLeast(1)}").apply()
            QuranWidget.push(appCtx)
        } else {
            quranSurah = 0; quranAyah = 0
            mediaId.toLongOrNull()?.let { currentId = it; if (record) pushRecent(it) }
        }
        lyr = if (mediaId.startsWith("q:")) null else mediaId.toLongOrNull()?.let { runCatching { LyricsStore.load(appCtx, it) }.getOrNull() }
        lastLine = -2
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@PlayerUi.isPlaying = isPlaying
            if (isPlaying) dismissedId = -1L
            PlayerWidget.push(appCtx, controller)
            if (isPlaying) { handler.removeCallbacks(ticker); handler.post(ticker) } else { handler.removeCallbacks(ticker); saveQueue() }
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // تحديث وصف الأغنية الحالية (سطر الكلمات) ليس انتقالًا فعليًا
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED && mediaItem?.mediaId == baseId && !restoring) return
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) dir = 1
            onItem(mediaItem?.mediaId, record = !restoring)
            restoring = false
            saveQueue()
            PlayerWidget.push(appCtx, controller)
            syncPosition()
        }
        override fun onPlaybackStateChanged(playbackState: Int) = syncPosition()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
        override fun onRepeatModeChanged(repeatMode: Int) { repeat = repeatMode }
    }

    fun attach(c: MediaController) {
        controller = c
        c.addListener(listener)
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeat = c.repeatMode
        applySpeed()
        onItem(c.currentMediaItem?.mediaId, record = false)
        syncPosition()
    }

    /** يطبّق سرعة التشغيل المحفوظة في الإعدادات على المشغّل. */
    fun applySpeed() {
        val c = controller ?: return
        val s = AppPrefs.speed
        runCatching { c.playbackParameters = PlaybackParameters(s, if (AppPrefs.keepPitch) 1f else s) }
    }

    private val ticker = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 100) }
    }

    private fun tick() {
        val c = controller ?: return
        if (!c.isPlaying) return
        val pos = c.currentPosition; val dur = c.duration
        val isQuran = c.currentMediaItem?.mediaId?.startsWith("q:") == true
        if (TM.fade && dur > 0 && !isQuran) {
            val out = ((dur - pos) / 3000f).coerceIn(0f, 1f)
            val inn = (pos / 1500f).coerceIn(0f, 1f)
            c.volume = minOf(out, inn)
        } else if (c.volume != 1f) c.volume = 1f
        val l = lyr
        if (l != null && l.synced) {
            val idx = l.lines.indexOfLast { it.timeMs <= pos + 250 }
            if (idx != lastLine) { lastLine = idx; setLine(l.lines.getOrNull(idx)?.text?.takeIf { it != "♪" }) }
        }
        saveTick++
        if (saveTick % 20 == 0) PlayerWidget.pushProgress(appCtx, pos, dur)
        if (saveTick % 50 == 0) saveQueue()
    }

    /** يعرض سطر الكلمات الحالي في إشعار التشغيل وعلى الشاشة المقفلة (مكان اسم الفنان). */
    private fun setLine(text: String?) {
        val c = controller ?: return
        val cur = c.currentMediaItem ?: return
        if (cur.mediaId.startsWith("q:")) return
        if (cur.mediaId != baseId) { baseId = cur.mediaId; baseArtist = cur.mediaMetadata.artist?.toString() ?: "" }
        val md = cur.mediaMetadata.buildUpon().setArtist(if (text.isNullOrBlank()) baseArtist else "♪ $text").build()
        runCatching { c.replaceMediaItem(c.currentMediaItemIndex, cur.buildUpon().setMediaMetadata(md).build()) }
    }

    fun reloadLyrics() {
        lyr = runCatching { LyricsStore.load(appCtx, currentId) }.getOrNull(); lastLine = -2
    }

    private fun saveQueue() {
        val c = controller ?: return
        val n = c.mediaItemCount; if (n == 0) return
        val cur = c.currentMediaItemIndex
        val ids = ArrayList<Long>(); var idx = 0
        for (i in 0 until n) {
            val id = c.getMediaItemAt(i).mediaId.toLongOrNull()
            if (id != null && id > 0) { if (i == cur) idx = ids.size; ids.add(id) } else if (i == cur) return
        }
        if (ids.isEmpty() || idx >= 500) return
        prefs.edit().putString("q_ids", ids.take(500).joinToString(",")).putInt("q_idx", idx).putLong("q_pos", c.currentPosition).apply()
    }

    /** استئناف تلقائي: يعيد آخر قائمة تشغيل وموضعها (دون تشغيل) عند فتح التطبيق. */
    fun restore(songs: List<Song>) {
        if (restored) return
        val c = controller ?: return
        if (songs.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return
        val ids = (prefs.getString("q_ids", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
        if (ids.isEmpty()) return
        val byId = songs.associateBy { it.id }
        val saved = prefs.getInt("q_idx", 0)
        val items = ArrayList<MediaItem>(); var start = 0; var found = false
        ids.forEachIndexed { i, id -> byId[id]?.let { if (i == saved) { start = items.size; found = true }; items.add(item(it)) } }
        if (items.isEmpty()) return
        restoring = true
        c.setMediaItems(items, start.coerceIn(items.indices), if (found) prefs.getLong("q_pos", 0L) else 0L)
        c.prepare()
    }

    fun detach() {
        handler.removeCallbacks(ticker)
        controller?.removeListener(listener)
        controller = null
    }

    fun syncPosition() {
        controller?.let { position = it.currentPosition; duration = it.duration.coerceAtLeast(0L) }
    }

    private fun item(s: Song) = MediaItem.Builder()
        .setUri(s.uri).setMediaId(s.id.toString())
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setArtworkUri(s.art).build())
        .build()

    fun playNext(s: Song) {
        val c = controller ?: return
        if (s.remoteUrl != null) online[s.id] = s
        val empty = c.mediaItemCount == 0
        c.addMediaItem(if (empty) 0 else c.currentMediaItemIndex + 1, item(s))
        if (empty) { c.prepare(); c.play(); openRequest++ }
    }

    fun addToQueue(s: Song) {
        val c = controller ?: return
        if (s.remoteUrl != null) online[s.id] = s
        val empty = c.mediaItemCount == 0
        c.addMediaItem(item(s))
        if (empty) { c.prepare(); c.play(); openRequest++ }
    }

    fun play(list: List<Song>, index: Int, shuffleMode: Boolean? = null) {
        val c = controller ?: return
        if (list.isEmpty()) return
        list.forEach { if (it.remoteUrl != null) online[it.id] = it }
        if (shuffleMode != null) c.shuffleModeEnabled = shuffleMode
        c.setMediaItems(list.map(::item), index.coerceIn(list.indices), 0)
        c.prepare(); c.play()
        openRequest++
    }

    /** يشغّل السورة آية بعد آية (مع البسملة في البداية) بصوت القارئ المختار. */
    fun playQuran(surah: Int, startAyah: Int = 1) {
        val c = controller ?: return
        val info = Quran.surahs.getOrNull(surah - 1) ?: return
        val reciter = Quran.reciters[reciterIdx]
        fun q(s: Int, a: Int, urlSurah: Int, urlAyah: Int, label: String) = MediaItem.Builder()
            .setUri(Quran.audioUrl(reciter.folder, urlSurah, urlAyah))
            .setMediaId("q:$s:$a")
            .setMediaMetadata(MediaMetadata.Builder().setTitle("سورة ${info.name} - $label").setArtist(reciter.name).build())
            .build()
        val bism = Quran.hasBasmala(surah)
        val items = buildList {
            if (bism) add(q(surah, 0, 1, 1, "البسملة"))
            for (a in 1..info.ayahs) add(q(surah, a, surah, a, "آية ${Quran.digits(a)}"))
        }
        val start = if (startAyah <= 1) 0 else (startAyah - 1) + (if (bism) 1 else 0)
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItems(items, start.coerceIn(items.indices), 0)
        c.prepare(); c.play()
        applySpeed()
    }

    fun closeMini() { controller?.pause(); dismissedId = currentId }
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { dir = 1; controller?.seekToNext() }
    /** السابق ينقل مباشرة إلى الأغنية السابقة (لا يعيد الأغنية الحالية إلى بدايتها). */
    fun previous() {
        dir = -1
        val c = controller ?: return
        if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem() else c.seekTo(0)
    }
    fun seek(ms: Long) { controller?.seekTo(ms); position = ms }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
}

@Composable
fun rememberPlayerUi(): PlayerUi {
    val ctx = LocalContext.current
    val ui = remember { PlayerUi(ctx.applicationContext) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({ runCatching { ui.attach(f.get()) } }, ContextCompat.getMainExecutor(ctx))
        onDispose { ui.detach(); MediaController.releaseFuture(f) }
    }
    return ui
}
