package com.tmusic.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun HomeTab(songs: List<Song>, albums: List<Album>, byId: Map<Long, Song>, ui: PlayerUi) {
    var showMp3 by remember { mutableStateOf(false) }
    if (showMp3) Mp3Sheet { showMp3 = false }
    var showAccount by remember { mutableStateOf(false) }
    if (showAccount) AccountDialog { showAccount = false }
    if (songs.isEmpty()) {
        EmptyState(Icons.Rounded.LibraryMusic, "لا توجد أغانٍ على جهازك", "انسخ ملفات صوتية إلى الهاتف وستظهر هنا مباشرة.")
        return
    }
    val quick = remember(ui.recents, songs) {
        ui.recents.mapNotNull { byId[it] }.ifEmpty { songs }.take(6)
    }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = when { hour < 5 -> "ليلة هادئة"; hour < 12 -> "صباح الخير"; hour < 18 -> "طاب يومك"; else -> "مساء الخير" }

    LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            Row(Modifier.fadeUp(0).padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.tm_logo), "T Music",
                    Modifier.size(56.dp)
                        .shadow(14.dp, RoundedCornerShape(percent = 22), ambientColor = TM.Violet, spotColor = TM.Violet)
                        .clip(RoundedCornerShape(percent = 22))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(greet, color = TM.Muted)
                    Text(
                        "T Music",
                        style = MaterialTheme.typography.headlineMedium.copy(brush = Brush.horizontalGradient(listOf(TM.VioletSoft, TM.Blue)))
                    )
                }
                IconButton(onClick = { showAccount = true }) {
                    Icon(Icons.Rounded.AccountCircle, "الحساب", Modifier.size(32.dp), tint = if (Cloud.signedIn) TM.VioletSoft else TM.Muted)
                }
            }
        }
        item {
            Row(
                Modifier.fadeUp(1).padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
                    .bounceClick(0.97f) { showMp3 = true }
                    .clip(RoundedCornerShape(14.dp)).background(TM.Raised).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Download, null, tint = TM.VioletSoft)
                Spacer(Modifier.width(10.dp))
                Text("تنزيل MP3 من رابط", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (Mp3Dl.busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = TM.VioletSoft)
            }
        }
        item {
            Column(Modifier.fadeUp(1).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                quick.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { s ->
                            Row(
                                Modifier.weight(1f).height(56.dp)
                                    .bounceClick(0.96f) { ui.play(songs, songs.indexOfFirst { it.id == s.id }) }
                                    .clip(RoundedCornerShape(14.dp)).background(TM.Raised),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Cover(s, Modifier.size(56.dp), 0.dp)
                                Text(
                                    s.title, Modifier.padding(horizontal = 10.dp), maxLines = 2,
                                    overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, lineHeight = 16.sp
                                )
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Box(
                Modifier.fillMaxWidth().fadeUp(2).padding(16.dp)
                    .bounceClick(0.97f) { ui.play(songs, songs.indices.random(), shuffleMode = true) }
                    .shadow(16.dp, RoundedCornerShape(20.dp), ambientColor = TM.Violet, spotColor = TM.Violet)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(TM.Violet, TM.Blue)))
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(32.dp), tint = Color.White)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("تشغيل عشوائي", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${songs.size} أغنية من مكتبتك", color = Color.White.copy(0.8f), fontSize = 13.sp)
                    }
                }
            }
        }
        item { HomeSections(songs, byId, ui) }
        if (albums.isNotEmpty()) {
            item {
                SectionTitle("ألبوماتك")
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(albums, key = { it.id }) { AlbumCard(it, ui, Modifier.width(148.dp)) }
                }
            }
        }
        item { SectionTitle("كل الأغاني") }
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(songs, i) }
        }
    }
}

@Composable
fun AlbumCard(album: Album, ui: PlayerUi, modifier: Modifier = Modifier) {
    Column(modifier.bounceClick(0.96f) { ui.play(album.songs, 0) }.clip(RoundedCornerShape(14.dp))) {
        Cover(album.songs.first(), Modifier.fillMaxWidth().aspectRatio(1f), 14.dp)
        Text(album.name, Modifier.padding(top = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(album.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = TM.Muted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchTab(songs: List<Song>, artists: List<Artist>, ui: PlayerUi, onOpenSurah: (Int) -> Unit, onYoutube: (YtVideo) -> Unit) {
    var q by remember { mutableStateOf("") }
    val sctx = androidx.compose.ui.platform.LocalContext.current
    val results = remember(songs, q) { Fuzzy.search(sctx, songs, q) }
    val surahHits = remember(q) { Quran.search(q) }
    val (online, loading0) = rememberOnline(q)
    var submitted by remember { mutableStateOf("") }
    LaunchedEffect(q) { if (q.isBlank()) submitted = "" else { kotlinx.coroutines.delay(900); submitted = q.trim() } }
    val (yt, ytLoading) = rememberYoutube(submitted)
    val loading = loading0 || ytLoading
    Column(Modifier.fillMaxSize()) {
        Text("البحث والتحميل", style = MaterialTheme.typography.headlineMedium, maxLines = 1, modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp))
        TextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submitted = q.trim() }),
            placeholder = { Text("ابحث عن أي أغنية أو فنان أو سورة...") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, null) } },
            shape = RoundedCornerShape(14.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = TM.Raised, unfocusedContainerColor = TM.Raised,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        when {
            q.isBlank() -> {
                SectionTitle("ابدأ بفنان")
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(artists.take(10), key = { it.name }) { a ->
                        AssistChip(onClick = { q = a.name }, label = { Text(a.name) })
                    }
                }
            }
            results.isEmpty() && surahHits.isEmpty() && online.isEmpty() && yt.isEmpty() && !loading -> EmptyState(Icons.Rounded.Search, "لا نتائج لـ «$q»", "جرّب كلمة أقصر أو اسم الفنان أو السورة." + (if (!Online.ytReady) " لنتائج يوتيوب أضف المفتاح في Online.kt." else if (submitted != q.trim()) " اضغط زر البحث في لوحة المفاتيح لنتائج يوتيوب." else ""))
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (Online.ytReady && q.isNotBlank() && submitted != q.trim()) item {
                    Text("اضغط زر البحث في لوحة المفاتيح لعرض نتائج يوتيوب", color = TM.Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                if (surahHits.isNotEmpty()) {
                    item { SectionTitle("السور") }
                    items(surahHits, key = { "s${it.number}" }) { s ->
                        SurahRow(s, ui.quranSurah == s.number, ui.isPlaying) { onOpenSurah(s.number) }
                    }
                }
                if (results.isNotEmpty()) {
                    item { SectionTitle("على جهازك") }
                    itemsIndexed(results, key = { _, s -> "m${s.id}" }) { i, s ->
                        SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(results, i) }
                    }
                }
                if (yt.isNotEmpty()) {
                    item { SectionTitle("من يوتيوب") }
                    items(yt, key = { "y${it.id}" }) { v -> YtRow(v) { onYoutube(v) } }
                }
                if (online.isNotEmpty()) {
                    item { SectionTitle("من الإنترنت") }
                    itemsIndexed(online, key = { _, s -> "o${s.id}" }) { i, s ->
                        SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(online, i) }
                    }
                }
                if (loading) item {
                    Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                        CircularProgressIndicator(color = TM.Violet, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryTab(albums: List<Album>, artists: List<Artist>, ui: PlayerUi, byId: Map<Long, Song>) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        var themeDlg by remember { mutableStateOf(false) }
        var openArtist by remember { mutableStateOf<Artist?>(null) }
        if (themeDlg) ThemeDialog { themeDlg = false }
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("مكتبتي", style = MaterialTheme.typography.headlineMedium, maxLines = 1, modifier = Modifier.weight(1f))
            IconButton({ themeDlg = true }) { Icon(Icons.Rounded.Palette, null, tint = TM.VioletSoft) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(mode == 0, { mode = 0 }, label = { Text("ألبوماتي") }) }
            item { FilterChip(mode == 3, { mode = 3 }, label = { Text("ذكية") }) }
            item { FilterChip(mode == 2, { mode = 2 }, label = { Text("ألبومات الجهاز") }) }
            item { FilterChip(mode == 1, { mode = 1 }, label = { Text("الفنانون") }) }
            item { FilterChip(mode == 4, { mode = 4 }, label = { Text("المكرر") }) }
            item { FilterChip(mode == 5, { mode = 5 }, label = { Text("إصلاح") }) }
        }
        Spacer(Modifier.height(8.dp))
        if (mode == 0) {
            MyAlbums(byId, ui)
        } else if (mode == 3) {
            SmartAlbums(byId.values.toList(), ui)
        } else if (mode == 5) {
            MetaFixTab(byId.values.toList())
        } else if (mode == 4) {
            DuplicatesTab(byId.values.toList(), ui)
        } else if (mode == 2) {
            LazyVerticalGrid(
                GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
            ) { items(albums, key = { it.id }) { AlbumCard(it, ui) } }
        } else if (openArtist != null) {
            ArtistScreen(openArtist!!, ui) { openArtist = null }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                items(artists, key = { it.name }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { openArtist = a }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Cover(a.songs.first(), Modifier.size(56.dp), 28.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(a.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${a.songs.size} أغنية", fontSize = 12.sp, color = TM.Muted)
                        }
                    }
                }
            }
        }
    }
}
