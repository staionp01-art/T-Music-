package com.tmusic.app

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.shadow
import kotlinx.coroutines.delay
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs

@Composable
fun rememberArt(song: Song?): State<Bitmap?> {
    val ctx = LocalContext.current.applicationContext
    return produceState<Bitmap?>(song?.let { Art.peek(it) }, song?.id) {
        value = song?.let { Art.get(ctx, it) }
    }
}

data class CoverPalette(val accent: Color, val bg: Color)

/** لون الخلفية: نفس لون الغلاف الأكثر حضورًا لكن فاتحًا وزاهيًا، مع خفض السطوع فقط إن كان فاتحًا جدًا ليبقى النص مقروءًا. */
private fun vividTone(h: Float, s: Float): Color {
    // نغمة داكنة غنية بنفس درجة لون الغلاف تمامًا
    return Color.hsv(h, s.coerceIn(0.55f, 0.85f), 0.42f)
}

/** اللون الأكثر حضورًا في الغلاف: نعدّ البكسلات الملوّنة حسب درجة اللون ونتجاهل الأسود والرمادي. */
private fun dominantColor(b: Bitmap): Color? {
    val n = 48
    val small = Bitmap.createScaledBitmap(b, n, n, true)
    val px = IntArray(n * n)
    small.getPixels(px, 0, n, 0, 0, n, n)
    val w = FloatArray(36); val r = FloatArray(36); val g = FloatArray(36); val bl = FloatArray(36)
    val hsv = FloatArray(3)
    var colored = 0
    for (c in px) {
        android.graphics.Color.colorToHSV(c, hsv)
        if (hsv[2] < 0.2f || hsv[1] < 0.18f) continue
        colored++
        val wt = hsv[1] * hsv[2]
        val i = (hsv[0] / 10f).toInt().coerceIn(0, 35)
        w[i] += wt
        r[i] += android.graphics.Color.red(c) * wt
        g[i] += android.graphics.Color.green(c) * wt
        bl[i] += android.graphics.Color.blue(c) * wt
    }
    if (colored < n * n * 0.10f) return null   // غلاف أبيض وأسود تقريبًا: لا لون يُستخرج
    var best = -1
    var bestScore = 0f
    for (i in 0 until 36) {
        val sc = w[i] + 0.5f * (w[(i + 35) % 36] + w[(i + 1) % 36])
        if (sc > bestScore) { bestScore = sc; best = i }
    }
    if (best < 0 || w[best] <= 0f) return null
    return Color(r[best] / w[best] / 255f, g[best] / w[best] / 255f, bl[best] / w[best] / 255f)
}

/** ألوان الشاشة من الغلاف نفسه (نفس درجة لونه). الأغلفة الأبيض والأسود تأخذ بنفسجي التطبيق. */
@Composable
fun rememberCoverPalette(song: Song?, fallback: Color): CoverPalette {
    val art by rememberArt(song)
    val target by produceState(CoverPalette(TM.VioletSoft, TM.Deep), art) {
        val bmp = art
        value = if (bmp == null) CoverPalette(TM.VioletSoft, TM.Deep) else withContext(Dispatchers.Default) {
            val base = dominantColor(bmp)
            if (base == null) CoverPalette(Color(0xFFDADAE4), Color(0xFF2B2B34)) else {
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(base.toArgb(), hsv)
                CoverPalette(Color.hsv(hsv[0], hsv[1].coerceIn(0.4f, 0.75f), 1f), vividTone(hsv[0], hsv[1]))
            }
        }
    }
    val accent by animateColorAsState(target.accent, tween(900), label = "accent")
    val bg by animateColorAsState(target.bg, tween(900), label = "bg")
    return CoverPalette(accent, bg)
}

@Composable
fun rememberCoverColor(song: Song?, fallback: Color): Color = rememberCoverPalette(song, fallback).bg

@Composable
fun Cover(song: Song?, modifier: Modifier = Modifier, corner: Dp = 12.dp, saturation: Float = 1f) {
    val art by rememberArt(song)
    val hue = abs(((song?.albumId ?: 0L) * 47) % 360).toFloat()
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color.hsv(hue, 0.5f, 0.45f), Color.hsv((hue + 40) % 360, 0.6f, 0.22f)))),
        contentAlignment = Alignment.Center
    ) {
        val b = art
        if (b == null) Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(0.5f), modifier = Modifier.fillMaxSize(0.4f))
        else Image(
            b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
            colorFilter = if (saturation < 0.999f) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(saturation) }) else null
        )
    }
}

@Composable
fun EqBars(playing: Boolean, color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(420, 560, 360).forEachIndexed { i, d ->
            val h by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(d, easing = LinearEasing), RepeatMode.Reverse), label = "bar$i")
            Box(Modifier.width(3.dp).fillMaxHeight(if (playing) h else 0.3f).background(color, RoundedCornerShape(2.dp)))
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleLarge, modifier = modifier.padding(horizontal = 16.dp, vertical = 12.dp))
}

@Composable
fun SongRow(song: Song, active: Boolean, playing: Boolean, inAlbum: UAlbum? = null, onClick: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    if (menu) SongMenuSheet(song, inAlbum) { menu = false }
    val rowBg by animateColorAsState(if (active) TM.Violet.copy(alpha = 0.13f) else Color.Transparent, tween(350), label = "row-bg")
    val titleCol by animateColorAsState(if (active) TM.VioletSoft else TM.Text, tween(350), label = "row-title")
    Row(
        Modifier.fillMaxWidth()
            .bounceCombined(0.98f, onLongClick = { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); menu = true }, onClick = onClick)
            .padding(horizontal = 8.dp).clip(RoundedCornerShape(14.dp)).background(rowBg)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(song, Modifier.size(52.dp), 10.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = titleCol, fontWeight = FontWeight.SemiBold
            )
            Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = TM.Muted)
        }
        Spacer(Modifier.width(10.dp))
        if (song.remoteUrl != null) {   // أغاني الإنترنت: زر التنزيل دائمًا، وباهت إن لم يُتح صاحبها التنزيل
            val ctx = LocalContext.current
            val can = song.downloadUrl != null
            IconButton(
                {
                    if (can) downloadSong(ctx, song)
                    else android.widget.Toast.makeText(ctx, "صاحب هذه الأغنية لم يتح تنزيلها", android.widget.Toast.LENGTH_SHORT).show()
                },
                Modifier.size(36.dp)
            ) { Icon(Icons.Rounded.Download, null, Modifier.size(22.dp), tint = if (can) TM.VioletSoft else TM.Muted.copy(alpha = 0.5f)) }
        }
        if (active) EqBars(playing, TM.VioletSoft)
        else Text(fmt(song.duration), style = MaterialTheme.typography.bodySmall, color = TM.Muted)
    }
}

/** شريط تنقّل سينمائي: مؤشر زجاجي ينزلق بنابض مرن، والأيقونة تقفز وتكبر عند اختيارها. */
@Composable
fun CinemaNavBar(tab: Int, badge: Int = 0, insets: Boolean = true, onTab: (Int) -> Unit) {
    val items = listOf(
        Triple("الرئيسية", Icons.Rounded.Home, 0),
        Triple("بحث", Icons.Rounded.Search, 1),
        Triple("مكتبتي", Icons.Rounded.LibraryMusic, 2),
        Triple("التنزيلات", Icons.Rounded.Download, 3),
        Triple("الإعدادات", Icons.Rounded.Settings, 4)
    )
    val pos by animateFloatAsState(tab.toFloat(), spring(dampingRatio = 0.62f, stiffness = 320f), label = "nav-pos")
    BoxWithConstraints(
        Modifier.fillMaxWidth().then(if (insets) Modifier.navigationBarsPadding() else Modifier).padding(horizontal = 14.dp, vertical = 6.dp).height(64.dp)
            .glass(RoundedCornerShape(30.dp))
    ) {
        val w = maxWidth / items.size
        // عدسة زجاجية تنزلق بين الأيقونات وتتمطّط أثناء الحركة
        val stretch = 1f + abs(tab - pos).coerceAtMost(1.5f) * 0.32f
        Box(
            Modifier.offset(x = w * pos).width(w).fillMaxHeight().padding(horizontal = 6.dp, vertical = 4.dp)
                .graphicsLayer { scaleX = stretch; scaleY = 1f / (0.65f + 0.35f * stretch) }
                .glass(RoundedCornerShape(24.dp), tint = Color.White, strength = 1.7f)
        )
        Row(Modifier.fillMaxSize()) {
            items.forEach { (label, icon, i) ->
                val sel = tab == i
                val sc by animateFloatAsState(if (sel) 1.2f else 1f, spring(dampingRatio = 0.38f, stiffness = 380f), label = "nav-scale")
                val lift by animateDpAsState(if (sel) (-3).dp else 0.dp, spring(dampingRatio = 0.5f, stiffness = 380f), label = "nav-lift")
                val col by animateColorAsState(if (sel) Color.White else TM.Muted, tween(300), label = "nav-color")
                Column(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp)).liquidPress(0.88f) { onTab(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Box {
                        Icon(icon, null, Modifier.size(24.dp).offset(y = lift).graphicsLayer { scaleX = sc; scaleY = sc }, tint = col)
                        if (i == 3 && badge > 0) Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 8.dp, y = (-4).dp).size(16.dp)
                                .clip(RoundedCornerShape(8.dp)).background(Color(0xFFFF4D8D)),
                            contentAlignment = Alignment.Center
                        ) { Text(badge.toString(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(label, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = col)
                }
            }
        }
    }
}

@Composable
fun ProgressLine(frac: Float, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(2.dp)) {
        drawRect(Color.White, size = Size(size.width * frac.coerceIn(0f, 1f), size.height))
    }
}

@Composable
fun MiniPlayer(song: Song, ui: PlayerUi, pal: CoverPalette, onOpen: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    // التقدم ينساب بنعومة بدل أن يقفز
    val progress by animateFloatAsState(
        if (ui.duration > 0) (ui.position.toFloat() / ui.duration).coerceIn(0f, 1f) else 0f,
        tween(260, easing = LinearEasing), label = "mini-progress"
    )
    Box(
        Modifier.fillMaxWidth().bounceClick(0.985f, onOpen).padding(horizontal = 10.dp, vertical = 6.dp)
            .shadow(14.dp, shape, ambientColor = pal.accent, spotColor = pal.accent)
            .clip(shape)
            .pointerInput(Unit) {
                // اسحب المشغّل المصغّر: يسارًا للأغنية التالية، يمينًا للسابقة
                var dx = 0f
                detectHorizontalDragGestures(
                    onDragStart = { dx = 0f },
                    onDragEnd = { if (dx < -90f) ui.next() else if (dx > 90f) ui.previous() },
                    onHorizontalDrag = { _, d -> dx += d }
                )
            }
            .glass(shape, tint = pal.accent, art = Art.peek(song), strength = 1f)
    ) {
        Column {
        Row(Modifier.padding(start = 10.dp, end = 6.dp, top = 10.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = song,
                transitionSpec = { (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.7f)) togetherWith (fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.7f)) },
                label = "mini-cover"
            ) { sg -> Cover(sg, Modifier.size(46.dp), 10.dp) }
            Spacer(Modifier.width(12.dp))
            AnimatedContent(
                targetState = song,
                modifier = Modifier.weight(1f),
                transitionSpec = { (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200))) },
                label = "mini-title"
            ) { sg ->
                Column {
                    Text(sg.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(sg.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.White.copy(0.7f))
                }
            }
            val fav = Favorites.has(song.id)
            IconButton({ Favorites.toggle(song) }, Modifier.size(34.dp)) {
                Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "المفضلة", Modifier.size(20.dp), tint = if (fav) Color(0xFFFF5C8A) else Color.White.copy(0.85f))
            }
            IconButton(ui::previous, Modifier.size(36.dp)) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(28.dp)) }
            IconButton(ui::togglePlay, Modifier.size(42.dp)) {
                AnimatedContent(
                    targetState = ui.isPlaying,
                    transitionSpec = { (scaleIn(spring(0.55f, 500f)) + fadeIn(tween(150))) togetherWith (scaleOut(tween(120)) + fadeOut(tween(120))) },
                    label = "mini-playpause"
                ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(30.dp)) }
            }
            IconButton(ui::next, Modifier.size(36.dp)) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(26.dp)) }
            Box(
                Modifier.padding(start = 2.dp).size(28.dp).clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color.White.copy(alpha = 0.14f)).clickable { ui.closeMini() },
                Alignment.Center
            ) { Icon(Icons.Rounded.Close, "إغلاق المشغّل", Modifier.size(15.dp)) }
        }
        }
        Canvas(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp)) {
            drawRect(Color.White.copy(alpha = 0.08f))
            drawRect(
                Brush.horizontalGradient(listOf(pal.accent, TM.Blue)),
                size = Size(size.width * progress, size.height)
            )
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, Modifier.size(56.dp), tint = TM.Muted)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, color = TM.Muted, textAlign = TextAlign.Center)
    }
}


/** ضغطة بنابض: العنصر يصغر قليلًا عند اللمس ثم يعود بمرونة. */
@Composable
fun Modifier.bounceClick(scaleDown: Float = 0.95f, onClick: () -> Unit): Modifier = this.liquidPress(scaleDown, onClick)

/** دخول متدرّج: يظهر العنصر بتأخير بسيط ويصعد من الأسفل. */
@Composable
fun Modifier.fadeUp(index: Int = 0): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(70L * index)
        a.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 40f }
}
