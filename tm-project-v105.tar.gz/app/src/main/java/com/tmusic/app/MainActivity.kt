package com.tmusic.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object QuranResume { var pending by mutableStateOf<Pair<Int, Int>?>(null) }

class MainActivity : ComponentActivity() {
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Glass.applyRefresh(this)
        Glass.attach(this)
    }

    override fun onStart() { super.onStart(); AppState.set(true) }

    override fun onStop() { AppState.set(false); super.onStop() }

    override fun onPause() {
        Glass.detach(this)
        super.onPause()
    }

    /** أزرار الصوت في الهاتف تُظهر شريط T Music بدل لوحة النظام، وفوق 100% يبدأ تعزيز الصوت. */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val k = event.keyCode
        if (VolBoost.hudOn && (k == android.view.KeyEvent.KEYCODE_VOLUME_UP || k == android.view.KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event.action == android.view.KeyEvent.ACTION_DOWN) VolumeHud.key(this, k == android.view.KeyEvent.KEYCODE_VOLUME_UP)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun handleIntent(i: android.content.Intent?) {
        if (i?.getBooleanExtra("update_now", false) == true) Updater.autoStart = true
        val p = i?.getStringExtra("resume_q")?.split(":") ?: return
        val s = p.getOrNull(0)?.toIntOrNull(); val a = p.getOrNull(1)?.toIntOrNull()
        if (s != null && a != null) QuranResume.pending = s to a
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        TM.init(this)
        Glass.init(this)
        VolBoost.init(this)
        AppPrefs.init(this)
        TikoLook.init(this)
        TikoKit.init(this)
        runCatching { Updater.schedule(this) }
        Profile.init(this)
        Favorites.init(this)
        Mp3Dl.init(this)
        Cloud.refreshUser(this)
        handleIntent(intent)
        setContent {
            TMusicTheme {
                Surface(Modifier.fillMaxSize(), color = TM.Ink) {
                    var intro by rememberSaveable { mutableStateOf(true) }
                    var skipLogin by rememberSaveable { mutableStateOf(false) }
                    val ctx = LocalContext.current
                    Box(Modifier.fillMaxSize()) {
                        Crossfade(intro, animationSpec = tween(450), label = "intro") {
                            if (it) TMSplash { intro = false }
                            else if (Cloud.ready(ctx) && !Cloud.signedIn && !skipLogin) LoginGate { skipLogin = true }
                            else Root()
                        }
                        VolumeHudOverlay()
                        FpsMeter()
                    }
                }
            }
        }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun has() = ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(has()) }
    val ask = remember {
        buildList { add(audioPerm); if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS) }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = has() }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(ask) }
    // إذن الإشعارات يُطلب منفصلًا (قد يكون إذن الصوت ممنوحًا من إصدار سابق فلا يُسأل عن الإشعارات أبدًا)
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(granted) {
        if (granted && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        // استثناء من توفير البطارية مرة واحدة: بدونه تقتل بعض الأجهزة الفحص الخلفي فلا يصل إشعار التحديث
        val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
        val sp = ctx.getSharedPreferences("tm_update", android.content.Context.MODE_PRIVATE)
        if (granted && Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(ctx.packageName) && !sp.getBoolean("battery_asked", false)) {
            sp.edit().putBoolean("battery_asked", true).apply()
            delay(1500)
            runCatching {
                ctx.startActivity(
                    android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:${ctx.packageName}"))
                )
            }
        }
    }
    if (granted) App() else PermissionScreen { launcher.launch(ask) }
}

@Composable
fun PermissionScreen(onAllow: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(
            Modifier.size(96.dp).background(Brush.linearGradient(listOf(TM.Violet, TM.Blue)), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.MusicNote, null, Modifier.size(48.dp), tint = Color.Black) }
        Spacer(Modifier.height(24.dp))
        Text("T Music", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("نحتاج إذن الوصول إلى ملفات الصوت لنعرض أغانيك.", color = TM.Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onAllow) { Text("السماح بالوصول") }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var songs by remember { mutableStateOf<List<Song>?>(null) }
    LaunchedEffect(Unit) { songs = withContext(Dispatchers.IO) { loadSongs(ctx) } }
    // بعد حفظ MP3 جديد: حدّث المكتبة
    LaunchedEffect(Mp3Dl.savedCount) { if (Mp3Dl.savedCount > 0) songs = withContext(Dispatchers.IO) { loadSongs(ctx) } }

    val ui = rememberPlayerUi()
    LaunchedEffect(Glass.notice) {
        Glass.notice?.let { android.widget.Toast.makeText(ctx, it, android.widget.Toast.LENGTH_LONG).show(); Glass.notice = null }
    }
    LaunchedEffect(Unit) {
        Cloud.refreshUser(ctx)
        if (AppPrefs.autoUpdate) runCatching { Updater.check(ctx, false, force = true) }
        while (true) { kotlinx.coroutines.delay(90_000); runCatching { Cloud.backup(ctx, false) } }
    }
    // فحص دوري كل دقيقة والتطبيق مفتوح: يظهر الإشعار تلقائيًا بلا أي ضغط
    LaunchedEffect(Unit) {
        while (true) { kotlinx.coroutines.delay(60_000); if (AppPrefs.autoUpdate) runCatching { Updater.check(ctx, false) } }
    }
    LaunchedEffect(Updater.autoStart) {
        if (Updater.autoStart) { Updater.autoStart = false; runCatching { Updater.apply(ctx.applicationContext) } }
    }
    LaunchedEffect(songs, ui.controller) { val sl = songs; if (ui.controller != null && sl != null && sl.isNotEmpty()) ui.restore(sl) }
    activeUi = ui
    LaunchedEffect(QuranResume.pending, ui.controller) {
        val q = QuranResume.pending
        if (q != null && ui.controller != null) { ui.playQuran(q.first, q.second); QuranResume.pending = null }
    }
    LaunchedEffect(ui.isPlaying, ui.controller) {
        while (ui.isPlaying) { ui.syncPosition(); delay(200) }
    }

    var tab by rememberSaveable { mutableIntStateOf(AppPrefs.startTab) }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var yt by remember { mutableStateOf<YtVideo?>(null) }
    var section by rememberSaveable { mutableIntStateOf(0) }      // 0 = T Music، 1 = T Quran
    var quranOpen by rememberSaveable { mutableIntStateOf(0) }    // رقم السورة المفتوحة، 0 = القائمة

    LaunchedEffect(ui.openRequest) { if (ui.openRequest > 0) expanded = true }

    // بعد أول تسجيل دخول: اطلب اسمًا للملف الشخصي (وصورة اختيارية)
    var askProfile by remember { mutableStateOf(false) }
    LaunchedEffect(Cloud.signedIn) { if (Cloud.signedIn && Profile.name.isBlank()) askProfile = true }
    if (askProfile) ProfileEditDialog { askProfile = false }

    val list = songs
    if (list == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = TM.Violet) }
        return
    }
    val byId = remember(list) { list.associateBy { it.id } }
    val albums = remember(list) { list.toAlbums() }
    val artists = remember(list) { list.toArtists() }
    val current = byId[ui.currentId] ?: ui.online[ui.currentId]
    val miniPal = rememberCoverPalette(current, TM.Raised)

    BackHandler(expanded) { expanded = false }
    val view = androidx.compose.ui.platform.LocalView.current
    SideEffect { view.keepScreenOn = AppPrefs.keepOn && expanded }
    DisposableEffect(Unit) { onDispose { view.keepScreenOn = false } }
    val onHome = section == 0 && tab == 0
    val bannerOn = Updater.available && !Updater.dismissed && !onHome

    Box(Modifier.fillMaxSize()) {
        LiquidBackdrop(miniPal)
        Scaffold(
            containerColor = Color.Transparent,
            topBar = { AppHeader(section, onSelect = { section = it }, onSettings = { section = 0; tab = 4 }) },
            bottomBar = {
                Column((if (section != 0 || bannerOn) Modifier.navigationBarsPadding() else Modifier).animateContentSize(spring(dampingRatio = 0.8f, stiffness = 380f))) {
                    if (ui.quranSurah != 0) {
                        if (!(section == 1 && quranOpen == ui.quranSurah)) QuranMiniPlayer(ui) { section = 1; quranOpen = ui.quranSurah }
                    } else if (current != null && ui.dismissedId != ui.currentId) MiniPlayer(current, ui, miniPal) { expanded = true }
                    if (section == 0) CinemaNavBar(tab, Mp3Dl.activeCount, insets = !bannerOn) { tab = it }
                    if (!onHome) UpdateBanner()
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                Crossfade(section, animationSpec = tween(380), label = "section") { sec ->
                    if (sec == 0) {
                        AnimatedContent(
                            targetState = tab,
                            transitionSpec = {
                                val d = if (targetState > initialState) 1 else -1
                                (slideInHorizontally(tween(440, easing = FastOutSlowInEasing)) { d * it / 4 } + fadeIn(tween(400, delayMillis = 60))) togetherWith
                                    (slideOutHorizontally(tween(320, easing = FastOutSlowInEasing)) { -d * it / 4 } + fadeOut(tween(220)))
                            },
                            label = "tabs"
                        ) { t ->
                            when (t) {
                                0 -> HomeTab(list, albums, byId, ui)
                                1 -> SearchTab(list, artists, ui, onOpenSurah = { section = 1; quranOpen = it }) { ui.controller?.pause(); yt = it }
                                2 -> LibraryTab(albums, artists, ui, byId)
                                3 -> DownloadsTab(byId, ui)
                                else -> SettingsTab(ui)
                            }
                        }
                    } else QuranTab(ui, list, quranOpen, onYoutube = { ui.controller?.pause(); yt = it }) { quranOpen = it }
                }
            }
        }

        PlayerSheet(expanded && current != null, onClose = { expanded = false }) { dragMod ->
            current?.let { NowPlaying(it, ui, dragMod) { expanded = false } }
        }
        EqualizerOverlay(current, ui)
        ReelOverlay()
        yt?.let { YoutubeDialog(it, ui) { yt = null } }
        TikoCompanion(
            visible = false,
            onClick = { expanded = true },
            modifier = Modifier
        )
    }
}


/**
 * شاشة التشغيل كورقة تصعد من أسفل الشاشة (من مكان المشغّل المصغّر) بنابض ناعم،
 * ويمكن سحبها للأسفل من الشريط العلوي أو العنوان لإغلاقها، مع تعتيم الخلفية أثناء الحركة.
 */
@Composable
fun PlayerSheet(visible: Boolean, onClose: () -> Unit, content: @Composable (Modifier) -> Unit) {
    val p = remember { Animatable(0f) }      // 0 = مخفية، 1 = مفتوحة
    val dragY = remember { Animatable(0f) }  // سحب المستخدم بالبكسل
    val scope = rememberCoroutineScope()
    LaunchedEffect(visible) {
        if (visible) p.animateTo(1f, spring(dampingRatio = 1f, stiffness = 260f))
        else { p.animateTo(0f, tween(320, easing = FastOutSlowInEasing)); dragY.snapTo(0f) }
    }
    if (!visible && p.value <= 0.001f) return

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = constraints.maxHeight.toFloat()
        val dragMod = Modifier.pointerInput(h) {
            detectVerticalDragGestures(
                onVerticalDrag = { change, dy ->
                    change.consume()
                    scope.launch { dragY.snapTo((dragY.value + dy).coerceAtLeast(0f)) }
                },
                onDragEnd = {
                    if (dragY.value > h * 0.18f) onClose()
                    else scope.launch { dragY.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 400f)) }
                },
                onDragCancel = { scope.launch { dragY.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 400f)) } }
            )
        }
        val shown = ((1f - p.value) * h + dragY.value).coerceAtLeast(0f)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f * (1f - (shown / h).coerceIn(0f, 1f)))))
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                translationY = shown
                val r = (28f * (shown / h * 6f).coerceIn(0f, 1f))
                shape = RoundedCornerShape(topStart = r.dp, topEnd = r.dp)
                clip = true
            }
        ) { content(dragMod) }
    }
}
