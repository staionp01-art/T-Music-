package com.tmusic.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * أعلى الرئيسية: حقل البحث (ينقلك لصفحة البحث، فلا حاجة لتبويب بحث في الشريط السفلي)
 * وتحته أدوات سريعة: وضع السيارة، التركيز، الإنجازات، التعرّف على أغنية، الاستماع المشترك.
 */
@Composable
fun HomeQuickBar(songs: List<Song>, byId: Map<Long, Song>, ui: PlayerUi, onSearch: () -> Unit) {
    var dlg by remember { mutableIntStateOf(0) }
    when (dlg) {
        1 -> AchievementsSheet(ui, byId, songs.size) { dlg = 0 }
        2 -> FocusDialog(ui, songs, byId) { dlg = 0 }
        3 -> RecognizeDialog(songs, ui) { dlg = 0 }
        4 -> TogetherDialog(songs, ui, byId) { dlg = 0 }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(TM.Raised)
                .clickable { onSearch() }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Search, null, tint = TM.Muted)
            Spacer(Modifier.width(10.dp))
            Text("ابحث عن أغنية أو فنان أو سورة…", color = TM.Muted, fontSize = 15.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToolChip(Icons.Rounded.DirectionsCar, "وضع السيارة") { CarMode.on = true }
            ToolChip(Icons.Rounded.Timer, if (FocusMode.active) "التركيز يعمل" else "تركيز") { dlg = 2 }
            ToolChip(Icons.Rounded.EmojiEvents, "الإنجازات") { dlg = 1 }
            ToolChip(Icons.Rounded.Mic, "تعرّف على أغنية") { dlg = 3 }
            ToolChip(Icons.Rounded.Group, if (Together.role != 0) "غرفة ${Together.code}" else "استماع مشترك") { dlg = 4 }
        }
    }
}

@Composable
private fun ToolChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    AssistChip(onClick, label = { Text(label) }, leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) })
}
