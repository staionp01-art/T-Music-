package com.tmusic.app

import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** وضع السيارة: شاشة سوداء بلا تفاصيل، أزرار ضخمة يسهل لمسها دون النظر. */
object CarMode {
    var on by mutableStateOf(false)
}

@Composable
fun CarModeOverlay(song: Song?, ui: PlayerUi) {
    if (!CarMode.on) return
    val ctx = LocalContext.current
    BackHandler { CarMode.on = false }
    DisposableEffect(Unit) {
        val w = ctx.hostActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable(enabled = false) {}) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("وضع السيارة", color = Color.White.copy(0.35f), fontSize = 16.sp, modifier = Modifier.weight(1f))
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF1A1A1A)).clickable { CarMode.on = false },
                    Alignment.Center
                ) { Icon(Icons.Rounded.Close, "إغلاق", Modifier.size(34.dp), tint = Color.White) }
            }
            Spacer(Modifier.weight(1f))
            Text(
                song?.title ?: "لا شيء قيد التشغيل", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 42.sp,
                modifier = Modifier.fillMaxWidth()
            )
            if (song != null) {
                Spacer(Modifier.height(10.dp))
                Text(
                    song.artist, color = Color.White.copy(0.6f), fontSize = 22.sp, textAlign = TextAlign.Center,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.weight(1f))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
                ) {
                    CarButton(Icons.Rounded.SkipPrevious, 108.dp, 64.dp, Color(0xFF1A1A1A), "السابق") { ui.previous() }
                    CarButton(
                        if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, 150.dp, 90.dp, Color.White,
                        if (ui.isPlaying) "إيقاف" else "تشغيل", tint = Color.Black
                    ) { ui.togglePlay() }
                    CarButton(Icons.Rounded.SkipNext, 108.dp, 64.dp, Color(0xFF1A1A1A), "التالي") { ui.next() }
                }
            }
        }
    }
}

@Composable
private fun CarButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector, box: androidx.compose.ui.unit.Dp, iconSize: androidx.compose.ui.unit.Dp,
    bg: Color, desc: String, tint: Color = Color.White, onClick: () -> Unit
) {
    Box(Modifier.size(box).clip(CircleShape).background(bg).clickable(onClick = onClick), Alignment.Center) {
        Icon(icon, desc, Modifier.size(iconSize), tint = tint)
    }
}
