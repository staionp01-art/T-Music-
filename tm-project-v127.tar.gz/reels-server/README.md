# إعداد ريلز T Music على تيليجرام (مجاني)

الفكرة: التطبيق لا يحمل توكن البوت أبدًا. الوسيط (Worker) هو من يكلّم تيليجرام.

## 1) البوت والقناة
1. في تيليجرام افتح @BotFather ← `/newbot` ← احفظ **التوكن**.
2. أنشئ **قناة** (خاصة تكفي)، وأضف البوت **مشرفًا** فيها بصلاحية نشر الرسائل.
3. معرّف القناة (يبدأ بـ -100): أرسل أي رسالة في القناة ثم افتح
   `https://api.telegram.org/bot<TOKEN>/getUpdates` وانسخ `chat.id`.

## 2) نشر الوسيط على Cloudflare (مجاني)
1. أنشئ حسابًا على cloudflare.com ← Workers & Pages ← Create ← Worker.
2. الصق محتوى `worker.js` ثم Deploy.
3. من Settings ← Variables:
   - متغيّر عادي: `FIREBASE_PROJECT` = معرّف مشروع Firebase (Project ID).
   - سرّان (Encrypt): `BOT_TOKEN` و `CHAT_ID`.
4. انسخ رابط الـWorker، مثل `https://tm-reels.اسمك.workers.dev`.

## 3) التطبيق
ضع الرابط في `app/src/main/java/com/tmusic/app/ReelsConfig.kt`:
`const val API_URL = "https://tm-reels.اسمك.workers.dev"`

## 4) قواعد Firestore (أضفها داخل قواعدك الحالية)
```
match /tm_reels/{id} {
  allow read: if true;
  allow create: if request.auth != null && request.resource.data.uid == request.auth.uid;
  allow update: if request.resource.data.diff(resource.data).affectedKeys().hasOnly(['likes','reports']);
  allow delete: if request.auth != null && resource.data.uid == request.auth.uid;
}
```

## حدود يجب أن تعرفها
- أكبر فيديو يمكن بثّه من تيليجرام عبر البوت: **20 ميغابايت**. التطبيق يرفض ما فوق 19.
- ريلز 720×1280 لمدة 15–30 ثانية تكون عادةً أقل من ذلك بكثير.
- النشر يتطلب تسجيل الدخول (يتحقق الوسيط من توكن Firebase)، والمشاهدة مفتوحة للجميع.
- ما يصله 3 بلاغات يختفي تلقائيًا من القائمة. للحذف النهائي احذف المستند من Firestore.
- شروط تيليجرام تمنع إساءة استخدام البوتات؛ إن كبر التطبيق كثيرًا فكّر بنقل التخزين إلى Cloudflare R2.
