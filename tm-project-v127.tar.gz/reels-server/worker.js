// T Music Reels — وسيط Cloudflare Worker بين التطبيق وتيليجرام.
// الأسرار (Secrets): BOT_TOKEN, CHAT_ID    المتغيّر (Variable): FIREBASE_PROJECT
// المسارات:  POST /upload   (يتطلب توكن Firebase)   |   GET /f/<file_id>  (بث الفيديو أو الصورة المصغّرة)

const JWKS_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
const MAX_BYTES = 19 * 1024 * 1024; // حد تحميل الملفات من بوت تيليجرام 20MB

const cors = () => ({
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type, Range',
  'Access-Control-Expose-Headers': 'Content-Length, Content-Range',
});
const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json', ...cors() } });

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors() });
    try {
      if (url.pathname === '/upload' && req.method === 'POST') return await upload(req, env, url);
      const m = url.pathname.match(/^\/f\/([A-Za-z0-9_-]{10,250})$/);
      if (m && (req.method === 'GET' || req.method === 'HEAD')) return await serveFile(req, env, m[1]);
      return new Response('T Music Reels OK', { headers: cors() });
    } catch (e) {
      return json({ error: String(e && e.message || e) }, 500);
    }
  },
};

function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}

// يتحقق أن التوكن صادر من Firebase لمشروعك فعلًا (توقيع RS256 + المشروع + الصلاحية)
async function verifyFirebase(token, env) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('bad token');
  const [h, p, s] = parts;
  const header = JSON.parse(new TextDecoder().decode(b64urlToBytes(h)));
  const payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(p)));
  const jwks = await (await fetch(JWKS_URL, { cf: { cacheTtl: 3600, cacheEverything: true } })).json();
  const jwk = jwks.keys.find((k) => k.kid === header.kid);
  if (!jwk) throw new Error('unknown key');
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64urlToBytes(s), new TextEncoder().encode(h + '.' + p));
  const now = Math.floor(Date.now() / 1000);
  const proj = env.FIREBASE_PROJECT;
  if (!ok || payload.aud !== proj || payload.iss !== 'https://securetoken.google.com/' + proj || payload.exp < now || !payload.sub) {
    throw new Error('invalid token');
  }
  return payload;
}

async function upload(req, env, url) {
  const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  let user;
  try { user = await verifyFirebase(token, env); } catch (e) { return json({ error: 'unauthorized' }, 401); }
  const len = Number(req.headers.get('Content-Length') || 0);
  if (!len || len > MAX_BYTES) return json({ error: 'size' }, 413);
  const blob = await req.blob();
  const caption = (url.searchParams.get('caption') || '').slice(0, 200);
  const fd = new FormData();
  fd.append('chat_id', env.CHAT_ID);
  fd.append('supports_streaming', 'true');
  fd.append('caption', caption + '\nuid:' + user.sub);
  fd.append('video', blob, 'reel.mp4');
  const r = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/sendVideo`, { method: 'POST', body: fd });
  const j = await r.json();
  if (!j.ok) return json({ error: j.description || 'telegram' }, 502);
  const v = j.result.video;
  const th = v.thumbnail || v.thumb;
  return json({ fileId: v.file_id, thumbId: th ? th.file_id : '', messageId: j.result.message_id });
}

async function serveFile(req, env, id) {
  const info = await (await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/getFile?file_id=${id}`)).json();
  if (!info.ok) return new Response('not found', { status: 404, headers: cors() });
  const path = info.result.file_path;
  const range = req.headers.get('Range');
  const up = await fetch(`https://api.telegram.org/file/bot${env.BOT_TOKEN}/${path}`, { headers: range ? { Range: range } : {} });
  const h = new Headers(cors());
  h.set('Content-Type', /\.(jpe?g|png|webp)$/i.test(path) ? 'image/jpeg' : 'video/mp4');
  h.set('Accept-Ranges', 'bytes');
  h.set('Cache-Control', 'public, max-age=3600');
  for (const k of ['Content-Length', 'Content-Range']) {
    const v = up.headers.get(k);
    if (v) h.set(k, v);
  }
  return new Response(req.method === 'HEAD' ? null : up.body, { status: up.status, headers: h });
}
