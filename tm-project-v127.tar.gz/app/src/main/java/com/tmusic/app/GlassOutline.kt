package com.tmusic.app

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill

/** يرسم Outline بفرشاة (بديل ذاتي لـ drawOutline حتى لا نعتمد على حزمة قد تتغير بين الإصدارات). */
fun DrawScope.tmOutline(outline: Outline, brush: Brush, style: DrawStyle = Fill) {
    val path = when (outline) {
        is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
        is Outline.Generic -> outline.path
    }
    drawPath(path, brush, style = style)
}

fun DrawScope.tmOutline(outline: Outline, color: Color, style: DrawStyle = Fill) =
    tmOutline(outline, SolidColor(color), style)
