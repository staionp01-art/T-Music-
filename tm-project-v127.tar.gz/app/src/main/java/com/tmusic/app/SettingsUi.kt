package com.tmusic.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * سحب مطّاطي أفقي على طريقة iOS: العنصر يتبع إصبعك بمقاومة تزداد كلما ابتعد، يميل قليلًا،
 * ثم يرجع بنابض مرن عند الإفلات. لا يمنع التمرير العمودي ولا نقرات العناصر بداخله.
 */
fun Modifier.rubberDrag(maxTilt: Float = 9f): Modifier = composed {
    val x = remember { Animatable(0f) }
    val press = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    fun release() {
        scope.launch { x.animateTo(0f, spring(dampingRatio = 0.42f, stiffness = 260f)) }
        scope.launch { press.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 400f)) }
    }
    this
        .graphicsLayer {
            translationX = x.value
            rotationY = (x.value / 14f).coerceIn(-maxTilt, maxTilt)
            cameraDistance = 14f * density
            val s = 1f - 0.018f * press.value
            scaleX = s; scaleY = s
        }
        .pointerInput(Unit) {
            detectHorizontalDragGestures(
                onDragStart = { scope.launch { press.animateTo(1f, spring(stiffness = 600f)) } },
                onDragEnd = { release() },
                onDragCancel = { release() },
                onHorizontalDrag = { c, dx ->
                    c.consume()
                    val cur = x.value
                    val damp = 1f / (1f + abs(cur) / (size.width * 0.18f))
                    scope.launch { x.snapTo(cur + dx * damp) }
                }
            )
        }
}

/** سحب مطّاطي بالاتجاهين (للأزرار الصغيرة): يتبع الإصبع ويعود بنابض. */
fun Modifier.rubberDrag2D(): Modifier = composed {
    val ox = remember { Animatable(0f) }
    val oy = remember { Animatable(0f) }
    val press = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    fun release() {
        scope.launch { ox.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = 280f)) }
        scope.launch { oy.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = 280f)) }
        scope.launch { press.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 400f)) }
    }
    this
        .graphicsLayer {
            translationX = ox.value; translationY = oy.value
            val s = 1f + 0.06f * press.value
            scaleX = s; scaleY = s
            rotationZ = (ox.value / 22f).coerceIn(-14f, 14f)
        }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { scope.launch { press.animateTo(1f, spring(stiffness = 600f)) } },
                onDragEnd = { release() },
                onDragCancel = { release() },
                onDrag = { c, d ->
                    c.consume()
                    val cx = ox.value; val cy = oy.value
                    val dist = kotlin.math.sqrt(cx * cx + cy * cy)
                    val damp = 1f / (1f + dist / (size.width * 0.9f))
                    scope.launch { ox.snapTo(cx + d.x * damp); oy.snapTo(cy + d.y * damp) }
                }
            )
        }
}

/**
 * مفتاح زجاجي بأسلوب iOS: الإبهام يتمدّد عند اللمس، ويمكن سحبه أو الضغط عليه، ويستقر بنابض.
 * يُرسم من اليسار لليمين دائمًا (الإبهام يمينًا = مفعّل).
 */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val prog = remember { Animatable(if (checked) 1f else 0f) }
    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val stretch by animateFloatAsState(if (pressed) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "sw-stretch")
    val cb by rememberUpdatedState(onChange)
    val cur by rememberUpdatedState(checked)
    LaunchedEffect(checked) {
        if (!dragging) prog.animateTo(if (checked) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 420f))
    }
    val onColor = TM.Emerald
    Canvas(
        modifier.size(60.dp, 36.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); cb(!cur) }
                )
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true; pressed = true },
                    onDragEnd = {
                        dragging = false; pressed = false
                        val target = prog.value > 0.5f
                        if (target != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); cb(target) }
                        else scope.launch { prog.animateTo(if (cur) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 420f)) }
                    },
                    onDragCancel = {
                        dragging = false; pressed = false
                        scope.launch { prog.animateTo(if (cur) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 420f)) }
                    },
                    onHorizontalDrag = { c, dx ->
                        c.consume()
                        val travel = (size.width - 6.dp.toPx() * 2 - (size.height - 6.dp.toPx())).coerceAtLeast(1f)
                        scope.launch { prog.snapTo((prog.value + dx / travel).coerceIn(0f, 1f)) }
                    }
                )
            }
    ) {
        val w = size.width; val h = size.height
        val p = prog.value
        drawRoundRect(
            lerp(Color.White.copy(alpha = 0.18f), onColor.copy(alpha = 0.92f), p),
            size = Size(w, h), cornerRadius = CornerRadius(h / 2f, h / 2f)
        )
        drawRoundRect(
            Color.White.copy(alpha = 0.14f), size = Size(w, h), cornerRadius = CornerRadius(h / 2f, h / 2f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx())
        )
        val pad = 3.dp.toPx()
        val th = h - pad * 2
        val tw = th * (1f + 0.42f * stretch)
        val travel = w - pad * 2 - th
        // عند التمدد يبقى الطرف الخارجي ثابتًا فيتمدد الإبهام نحو الداخل
        val x = pad + travel * p - (tw - th) * p
        drawRoundRect(Color.Black.copy(alpha = 0.28f), Offset(x, pad + 2.dp.toPx()), Size(tw, th), CornerRadius(th / 2f, th / 2f))
        drawRoundRect(
            Brush.verticalGradient(listOf(Color.White, Color(0xFFE9E9E9)), startY = pad, endY = pad + th),
            Offset(x, pad), Size(tw, th), CornerRadius(th / 2f, th / 2f)
        )
    }
}

/**
 * شريط اختيار زجاجي بأسلوب iOS: كبسولة تنزلق بنابض إلى الخيار، ويمكنك سحبها بإصبعك بين الخيارات.
 * يحترم اتجاه اللغة (العربية من اليمين).
 */
@Composable
fun GlassSegmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val n = options.size
    if (n == 0) return
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    fun vis(i: Int) = if (rtl) n - 1 - i else i
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val pos = remember { Animatable(vis(selected).toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onSelect)
    val sel by rememberUpdatedState(selected)
    LaunchedEffect(selected, rtl) {
        if (!dragging) pos.animateTo(vis(selected).toFloat(), spring(dampingRatio = 0.62f, stiffness = 420f))
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(17.dp))
                .background(Color.White.copy(alpha = 0.08f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(17.dp))
                .padding(3.dp)
        ) {
            val segW = maxWidth / n
            val segPx = with(LocalDensity.current) { segW.toPx() }
            Box(
                Modifier.offset { IntOffset((pos.value * segPx).roundToInt(), 0) }
                    .width(segW).fillMaxHeight().clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(Color.White.copy(0.30f), Color.White.copy(0.14f))))
                    .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            )
            Row(
                Modifier.fillMaxSize().pointerInput(n, rtl) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = {
                            dragging = false
                            val t = pos.value.roundToInt().coerceIn(0, n - 1)
                            scope.launch { pos.animateTo(t.toFloat(), spring(dampingRatio = 0.62f, stiffness = 420f)) }
                            val logical = if (rtl) n - 1 - t else t
                            if (logical != sel) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); cb(logical) }
                        },
                        onDragCancel = {
                            dragging = false
                            scope.launch { pos.animateTo(vis(sel).toFloat(), spring()) }
                        },
                        onHorizontalDrag = { c, dx ->
                            c.consume()
                            scope.launch { pos.snapTo((pos.value + dx / segPx).coerceIn(0f, (n - 1).toFloat())) }
                        }
                    )
                }
            ) {
                for (v in 0 until n) {
                    val logical = if (rtl) n - 1 - v else v
                    val active = logical == selected
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clickable(
                            interactionSource = remember { MutableInteractionSource() }, indication = null
                        ) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); cb(logical) },
                        Alignment.Center
                    ) {
                        Text(
                            options[logical], color = if (active) Color.White else Color.White.copy(0.6f),
                            fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1, textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

/** بلاطة سريعة زجاجية: تُسحب بإصبعك في أي اتجاه فتتبعك وتعود بنابض، وتعمل بنقرة. */
@Composable
fun QuickTile(icon: ImageVector, title: String, sub: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.rubberDrag2D().height(104.dp)
            .glass(shape, strength = 1f)
            .liquidPress(0.94f, onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, null, Modifier.size(26.dp), tint = Color.White)
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text(sub, color = Color.White.copy(0.6f), fontSize = 11.sp, maxLines = 1)
        }
    }
}
