package com.tmusic.app

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.media.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.Surface
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.delay
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color as CColor
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** نقطة الدخول: ReelUi.open(song) من أي مكان (قائمة الأغنية، شاشة التشغيل). */
object ReelUi {
    var song by mutableStateOf<Song?>(null)
    fun open(s: Song) { song = s }
    fun close() { song = null }
}

/**
 * يصنع فيديو عموديًا 9:16 (720×1280) من غلاف الأغنية ومقطع صوتي منها، بدون أي مكتبة خارجية:
 * الفيديو عبر MediaCodec (H.264) من رسم Canvas، والصوت يُفكّ ثم يُرمَّز AAC، ثم يُدمجان في MP4.
 */
object ReelMaker {
    private const val W = 720
    private const val H = 1280
    private const val FPS = 30
    private fun landscape(style: Int) = style >= REEL_VIDEO_BASE
    private fun outW(style: Int) = if (landscape(style)) REEL_LAND_W else W
    private fun outH(style: Int) = if (landscape(style)) REEL_LAND_H else H
    private const val TIMEOUT = 10_000L

    suspend fun create(ctx: Context, song: Song, startMs: Long, lenSec: Int, style: Int, label: String, onProgress: (Float) -> Unit): File? =
        withContext(Dispatchers.Default) {
            val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.filter { it.name.startsWith("reel_") }?.forEach { runCatching { it.delete() } }
            val vFile = File(dir, "reel_v.mp4")
            val aFile = File(dir, "reel_a.m4a")
            val out = File(dir, "reel_${System.currentTimeMillis()}.mp4")
            val art = runCatching { Art.get(ctx, song) }.getOrNull()
            var audioOk = false
            val lv = Levels()
            try {
                onProgress(0.02f)
                audioOk = runCatching { encodeAudio(ctx, song, startMs * 1000L, lenSec, aFile, lv) }.getOrDefault(false)
                onProgress(0.12f)
                val spec = Spectrum(lv.frames, FPS)
                encodeVideo(ctx, song, art, lenSec, startMs, style, label, spec, vFile) { onProgress(0.12f + 0.80f * it) }
                onProgress(0.95f)
                if (audioOk) muxTogether(vFile, aFile, out) else vFile.copyTo(out, overwrite = true)
                onProgress(1f)
                out
            } catch (t: Throwable) {
                runCatching { out.delete() }
                null
            } finally {
                runCatching { vFile.delete() }; runCatching { aFile.delete() }
            }
        }

    private class Levels { var frames: Array<FloatArray>? = null }

    private fun makeScene(ctx: Context, song: Song, art: Bitmap?, lenSec: Int, startMs: Long, style: Int, label: String, spec: Spectrum): ReelFrame =
        when (style) {
            0 -> GlassScene(ctx, song, art?.let { ReelArt.trimmed(it) }, lenSec, startMs, label, spec)
            1 -> SakuraScene(ctx, song, art?.let { ReelArt.trimmed(it) }, lenSec, startMs, label, spec)
            in REEL_VIDEO_BASE until REEL_VIDEO_BASE + reelVideoNames.size ->
                VideoScene(ctx, song, art?.let { ReelArt.trimmed(it) }, lenSec, label, spec, startMs, style - REEL_VIDEO_BASE)
            else -> Scene(ctx, song, art, lenSec, style - 2)
        }

    /** صور مصغّرة حقيقية لكل قالب بغلاف الأغنية نفسها (للعرض في ورقة الإنشاء). */
    suspend fun previews(ctx: Context, song: Song, label: String): List<Bitmap?> = withContext(Dispatchers.Default) {
        val art = runCatching { Art.get(ctx, song) }.getOrNull()
        val spec = Spectrum(null, FPS)
        List(reelTemplateNames.size) { st ->
            runCatching {
                val bmp = Bitmap.createBitmap(outW(st) / 2, outH(st) / 2, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.scale(0.5f, 0.5f)
                val scene = makeScene(ctx, song, art, 15, 0L, st, label, spec)
                try { scene.draw(c, 3f) } finally { scene.recycle() }
                bmp
            }.getOrNull()
        }
    }

    // ---------------- الفيديو ----------------
    private fun encodeVideo(ctx: Context, song: Song, art: Bitmap?, lenSec: Int, startMs: Long, style: Int, label: String, spec: Spectrum, out: File, onProgress: (Float) -> Unit) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW(style), outH(style)).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, if (landscape(style)) 7_000_000 else 4_500_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface: Surface = enc.createInputSurface()
        enc.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var written = 0
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean) {
            var idle = 0
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, if (end) TIMEOUT else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return
                    if (++idle > 400) return
                    continue
                }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.outputFormat); mux.start(); started = true; continue
                }
                if (idx < 0) continue
                val buf = enc.getOutputBuffer(idx)
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (buf != null && info.size > 0 && started) {
                    info.presentationTimeUs = written * 1_000_000L / FPS
                    written++
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    mux.writeSampleData(track, buf, info)
                }
                enc.releaseOutputBuffer(idx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }

        val scene = makeScene(ctx, song, art, lenSec, startMs, style, label, spec)
        try {
            val total = lenSec * FPS
            val frameMs = 1000L / FPS
            for (f in 0 until total) {
                val t0 = System.currentTimeMillis()
                val c = try { surface.lockHardwareCanvas() } catch (e: Throwable) { surface.lockCanvas(null) }
                try { scene.draw(c, f / FPS.toFloat()) } finally { surface.unlockCanvasAndPost(c) }
                drain(false)
                onProgress(f / total.toFloat())
                // نحافظ على وتيرة 30 إطارًا في الثانية حتى لا يُسقط المرمِّز إطارات
                val spent = System.currentTimeMillis() - t0
                if (spent < frameMs) Thread.sleep(frameMs - spent)
            }
            enc.signalEndOfInputStream()
            drain(true)
        } finally {
            runCatching { enc.stop() }; runCatching { enc.release() }
            runCatching { if (started) mux.stop() }; runCatching { mux.release() }
            runCatching { surface.release() }
            scene.recycle()
        }
    }

    /** مشهد الفيديو: خلفية ضبابية من الغلاف + غلاف نابض + أعمدة صوت + عنوان + علامة T Music. */
    private class Scene(ctx: Context, val song: Song, val art: Bitmap?, val lenSec: Int, val style: Int) : ReelFrame {
        private val accent: Int
        private val bg: Bitmap
        private val logo: Bitmap? = runCatching { BitmapFactory.decodeResource(ctx.resources, R.drawable.tm_logo) }.getOrNull()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 54f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        private val sub = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 255, 255, 255); textSize = 38f; textAlign = Paint.Align.CENTER }
        private val tag = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 40f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        private val cta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(210, 255, 255, 255); textSize = 34f; textAlign = Paint.Align.CENTER }
        private val tTitle = TextUtils.ellipsize(song.title, title, W - 120f, TextUtils.TruncateAt.END).toString()
        private val tArtist = TextUtils.ellipsize(song.artist, sub, W - 160f, TextUtils.TruncateAt.END).toString()

        init {
            var base = Color.rgb(90, 90, 110)
            if (art != null) {
                val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
                val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
                hsv[1] = hsv[1].coerceAtLeast(0.55f); hsv[2] = hsv[2].coerceAtLeast(0.9f)
                base = Color.HSVToColor(hsv)
            }
            accent = base
            val full = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val c = Canvas(full)
            if (art != null) {
                val small = Bitmap.createScaledBitmap(art, 24, 24, true)
                // تعبئة الشاشة بالغلاف المصغّر المُكبَّر بترشيح ناعم = تمويه رخيص ومتناسق
                val side = H.toFloat()
                c.drawBitmap(small, null, RectF((W - side) / 2f, 0f, (W + side) / 2f, side), paint)
            } else c.drawColor(Color.rgb(24, 24, 28))
            c.drawColor(Color.argb(120, 0, 0, 0))
            bg = full
        }

        override fun recycle() { runCatching { bg.recycle() } }

        override fun draw(c: Canvas, t: Float) {
            c.drawBitmap(bg, 0f, 0f, null)
            // وهج بلون الغلاف
            val glow = RadialGradient(W / 2f, 520f, 520f, Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent)), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            paint.shader = glow; c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint); paint.shader = null

            // العلامة العلوية
            logo?.let {
                val h = 64f; val w = h * it.width / it.height
                c.drawBitmap(it, null, RectF(W / 2f - w / 2f, 70f, W / 2f + w / 2f, 70f + h), paint)
            }
            c.drawText("T Music", W / 2f, 190f, tag)

            // الغلاف
            val beat = 1f + 0.03f * sin(2.0 * PI * 2.0 * t).toFloat()
            val size = 560f * beat
            val cx = W / 2f; val cy = 560f
            val dst = RectF(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2)
            c.save()
            val path = Path()
            if (style == 1) path.addCircle(cx, cy, size / 2, Path.Direction.CW) else path.addRoundRect(dst, 56f, 56f, Path.Direction.CW)
            c.clipPath(path)
            if (style == 1) c.rotate(t * 24f, cx, cy)
            if (art != null) c.drawBitmap(art, null, dst, paint) else { paint.color = accent; c.drawRect(dst, paint) }
            c.restore()
            if (style == 1) { // ثقب الأسطوانة
                paint.color = Color.argb(230, 10, 10, 12); c.drawCircle(cx, cy, 44f, paint)
                paint.color = accent; c.drawCircle(cx, cy, 20f, paint)
            }

            // العنوان
            c.drawText(tTitle, W / 2f, 930f, title)
            c.drawText(tArtist, W / 2f, 990f, sub)

            // أعمدة الصوت
            val n = 34; val bw = 12f; val gap = 8f
            val total = n * bw + (n - 1) * gap
            var x = (W - total) / 2f
            paint.color = accent
            for (i in 0 until n) {
                val a = abs(sin(t * 3.1 + i * 0.7)).toFloat()
                val b = 0.55f + 0.45f * sin(t * 1.3 + i * 0.21).toFloat()
                val h = 18f + 96f * a * b
                c.drawRoundRect(RectF(x, 1130f - h, x + bw, 1130f), 6f, 6f, paint)
                x += bw + gap
            }
            // شريط التقدم
            paint.color = Color.argb(70, 255, 255, 255); c.drawRoundRect(RectF(80f, 1170f, W - 80f, 1178f), 4f, 4f, paint)
            paint.color = Color.WHITE
            c.drawRoundRect(RectF(80f, 1170f, 80f + (W - 160f) * (t / lenSec).coerceIn(0f, 1f), 1178f), 4f, 4f, paint)
            c.drawText("استمع إلى المزيد على T Music", W / 2f, 1240f, cta)
        }
    }

    // ---------------- الصوت ----------------
    private fun encodeAudio(ctx: Context, song: Song, startUs: Long, lenSec: Int, out: File, lv: Levels): Boolean {
        val ex = MediaExtractor()
        try {
            if (song.remoteUrl != null) ex.setDataSource(song.remoteUrl) else ex.setDataSource(ctx, song.uri, null)
            var ti = -1; var inFmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { ti = i; inFmt = f; break }
            }
            if (ti < 0 || inFmt == null) return false
            ex.selectTrack(ti)
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
            dec.configure(inFmt, null, null, 0)
            dec.start()
            var rate = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val pcm = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inEos = false; var outEos = false
            var spins = 0
            while (!outEos && spins < 20000) {
                spins++
                if (!inEos) {
                    val i = dec.dequeueInputBuffer(TIMEOUT)
                    if (i >= 0) {
                        val b = dec.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        val pt = ex.sampleTime
                        if (n < 0 || pt - startUs > (lenSec + 1) * 1_000_000L) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inEos = true
                        } else { dec.queueInputBuffer(i, 0, n, pt, 0); ex.advance() }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, TIMEOUT)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = dec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (o >= 0) {
                    val b = dec.getOutputBuffer(o)
                    if (b != null && info.size > 0) {
                        val arr = ByteArray(info.size); b.position(info.offset); b.get(arr); pcm.write(arr)
                    }
                    dec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outEos = true
                    if (pcm.size() >= lenSec.toLong() * rate * ch * 2) outEos = true
                }
            }
            runCatching { dec.stop() }; runCatching { dec.release() }
            val frameBytes = 2 * ch
            var data = pcm.toByteArray()
            val maxBytes = (lenSec.toLong() * rate * frameBytes).toInt().coerceAtMost(data.size)
            data = data.copyOf(maxBytes - maxBytes % frameBytes)
            if (data.isEmpty()) return false
            // الطيف الحقيقي للمقطع (قبل التلاشي) لتتحرك به الأعمدة في الفيديو
            runCatching { lv.frames = AudioAnalysis.analyze(data, rate, ch, FPS, Spectrum.BANDS) }
            // تلاشٍ في آخر ثانية
            val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            val fade = (rate * ch).coerceAtMost(data.size / 2)
            val totalShorts = data.size / 2
            for (k in 0 until fade) {
                val idx = totalShorts - fade + k
                bb.putShort(idx * 2, (bb.getShort(idx * 2) * (1f - k / fade.toFloat())).toInt().toShort())
            }
            return encodeAac(data, rate, ch, out)
        } finally { runCatching { ex.release() } }
    }

    private fun encodeAac(data: ByteArray, rate: Int, ch: Int, out: File): Boolean {
        val mime = MediaFormat.MIMETYPE_AUDIO_AAC
        val af = MediaFormat.createAudioFormat(mime, rate, ch).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(mime)
        enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1; var started = false
        val info = MediaCodec.BufferInfo()
        var off = 0; var eosSent = false; var done = false; var spins = 0
        val frameBytes = 2 * ch
        try {
            while (!done && spins < 200000) {
                spins++
                if (!eosSent) {
                    val i = enc.dequeueInputBuffer(TIMEOUT)
                    if (i >= 0) {
                        val b = enc.getInputBuffer(i)!!
                        b.clear()
                        var n = min(b.remaining(), data.size - off)
                        n -= n % frameBytes
                        val pts = (off / frameBytes).toLong() * 1_000_000L / rate
                        if (n <= 0) { enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eosSent = true }
                        else { b.put(data, off, n); enc.queueInputBuffer(i, 0, n, pts, 0); off += n }
                    }
                }
                val o = enc.dequeueOutputBuffer(info, TIMEOUT)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.outputFormat); mux.start(); started = true
                } else if (o >= 0) {
                    val b = enc.getOutputBuffer(o)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (b != null && info.size > 0 && started) {
                        b.position(info.offset); b.limit(info.offset + info.size)
                        mux.writeSampleData(track, b, info)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
                }
            }
        } finally {
            runCatching { enc.stop() }; runCatching { enc.release() }
            runCatching { if (started) mux.stop() }; runCatching { mux.release() }
        }
        return done && started
    }

    // ---------------- الدمج ----------------
    private fun muxTogether(video: File, audio: File, out: File) {
        val m = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val ve = MediaExtractor().apply { setDataSource(video.path) }
        val ae = MediaExtractor().apply { setDataSource(audio.path) }
        try {
            fun pick(e: MediaExtractor, prefix: String): Int {
                for (i in 0 until e.trackCount) if (e.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
                return -1
            }
            val vt = pick(ve, "video/"); val at = pick(ae, "audio/")
            val vi = m.addTrack(ve.getTrackFormat(vt)); val ai = m.addTrack(ae.getTrackFormat(at))
            m.start()
            fun copy(e: MediaExtractor, t: Int, idx: Int) {
                e.selectTrack(t)
                val buf = ByteBuffer.allocate(1 shl 20)
                val bi = MediaCodec.BufferInfo()
                while (true) {
                    buf.clear()
                    val n = e.readSampleData(buf, 0)
                    if (n < 0) break
                    bi.set(0, n, e.sampleTime, e.sampleFlags)
                    m.writeSampleData(idx, buf, bi)
                    e.advance()
                }
            }
            copy(ve, vt, vi); copy(ae, at, ai)
            m.stop()
        } finally {
            runCatching { m.release() }; runCatching { ve.release() }; runCatching { ae.release() }
        }
    }
}

private class ShareTarget(val label: String, val pkg: String)

private val shareTargets = listOf(
    ShareTarget("انستغرام", "com.instagram.android"),
    ShareTarget("تيك توك", "com.zhiliaoapp.musically"),
    ShareTarget("سناب شات", "com.snapchat.android"),
    ShareTarget("واتساب", "com.whatsapp"),
    ShareTarget("فيسبوك", "com.facebook.katana"),
    ShareTarget("يوتيوب", "com.google.android.youtube")
)

private fun installed(ctx: Context, pkg: String) = runCatching { ctx.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

private fun shareVideo(ctx: Context, file: File, song: Song, pkg: String?) {
    val uri = FileProvider.getUriForFile(ctx, "com.tmusic.app.files", file)
    val caption = "🎧 ${song.title} — ${song.artist}\nأسمعها على T Music #TMusic"
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, caption)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (pkg != null) setPackage(pkg)
    }
    val launch = if (pkg == null) Intent.createChooser(i, "نشر الريلز").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) else i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(launch) }
        .onFailure { android.widget.Toast.makeText(ctx, "تعذّر فتح التطبيق، جرّب «المزيد»", android.widget.Toast.LENGTH_SHORT).show() }
}

@Composable
private fun TemplateCard(name: String, bmp: Bitmap?, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            (if (bmp != null && bmp.width > bmp.height) Modifier.width(150.dp).height(84.dp) else Modifier.width(84.dp).height(150.dp)).clip(RoundedCornerShape(14.dp))
                .background(CColor(0xFF202024))
                .then(if (selected) Modifier.border(2.dp, CColor.White, RoundedCornerShape(14.dp)) else Modifier)
                .clickable(enabled = enabled, onClick = onClick)
        ) {
            if (bmp != null) Image(bmp.asImageBitmap(), name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(4.dp))
        Text(name, fontSize = 12.sp, color = if (selected) CColor.White else TM.Muted)
    }
}

@Composable
private fun LenDot(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(CircleShape)
            .background(if (selected) CColor.White else CColor(0x22FFFFFF))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) CColor.Black else CColor.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** ورقة «نشر ريلز»: قالب بمعاينة حقيقية، عبارة، ثم تحديد المقطع بالموجة، ثم إنشاء الفيديو ونشره. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelOverlay() {
    val song = ReelUi.song ?: return
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val ui = activeUi
    val prefs = remember { ctx.applicationContext.getSharedPreferences("tm_reel", Context.MODE_PRIVATE) }
    var len by remember(song.id) { mutableIntStateOf(prefs.getInt("len", 15)) }
    val initFrac = remember(song.id) {
        if (ui != null && ui.currentId == song.id && ui.duration > 0) (ui.position.toFloat() / ui.duration).coerceIn(0f, 0.95f) else 0.25f
    }
    var startFrac by remember(song.id) { mutableFloatStateOf(initFrac) }
    var style by remember(song.id) { mutableIntStateOf(prefs.getInt("style", 0).coerceIn(0, reelTemplateNames.size - 1)) }
    var label by remember { mutableStateOf(prefs.getString("label", "T MUSIC") ?: "T MUSIC") }
    var busy by remember(song.id) { mutableStateOf(false) }
    var prog by remember(song.id) { mutableFloatStateOf(0f) }
    var result by remember(song.id) { mutableStateOf<File?>(null) }
    var publishing by remember(song.id) { mutableStateOf(false) }
    var previews by remember(song.id) { mutableStateOf<List<Bitmap?>>(emptyList()) }
    var peaks by remember(song.id) { mutableStateOf<FloatArray?>(null) }
    val fakePeaks = remember(song.id) { ReelWave.fake(song.id) }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    LaunchedEffect(song.id) { peaks = ReelWave.load(ctx, song) }
    LaunchedEffect(song.id, label) {
        delay(600)
        previews = ReelMaker.previews(ctx, song, label)
    }

    ModalBottomSheet(
        onDismissRequest = { if (!busy) ReelUi.close() }, sheetState = state,
        containerColor = Color0, contentColor = androidx.compose.ui.graphics.Color.White
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp).padding(bottom = 22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cover(song, Modifier.size(64.dp), 14.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("نشر ريلز بهذه الأغنية", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(song.title + " — " + song.artist, color = TM.Muted, fontSize = 13.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (result == null) {
                Text("القالب", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    reelTemplateNames.forEachIndexed { i, n ->
                        TemplateCard(n, previews.getOrNull(i), style == i, !busy) { style = i; prefs.edit().putInt("style", i).apply() }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = label, onValueChange = { v -> if (!busy) { label = v.take(22); prefs.edit().putString("label", label).apply() } },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy,
                    label = { Text("العبارة على الريلز (اسمك أو اسم قناتك)") }
                )
                Spacer(Modifier.height(16.dp))

                val durMs = song.duration.coerceAtLeast(len * 1000L)
                val startMs = (((durMs - len * 1000L).coerceAtLeast(0L)) * startFrac).toLong()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("اختر المقطع", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(fmt(startMs) + " – " + fmt(startMs + len * 1000L), color = TM.Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(10, 15, 30, 60).forEach { s ->
                        LenDot(s.toString(), len == s, !busy) { len = s; prefs.edit().putInt("len", s).apply() }
                    }
                    Text("ثانية", color = TM.Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(10.dp))
                WaveClipPicker(peaks ?: fakePeaks, durMs, len, startFrac, !busy, { startFrac = it })
                Text("اسحب الإطار الأبيض على الموجة لتحديد بداية المقطع", color = TM.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                if (busy) {
                    LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text("جارٍ تجهيز الفيديو… ${(prog * 100).toInt()}% (يستغرق قرابة مدة المقطع)", color = TM.Muted, fontSize = 12.sp)
                } else {
                    Button({
                        busy = true; prog = 0f
                        scope.launch {
                            val f = ReelMaker.create(ctx, song, startMs, len, style, label) { prog = it }
                            busy = false
                            if (f != null) result = f
                            else {
                                android.widget.Toast.makeText(ctx, "تعذّر إنشاء الفيديو على هذا الجهاز، سأشارك بطاقة الأغنية بدلًا منه", android.widget.Toast.LENGTH_LONG).show()
                                shareSongCard(ctx, song)
                                ReelUi.close()
                            }
                        }
                    }, Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.IosShare, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("إنشاء الريلز")
                    }
                }
            } else {
                Text("الريلز جاهز ✔ اختر أين تنشره", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                if (ReelsConfig.enabled) {
                    Button({
                        publishing = true
                        scope.launch {
                            val msg = ReelsHub.publish(ctx, result!!, song, label)
                            publishing = false
                            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.fillMaxWidth(), enabled = !publishing) {
                        Icon(Icons.Rounded.Public, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                        Text(if (publishing) "جارٍ النشر…" else "انشر في ريلز T Music")
                    }
                    Spacer(Modifier.height(10.dp))
                }
                val targets = remember { shareTargets.filter { installed(ctx, it.pkg) } }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    targets.forEach { t -> FilledTonalButton({ shareVideo(ctx, result!!, song, t.pkg) }) { Text(t.label) } }
                    FilledTonalButton({ shareVideo(ctx, result!!, song, null) }) { Text("المزيد") }
                }
                Spacer(Modifier.height(8.dp))
                Text("في انستغرام اختر «ريلز» عند فتح الفيديو. ستُرفق وسوم T Music مع النص.", color = TM.Muted, fontSize = 12.sp)
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color(0xFF17171A)
