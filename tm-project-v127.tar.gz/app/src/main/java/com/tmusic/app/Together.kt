package com.tmusic.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * استماع مشترك: غرفة برمز قصير (على Firestore) يتزامن فيها التشغيل بين صديقين.
 * المضيف ينشر الأغنية (العنوان والفنان) وموضع التشغيل وحالته، والضيف يجد نفس الأغنية في مكتبته بالعنوان ويتابع المضيف.
 * شرط: الأغنية موجودة عند الطرفين. التزامن يعتمد على ساعتي الهاتفين فقد يظهر فرق ثانية أو اثنتين.
 */
object Together {
    var role by mutableIntStateOf(0)        // 0 لا شيء، 1 مضيف، 2 ضيف
        private set
    var code by mutableStateOf("")
        private set
    var status by mutableStateOf("")
        private set

    private const val COL = "tm_rooms"
    private var job: Job? = null
    private var reg: ListenerRegistration? = null

    private fun nz(x: String) = x.lowercase().filter { it.isLetterOrDigit() }
    private fun newCode(): String {
        val a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..5).map { a.random() }.joinToString("")
    }

    fun available(ctx: Context) = Cloud.ready(ctx)

    // ---------------- المضيف ----------------
    fun host(ctx: Context, ui: PlayerUi, byId: Map<Long, Song>) {
        if (!available(ctx)) { status = "تسجيل الدخول/Firebase غير مفعّل في هذه النسخة"; return }
        leave()
        val c = newCode()
        code = c; role = 1; status = "الغرفة جاهزة. أعطِ الرمز لصديقك."
        val doc = FirebaseFirestore.getInstance().collection(COL).document(c)
        job = Cloud.scope.launch {
            var lastId = Long.MIN_VALUE; var lastPlaying = false; var lastPos = 0L; var lastWrite = 0L
            while (isActive && role == 1) {
                val song = byId[ui.currentId]
                val playing = ui.isPlaying
                val pos = ui.controller?.currentPosition ?: ui.position
                val now = System.currentTimeMillis()
                val expected = lastPos + if (lastPlaying) now - lastWrite else 0L
                val changed = ui.currentId != lastId || playing != lastPlaying || kotlin.math.abs(pos - expected) > 1800L
                if (song != null && (changed || now - lastWrite > 20_000L)) {
                    lastId = ui.currentId; lastPlaying = playing; lastPos = pos; lastWrite = now
                    doc.set(
                        mapOf(
                            "title" to song.title, "artist" to song.artist, "dur" to song.duration,
                            "playing" to playing, "pos" to pos, "at" to now, "host" to Profile.name
                        )
                    ).addOnFailureListener { status = "تعذّر النشر: ${it.message ?: "تحقق من قواعد Firestore"}" }
                }
                delay(800)
            }
        }
    }

    // ---------------- الضيف ----------------
    fun join(ctx: Context, input: String, songs: List<Song>, ui: PlayerUi) {
        if (!available(ctx)) { status = "تسجيل الدخول/Firebase غير مفعّل في هذه النسخة"; return }
        val c = input.trim().uppercase()
        if (c.length < 4) { status = "الرمز غير صحيح"; return }
        leave()
        code = c; role = 2; status = "جارٍ الاتصال…"
        reg = FirebaseFirestore.getInstance().collection(COL).document(c).addSnapshotListener { snap, err ->
            if (err != null) { status = "خطأ: ${err.message ?: "تعذّر الاتصال"}"; return@addSnapshotListener }
            if (snap == null || !snap.exists()) { status = "لا توجد غرفة بهذا الرمز (أو أُغلقت)"; return@addSnapshotListener }
            val title = snap.getString("title") ?: return@addSnapshotListener
            val artist = snap.getString("artist") ?: ""
            val playing = snap.getBoolean("playing") ?: false
            val pos = snap.getLong("pos") ?: 0L
            val at = snap.getLong("at") ?: System.currentTimeMillis()
            val target = pos + if (playing) (System.currentTimeMillis() - at).coerceIn(0L, 60_000L) else 0L
            val nt = nz(title); val na = nz(artist)
            val mine = songs.firstOrNull { nz(it.title) == nt && (na.isEmpty() || nz(it.artist) == na) }
                ?: songs.firstOrNull { nz(it.title) == nt }
            if (mine == null) { status = "الأغنية «$title» غير موجودة في مكتبتك"; ui.controller?.pause(); return@addSnapshotListener }
            status = "متزامن مع ${snap.getString("host")?.ifBlank { null } ?: "المضيف"} · $title"
            if (ui.currentId != mine.id) ui.play(listOf(mine), 0)
            val cur = ui.controller?.currentPosition ?: 0L
            if (kotlin.math.abs(cur - target) > 2000L) ui.seek(target)
            if (playing && ui.controller?.isPlaying != true) ui.controller?.play()
            if (!playing && ui.controller?.isPlaying == true) ui.controller?.pause()
        }
    }

    fun leave() {
        val wasHost = role == 1
        val c = code
        job?.cancel(); job = null
        reg?.remove(); reg = null
        role = 0; code = ""; status = ""
        if (wasHost && c.isNotBlank()) runCatching { FirebaseFirestore.getInstance().collection(COL).document(c).delete() }
    }
}

@Composable
fun TogetherDialog(songs: List<Song>, ui: PlayerUi, byId: Map<Long, Song>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("استماع مشترك") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (Together.role) {
                    1 -> {
                        Text("رمز غرفتك", color = TM.Muted, fontSize = 13.sp)
                        Text(Together.code, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = TM.VioletSoft)
                        Text("شغّل ما تشاء، وسيتابعك صديقك تلقائيًا.", color = TM.Muted, fontSize = 12.sp)
                    }
                    2 -> Text("أنت في الغرفة ${Together.code}", color = TM.VioletSoft)
                    else -> {
                        Text("أنشئ غرفة وشارك رمزها، أو أدخل رمز صديقك.", color = TM.Muted, fontSize = 13.sp)
                        OutlinedTextField(input, { input = it.take(8) }, singleLine = true, label = { Text("رمز الغرفة") })
                    }
                }
                if (Together.status.isNotBlank()) Text(Together.status, color = TM.Gold, fontSize = 12.sp)
            }
        },
        confirmButton = {
            if (Together.role == 0) Row {
                TextButton({ Together.join(ctx, input, songs, ui) }, enabled = input.length >= 4) { Text("انضمام") }
                TextButton({ Together.host(ctx, ui, byId) }) { Text("إنشاء غرفة") }
            } else TextButton({ Together.leave() }) { Text(if (Together.role == 1) "إغلاق الغرفة" else "مغادرة") }
        },
        dismissButton = { TextButton(onDismiss) { Text("إخفاء") } }
    )
}
