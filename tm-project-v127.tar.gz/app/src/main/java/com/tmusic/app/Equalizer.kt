package com.tmusic.app

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * إيكولايزر بعشرة نطاقات افتراضية (31Hz..16kHz) كما في المشغّلات الكبيرة.
 * مستويات النطاقات العشرة تُحوَّل بالاستيفاء اللوغاريتمي إلى نطاقات المعالج الفعلية في الجهاز (غالبًا 5)،
 * فيعمل على كل الأجهزة بدون مكتبة معالجة خارجية.
 */
object Eq {
    class Preset(val name: String, val gains: List<Float>)

    val vfreq = listOf(31, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val vlabels = listOf("31", "63", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

    /** الفهرس 0 = «مخصص» (قيمه تتبع ما يضبطه المستخدم). */
    val presets = listOf(
        Preset("مخصص", List(10) { 0f }),
        Preset("تعزيز الباس", listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f)),
        Preset("تعزيز الأصوات", listOf(-2f, -2f, -1f, 1f, 3f, 4f, 3f, 1f, 0f, -1f)),
        Preset("تعزيز الحدة", listOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 5f, 6f)),
        Preset("عادي", List(10) { 0f }),
        Preset("بوب", listOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f)),
        Preset("هيب هوب", listOf(5f, 4f, 2f, 3f, -1f, -1f, 1f, -1f, 2f, 3f)),
        Preset("روك", listOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f)),
        Preset("إلكترونيك", listOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 2f, 4f, 5f)),
        Preset("هيفي ميتال", listOf(4f, 3f, 0f, -3f, -4f, 0f, 3f, 5f, 4f, 3f)),
        Preset("آر أند بي", listOf(3f, 6f, 5f, 1f, -2f, -1f, 2f, 2f, 3f, 3f)),
        Preset("فولك", listOf(3f, 2f, 0f, 0f, 1f, 2f, 3f, 2f, 1f, 1f)),
        Preset("دانس", listOf(4f, 7f, 5f, 0f, 2f, 3f, 5f, 4f, 3f, 0f)),
        Preset("جاز", listOf(4f, 3f, 1f, 2f, -2f, -2f, 0f, 1f, 3f, 4f)),
        Preset("كلاسيك", listOf(3f, 2f, 1f, 0f, 0f, 0f, -1f, 2f, 3f, 4f)),
        Preset("لاتيني", listOf(4f, 2f, 0f, 0f, -1f, -1f, 0f, 2f, 4f, 5f))
    )

    private var eq: Equalizer? = null
    private var boost: BassBoost? = null
    private var virt: Virtualizer? = null
    private var prefs: android.content.SharedPreferences? = null
    private val hwHz = mutableListOf<Int>()

    var available by mutableStateOf(false); private set
    var enabled by mutableStateOf(false); private set
    var minMb by mutableIntStateOf(-1500); private set
    var maxMb by mutableIntStateOf(1500); private set
    val levels = mutableStateListOf<Int>()
    val labels = mutableStateListOf<String>()
    /** مستويات النطاقات العشرة الافتراضية بالديسيبل. */
    val vgains = mutableStateListOf<Float>().also { l -> repeat(10) { l.add(0f) } }
    var bass by mutableIntStateOf(0); private set          // 0..1000
    var bassOk by mutableStateOf(false); private set
    var surround by mutableIntStateOf(0); private set      // 0..1000
    var surroundOk by mutableStateOf(false); private set
    var preset by mutableIntStateOf(4); private set        // 0 = مخصص

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tm_eq", Context.MODE_PRIVATE)
        prefs = p
        enabled = p.getBoolean("on", false)
        bass = p.getInt("bass", 0)
        surround = p.getInt("surround", 0)
        preset = p.getInt("preset2", 4).coerceIn(0, presets.size - 1)
        val saved = (p.getString("vgains", "") ?: "").split(",").mapNotNull { it.toFloatOrNull() }
        if (saved.size == 10) for (i in 0 until 10) vgains[i] = saved[i].coerceIn(-12f, 12f)
    }

    fun attach(ctx: Context, sessionId: Int) {
        init(ctx)
        release()
        if (sessionId == 0) return
        VolBoost.attach(sessionId)
        try {
            val e = Equalizer(0, sessionId)
            val n = e.numberOfBands.toInt()
            val r = e.bandLevelRange
            minMb = r[0].toInt(); maxMb = r[1].toInt()
            levels.clear(); labels.clear(); hwHz.clear()
            for (i in 0 until n) {
                levels.add(0)
                val hz = e.getCenterFreq(i.toShort()) / 1000
                hwHz.add(hz)
                labels.add(
                    if (hz >= 1000) (if (hz % 1000 == 0) "${hz / 1000} kHz" else String.format(java.util.Locale.US, "%.1f kHz", hz / 1000f))
                    else "$hz Hz"
                )
            }
            e.setEnabled(enabled)
            eq = e
            available = true
            pushToHardware()
        } catch (t: Throwable) { available = false }
        try {
            val b = BassBoost(0, sessionId)
            bassOk = b.strengthSupported
            if (bassOk) b.setStrength(bass.toShort())
            b.setEnabled(enabled)
            boost = b
        } catch (t: Throwable) { bassOk = false }
        try {
            val v = Virtualizer(0, sessionId)
            surroundOk = v.strengthSupported
            if (surroundOk) v.setStrength(surround.toShort())
            v.setEnabled(enabled)
            virt = v
        } catch (t: Throwable) { surroundOk = false }
    }

    fun release() {
        runCatching { eq?.release() }; runCatching { boost?.release() }; runCatching { virt?.release() }
        eq = null; boost = null; virt = null; available = false
        VolBoost.release()
    }

    private fun save() {
        prefs?.edit()?.putBoolean("on", enabled)?.putInt("bass", bass)?.putInt("surround", surround)
            ?.putInt("preset2", preset)?.putString("vgains", vgains.joinToString(","))?.apply()
    }

    fun enable(on: Boolean) {
        enabled = on
        runCatching { eq?.setEnabled(on) }; runCatching { boost?.setEnabled(on) }; runCatching { virt?.setEnabled(on) }
        save()
    }

    /** قيمة المنحنى الافتراضي عند تردد معيّن (استيفاء خطي على مقياس لوغاريتمي). */
    private fun curveAt(hz: Float): Float {
        if (hz <= vfreq.first()) return vgains.first()
        if (hz >= vfreq.last()) return vgains.last()
        var k = 0
        while (k < vfreq.size - 2 && hz >= vfreq[k + 1]) k++
        val t = (ln(hz) - ln(vfreq[k].toFloat())) / (ln(vfreq[k + 1].toFloat()) - ln(vfreq[k].toFloat()))
        return vgains[k] + (vgains[k + 1] - vgains[k]) * t
    }

    private fun pushToHardware() {
        for (i in levels.indices) {
            val hz = hwHz.getOrNull(i)?.toFloat() ?: continue
            // متوسط على عرض نصف أوكتاف تقريبًا ليشمل النطاق الواسع للمعالج
            val db = (curveAt(hz / 1.4f) + curveAt(hz) + curveAt(hz * 1.4f)) / 3f
            levels[i] = (db * 100).roundToInt().coerceIn(minMb, maxMb)
            runCatching { eq?.setBandLevel(i.toShort(), levels[i].toShort()) }
        }
    }

    fun setBand(i: Int, db: Float) {
        if (i !in 0 until 10) return
        vgains[i] = db.coerceIn(-12f, 12f)
        preset = 0
        pushToHardware(); save()
    }

    fun applyPreset(idx: Int) {
        val p = presets.getOrNull(idx) ?: return
        if (idx != 0) for (i in 0 until 10) vgains[i] = p.gains[i]
        preset = idx
        pushToHardware(); save()
    }

    fun changeBass(v: Int) {
        bass = v.coerceIn(0, 1000)
        runCatching { boost?.setStrength(bass.toShort()) }
        save()
    }

    fun changeSurround(v: Int) {
        surround = v.coerceIn(0, 1000)
        runCatching { virt?.setStrength(surround.toShort()) }
        save()
    }
}

/** فتح/إغلاق شاشة الإيكولايزر من أي مكان (الشاشة نفسها تُرسم في جذر التطبيق). */
object EqUi {
    var open by mutableStateOf(false)
    fun show(ctx: Context) { Eq.init(ctx); open = true }
}

private val presetIcons: List<ImageVector> = listOf(
    Icons.Rounded.GraphicEq, Icons.Rounded.Speaker, Icons.Rounded.Mic, Icons.Rounded.SurroundSound,
    Icons.Rounded.SentimentSatisfiedAlt, Icons.Rounded.AutoAwesome, Icons.Rounded.Headphones, Icons.Rounded.FlashOn,
    Icons.Rounded.Waves, Icons.Rounded.Whatshot, Icons.Rounded.Favorite, Icons.Rounded.Nature,
    Icons.Rounded.Nightlife, Icons.Rounded.MusicNote, Icons.Rounded.Piano, Icons.Rounded.Star
)

@Composable
fun EqualizerOverlay(song: Song?, ui: PlayerUi) {
    BackHandler(EqUi.open) { EqUi.open = false }
    AnimatedVisibility(
        EqUi.open,
        enter = slideInVertically(tween(420)) { it } + fadeIn(tween(300)),
        exit = slideOutVertically(tween(320)) { it } + fadeOut(tween(260))
    ) {
        val pal = rememberCoverPalette(song, TM.Raised)
        val top by animateColorAsState(lerp(pal.bg, Color.Black, 0.25f), tween(800), label = "eq-top")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(top, TM.Ink)))) {
            LiquidBackdrop(pal)
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                EqMiniStrip(song, ui, pal)
                EqSheet(song, pal, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun EqMiniStrip(song: Song?, ui: PlayerUi, pal: CoverPalette) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Cover(song, Modifier.size(58.dp), 14.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "لا شيء يُشغَّل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "", color = Color.White.copy(0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(ui::togglePlay) {
                Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(30.dp), tint = Color.White)
            }
        }
        Spacer(Modifier.height(8.dp))
        val frac = if (ui.duration > 0) (ui.position.toFloat() / ui.duration).coerceIn(0f, 1f) else 0f
        Canvas(Modifier.fillMaxWidth().height(5.dp)) {
            val r = CornerRadius(size.height / 2, size.height / 2)
            drawRoundRect(Color.White.copy(alpha = 0.18f), size = size, cornerRadius = r)
            drawRoundRect(pal.accent, size = Size((size.width * frac).coerceAtLeast(size.height), size.height), cornerRadius = r)
        }
    }
}

@Composable
private fun EqSheet(song: Song?, pal: CoverPalette, modifier: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val art = song?.let { Art.peek(it) }
    val white = Color.White
    Column(
        modifier.fillMaxWidth()
            .glass(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp), tint = pal.accent, art = art, strength = 0.8f)
    ) {
        // مقبض: اضغط أو اسحب للأسفل للإغلاق
        var drag by remember { mutableFloatStateOf(0f) }
        Box(
            Modifier.fillMaxWidth().height(30.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { drag = 0f },
                        onVerticalDrag = { c, dy -> c.consume(); drag += dy },
                        onDragEnd = { if (drag > 60f) EqUi.open = false }
                    )
                }
                .clickable { EqUi.open = false },
            Alignment.Center
        ) { Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(white.copy(0.35f))) }

        // ---- الجزء الثابت: العنوان + مفتاح التشغيل + النطاقات العشرة ----
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("الإيكولايزر", color = white, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                    Text(Eq.presets.getOrNull(Eq.preset)?.name ?: "", color = white.copy(0.6f), fontSize = 13.sp)
                }
                GlassSwitch(Eq.enabled, { Eq.init(ctx); Eq.enable(it) })
            }
            if (!Eq.available) {
                Spacer(Modifier.height(8.dp))
                Text("المعالج لم يبدأ بعد. شغّل أغنية ثم افتح الإيكولايزر من جديد.", color = white.copy(0.65f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            // النطاقات العشرة (من الأخفض إلى الأعلى من اليسار لليمين دائمًا)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0 until 10) {
                        VBand(
                            Eq.vgains[i], Eq.vlabels[i], pal.accent, Eq.enabled && Eq.available,
                            { Eq.setBand(i, it) }, Modifier.weight(1f)
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // ---- الجزء القابل للتمرير: القوالب الجاهزة ثم التأثيرات ----
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 20.dp).padding(bottom = 24.dp)
        ) {
            Text("القوالب الجاهزة", color = white.copy(0.7f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
            Eq.presets.chunked(2).forEachIndexed { row, pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEachIndexed { c, p ->
                        val idx = row * 2 + c
                        PresetCard(p.name, presetIcons.getOrElse(idx) { Icons.Rounded.GraphicEq }, Eq.preset == idx, Modifier.weight(1f)) {
                            Eq.init(ctx); Eq.applyPreset(idx); if (!Eq.enabled) Eq.enable(true)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            val hasFx = Eq.bassOk || Eq.surroundOk || VolBoost.maxPercent > 100
            if (hasFx) {
                Spacer(Modifier.height(8.dp))
                Text("التأثيرات", color = white.copy(0.7f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(white.copy(0.06f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    val sl = SliderDefaults.colors(thumbColor = white, activeTrackColor = pal.accent, inactiveTrackColor = white.copy(0.18f))
                    if (Eq.bassOk) {
                        ExtraRow("تعزيز الباس", "${Eq.bass / 10}%")
                        Slider(Eq.bass / 1000f, { Eq.changeBass((it * 1000).roundToInt()) }, colors = sl)
                    }
                    if (Eq.surroundOk) {
                        ExtraRow("الصوت المحيطي", "${Eq.surround / 10}%")
                        Slider(Eq.surround / 1000f, { Eq.changeSurround((it * 1000).roundToInt()) }, colors = sl)
                    }
                    if (VolBoost.maxPercent > 100) {
                        ExtraRow("تعزيز مستوى الصوت", "${VolBoost.percent}%")
                        Slider(
                            (VolBoost.percent - 100) / 200f,
                            { VolBoost.set(100 + ((it * 200f) / 10f).roundToInt() * 10) },
                            colors = sl
                        )
                        if (VolBoost.percent > 150) {
                            Text("تنبيه: التعزيز العالي قد يشوّه الصوت ويرهق السمع.", color = Color(0xFFFFB74D), fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExtraRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(value, color = Color.White.copy(0.7f), fontSize = 13.sp)
    }
}

/** قالب جاهز بأسلوب مشغّلات الصوت الكبيرة: بطاقة بحافة رقيقة، والمختار يمتلئ بالأبيض. */
@Composable
private fun PresetCard(name: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val fg = if (selected) Color.Black else Color.White
    Column(
        modifier.height(78.dp).clip(shape)
            .background(if (selected) Color.White.copy(0.94f) else Color.White.copy(0.05f))
            .border(1.dp, if (selected) Color.Transparent else Color.White.copy(0.14f), shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = fg.copy(if (selected) 0.85f else 0.65f))
        Text(name, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * نطاق عمودي نظيف: القيمة بالديسيبل فوق، خط رفيع مع خط الصفر، وحبة صغيرة تنزلق عليه، واسم التردد تحت.
 * كل الأعمدة بنفس الارتفاع والمحاذاة فتبدو منظمة في صف واحد.
 */
@Composable
private fun VBand(db: Float, label: String, accent: Color, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier) {
    val haptic = LocalHapticFeedback.current
    val cb by rememberUpdatedState(onChange)
    var last by remember { mutableIntStateOf(db.roundToInt()) }
    val alpha = if (enabled) 1f else 0.4f
    val shown = db.roundToInt()
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            (if (shown > 0) "+" else "") + shown, color = Color.White.copy(if (shown != 0) 0.9f * alpha else 0.5f * alpha), fontSize = 11.sp,
            fontWeight = if (shown != 0) FontWeight.Bold else FontWeight.Normal, maxLines = 1
        )
        Spacer(Modifier.height(6.dp))
        Canvas(
            Modifier.fillMaxWidth().height(150.dp)
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    fun set(y: Float) {
                        val h = size.height.toFloat()
                        val v = ((h / 2f - y) / (h / 2f) * 12f).coerceIn(-12f, 12f).roundToInt()
                        if (v != last) { last = v; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                        cb(v.toFloat())
                    }
                    detectVerticalDragGestures(
                        onDragStart = { set(it.y) },
                        onVerticalDrag = { c, _ -> c.consume(); set(c.position.y) }
                    )
                }
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures {
                        val h = size.height.toFloat()
                        cb(((h / 2f - it.y) / (h / 2f) * 12f).coerceIn(-12f, 12f).roundToInt().toFloat())
                    }
                }
        ) {
            val cx = size.width / 2f
            val mid = size.height / 2f
            val y = mid - (db / 12f) * mid
            // خط الصفر وخط النطاق
            drawLine(Color.White.copy(alpha = 0.10f), Offset(2.dp.toPx(), mid), Offset(size.width - 2.dp.toPx(), mid), strokeWidth = 1.dp.toPx())
            drawLine(Color.White.copy(alpha = 0.16f), Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            // الجزء الملوّن بين الصفر والقيمة
            if (abs(db) > 0.4f) drawLine(accent.copy(alpha = alpha), Offset(cx, mid), Offset(cx, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
            // الحبة
            drawCircle(Color.Black.copy(alpha = 0.25f), 7.dp.toPx(), Offset(cx, y + 1.5.dp.toPx()))
            drawCircle(Color.White.copy(alpha = alpha), 6.dp.toPx(), Offset(cx, y))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White.copy(0.55f), fontSize = 10.sp, maxLines = 1)
    }
}
