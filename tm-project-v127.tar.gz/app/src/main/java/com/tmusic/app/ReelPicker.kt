package com.tmusic.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** موجة الأغنية كاملة (قمم الصوت) لعرضها في محدّد المقطع. */
object ReelWave {
    const val BINS = 160
    private val cache = HashMap<Long, FloatArray>()

    /** موجة تقريبية ثابتة (للأغاني من الإنترنت أو إن تعذّر الفكّ) تتغيّر حسب رقم الأغنية. */
    fun fake(seed: Long): FloatArray {
        val s = (seed % 17).toFloat()
        return FloatArray(BINS) { i ->
            (0.22f + 0.7f * abs(sin(i * 0.37f + s)) * (0.55f + 0.45f * sin(i * 0.11f + s * 0.5f))).coerceIn(0.08f, 1f)
        }
    }

    suspend fun load(ctx: Context, song: Song): FloatArray? = withContext(Dispatchers.Default) {
        if (song.remoteUrl != null) return@withContext null
        cache[song.id]?.let { return@withContext it }
        val r = runCatching { decodePeaks(ctx, song) }.getOrNull()
        if (r != null) cache[song.id] = r
        r
    }

    private fun decodePeaks(ctx: Context, song: Song): FloatArray? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, song.uri, null)
            var ti = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { ti = i; fmt = f; break }
            }
            if (ti < 0 || fmt == null) return null
            ex.selectTrack(ti)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else song.duration * 1000L
            if (durUs <= 0L) return null
            val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec.configure(fmt, null, null, 0)
            dec.start()
            val peaks = FloatArray(BINS)
            val info = MediaCodec.BufferInfo()
            var inEos = false
            var outEos = false
            var spins = 0
            try {
                while (!outEos && spins < 400_000) {
                    spins++
                    if (!inEos) {
                        val i = dec.dequeueInputBuffer(5_000L)
                        if (i >= 0) {
                            val b = dec.getInputBuffer(i)!!
                            val n = ex.readSampleData(b, 0)
                            if (n < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inEos = true }
                            else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 5_000L)
                    if (o >= 0) {
                        val b = dec.getOutputBuffer(o)
                        if (b != null && info.size > 0) {
                            b.position(info.offset); b.limit(info.offset + info.size)
                            val sb = b.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            var m = 0
                            var k = 0
                            val cnt = sb.remaining()
                            val base = sb.position()
                            while (k < cnt) {
                                val v = abs(sb.get(base + k).toInt())
                                if (v > m) m = v
                                k += 6
                            }
                            val bin = ((info.presentationTimeUs.toDouble() / durUs) * BINS).toInt().coerceIn(0, BINS - 1)
                            peaks[bin] = max(peaks[bin], m / 32768f)
                        }
                        dec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outEos = true
                    }
                }
            } finally {
                runCatching { dec.stop() }; runCatching { dec.release() }
            }
            var top = 0f
            for (p in peaks) if (p > top) top = p
            if (top <= 0f) return null
            return FloatArray(BINS) { sqrt(peaks[it] / top).coerceIn(0.06f, 1f) }
        } finally { runCatching { ex.release() } }
    }
}

/**
 * محدّد المقطع بالموجة: نافذة بحدّ أبيض فوق موجة الأغنية، اسحبها لتحديد بداية المقطع أو المس أي مكان لنقلها إليه.
 * عرض النافذة يتبع طول المقطع المختار.
 */
@Composable
fun WaveClipPicker(
    peaks: FloatArray, durationMs: Long, lenSec: Int,
    startFrac: Float, enabled: Boolean, onStart: (Float) -> Unit, modifier: Modifier = Modifier
) {
    val win = (lenSec * 1000f / max(durationMs, 1L)).coerceIn(0.02f, 1f)
    val curStart by rememberUpdatedState(startFrac)
    val curWin by rememberUpdatedState(win)
    val curOn by rememberUpdatedState(onStart)
    val curEnabled by rememberUpdatedState(enabled)

    Canvas(
        modifier.fillMaxWidth().height(96.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dx ->
                    val room = 1f - curWin
                    if (curEnabled && room > 0.001f) curOn((curStart + dx / (size.width * room)).coerceIn(0f, 1f))
                    change.consume()
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { p ->
                    val room = 1f - curWin
                    if (curEnabled && room > 0.001f) curOn(((p.x / size.width - curWin / 2f) / room).coerceIn(0f, 1f))
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val n = peaks.size
        val step = w / n
        val bw = step * 0.55f
        val left = curStart * (1f - curWin) * w
        val right = left + curWin * w
        for (i in 0 until n) {
            val x = i * step + (step - bw) / 2f
            val bh = 8.dp.toPx() + peaks[i] * (h - 20.dp.toPx())
            val inside = x + bw / 2f in left..right
            drawRoundRect(
                color = if (inside) Color.White else Color(0x66FFFFFF),
                topLeft = Offset(x, (h - bh) / 2f),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f, bw / 2f)
            )
        }
        // النافذة
        drawRoundRect(
            color = Color(0x22FFFFFF),
            topLeft = Offset(left, 2.dp.toPx()), size = Size(right - left, h - 4.dp.toPx()),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(left, 2.dp.toPx()), size = Size(right - left, h - 4.dp.toPx()),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
