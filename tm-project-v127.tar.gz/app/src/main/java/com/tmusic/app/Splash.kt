package com.tmusic.app

import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

private const val SPLASH_END = 6.3f

/** الافتتاح الكامل (6 ثوانٍ مع النغمة) مرة واحدة كل يوم، وفي بقية الفتحات نسخة قصيرة صامتة. */
object SplashPolicy {
    fun full(ctx: android.content.Context): Boolean {
        val p = ctx.applicationContext.getSharedPreferences("tm_splash", android.content.Context.MODE_PRIVATE)
        val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        p.edit().putString("day", today).apply()
        return true // الافتتاح الكامل بالنغمة في كل مرة (يتحكم بالصوت مفتاح الإعدادات)
    }
}
private fun spCl(v: Float) = v.coerceIn(0f, 1f)
private fun spEio(p: Float) = if (p < .5f) 4f * p * p * p else 1f - (-2f * p + 2f).pow(3) / 2f
private fun spEo(p: Float) = 1f - (1f - p).pow(3)

/** شاشة الافتتاح: لطخة بيضاء تُرسم، ثم يُكتب حرف T بالأسود، ثم الاسم، مع نغمة قصيرة. اضغط لتخطيها. */
@Composable
fun TMSplash(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val brush = ImageBitmap.imageResource(R.drawable.tm_brush)
    val text = ImageBitmap.imageResource(R.drawable.tm_text)
    val glyph = ImageBitmap.imageResource(R.drawable.tm_t)
    val white = remember { ColorFilter.tint(Color.White) }
    val black = remember { ColorFilter.tint(Color.Black) }
    val rnd = remember { java.util.Random(7) }
    val rb0 = remember { FloatArray(64) { rnd.nextFloat() } }
    val rb1 = remember { FloatArray(64) { rnd.nextFloat() } }
    val rs0 = remember { FloatArray(90) { rnd.nextFloat() } }
    val t = remember { Animatable(0f) }

    val full = remember { SplashPolicy.full(ctx) }
    LaunchedEffect(Unit) {
        t.animateTo(SPLASH_END, tween((SPLASH_END * 1000 / (if (full) 1f else 3.6f)).toInt(), easing = LinearEasing))
        onDone()
    }
    DisposableEffect(Unit) {
        val mp = if (!AppPrefs.introSound || !full) null else try {
            MediaPlayer.create(
                ctx, R.raw.tm_intro,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
        } catch (e: Exception) { null }
        try { mp?.start() } catch (e: Exception) {}
        onDispose { try { mp?.release() } catch (e: Exception) {} }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) { detectTapGestures { onDone() } }
    ) {
        Canvas(
            Modifier.fillMaxSize().graphicsLayer {
                val tt = t.value
                val out = spCl((tt - 5.8f) / .5f)
                val pun = if (tt > 3.2f && tt < 3.8f) sin((tt - 3.2f) / .6f * PI.toFloat()) * .035f else 0f
                val sh = if (tt > 3.25f && tt < 3.65f) sin(tt * 90f) * 5f * (1f - (tt - 3.25f) / .4f) * density else 0f
                val k = 1f + pun + out * .08f
                scaleX = k; scaleY = k; translationX = sh; alpha = 1f - out
            }
        ) {
            tmLogoDraw(t.value, brush, text, glyph, white, black, rb0, rb1, rs0)
        }
    }
}

/** يرسم شعار T-Music المكتوب بالفرشاة عند الزمن tt (بالثواني، 0..~4.9) داخل مساحة الرسم. */
internal fun DrawScope.tmLogoDraw(
    tt: Float, brush: ImageBitmap, text: ImageBitmap, glyph: ImageBitmap,
    white: ColorFilter, black: ColorFilter, rb0: FloatArray, rb1: FloatArray, rs0: FloatArray,
    fill: Float = .94f, heightFill: Float = .62f
) {
    val imgW = brush.width
    val imgH = brush.height
    val ar = imgH.toFloat() / imgW
    val dw = min(size.width * fill, size.height * heightFill / ar)
    val dh = dw * ar
    val ox = (size.width - dw) / 2f
    val oy = (size.height - dh) / 2f
    val sc = dw / imgW

    fun seg(img: ImageBitmap, sx: Int, sy: Int, sw: Int, sh: Int, f: ColorFilter, a: Float) {
        if (sw <= 0 || sh <= 0) return
        drawImage(
            img,
            srcOffset = IntOffset(sx, sy), srcSize = IntSize(sw, sh),
            dstOffset = IntOffset((ox + sx * sc).roundToInt(), (oy + sy * sc).roundToInt()),
            dstSize = IntSize((sw * sc).roundToInt() + 1, (sh * sc).roundToInt() + 1),
            alpha = a, colorFilter = f
        )
    }

    // 1) اللطخة البيضاء: سحب فرشاة بخطوط دقيقة
    val n = 64
    for (i in 0 until n) {
        val p = spEio(spCl((tt - .2f - rb0[i] * .45f) / 1.25f))
        val lim = p * dw * 1.5f - (i / n.toFloat()) * dw * .35f + rb1[i] * dw * .05f * (1f - p)
        if (lim <= 0f) continue
        val y0 = i * imgH / n
        val y1 = (i + 1) * imgH / n
        seg(brush, 0, y0, min((lim / sc).toInt(), imgW), y1 - y0, white, 1f)
    }
    // 2) كتابة حرف T بالأسود: الخط العلوي ثم الساق
    val top = (imgH * .18f).toInt()
    for (i in 0 until 50) {
        val p = spEo(spCl((tt - 2f - (i / 50f) * .55f - rs0[i] * .06f) / .3f))
        if (p <= 0f) continue
        val sx = i * imgW / 50
        val ex = (i + 1) * imgW / 50
        seg(glyph, sx, top, ex - sx, (imgH * .18f * p).toInt(), black, 1f)
    }
    for (j in 0 until 40) {
        val p = spEo(spCl((tt - 2.6f - (j / 40f) * .5f) / .25f))
        if (p <= 0f) continue
        val y0 = (imgH * (.36f + j / 40f * .32f)).toInt()
        val y1 = (imgH * (.36f + (j + 1) / 40f * .32f)).toInt()
        seg(glyph, 0, y0, imgW, y1 - y0, black, p)
    }
    // 3) كتابة الاسم والخط تحته من اليسار لليمين
    val ty = (imgH * .55f).toInt()
    for (i in 0 until 90) {
        val p = spEo(spCl((tt - 3.4f - (i / 90f) * .9f - rs0[i] * .08f) / .45f))
        if (p <= 0f) continue
        val sx = i * imgW / 90
        val ex = (i + 1) * imgW / 90
        seg(text, sx, ty, ex - sx, (imgH * .45f * p).toInt(), white, 1f)
    }
}
