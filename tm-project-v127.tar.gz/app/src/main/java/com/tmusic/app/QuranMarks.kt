package com.tmusic.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** آخر موضع قراءة + علامات مرجعية للآيات، تُحفظ على الجهاز. المفتاح "سورة:آية". */
object QuranMarks {
    var last by mutableStateOf<Pair<Int, Int>?>(null)
    val marks = mutableStateListOf<String>()
    /** آية يُراد الانتقال إليها عند فتح السورة التالية (0 = لا شيء). */
    var jump by mutableIntStateOf(0)

    private var inited = false
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("tm_quran_marks", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val p = sp(ctx)
        val s = p.getInt("ls", 0); val a = p.getInt("la", 0)
        if (s in 1..114 && a >= 0) last = Pair(s, a)
        marks.clear()
        marks.addAll((p.getString("marks", "") ?: "").split(",").filter { it.matches(Regex("\\d+:\\d+")) })
    }

    fun setLast(ctx: Context, surah: Int, ayah: Int) {
        if (surah !in 1..114) return
        last = Pair(surah, ayah.coerceAtLeast(0))
        sp(ctx).edit().putInt("ls", surah).putInt("la", ayah.coerceAtLeast(0)).apply()
    }

    fun key(surah: Int, ayah: Int) = "$surah:$ayah"
    fun has(surah: Int, ayah: Int) = marks.contains(key(surah, ayah))

    fun toggle(ctx: Context, surah: Int, ayah: Int): Boolean {
        val k = key(surah, ayah)
        val nowOn = if (marks.contains(k)) { marks.remove(k); false } else { marks.add(0, k); true }
        sp(ctx).edit().putString("marks", marks.joinToString(",")).apply()
        return nowOn
    }
}
