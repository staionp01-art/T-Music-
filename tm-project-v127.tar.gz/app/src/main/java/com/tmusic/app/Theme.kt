package com.tmusic.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object TM {
    /** 0 الافتراضي، 1 داكن عميق، 2 AMOLED أسود، 3 ألوان حسب الوقت */
    var mode by mutableIntStateOf(0)
    var vinyl by mutableStateOf(false)
    var fade by mutableStateOf(false)
    fun applyFade(v: Boolean) { fade = v; prefs?.edit()?.putBoolean("fade", v)?.apply() }
    fun applyVinyl(v: Boolean) { vinyl = v; prefs?.edit()?.putBoolean("vinyl", v)?.apply() }
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("tm_theme", Context.MODE_PRIVATE)
        mode = prefs!!.getInt("mode", 0)
        vinyl = prefs!!.getBoolean("vinyl", false)
        fade = prefs!!.getBoolean("fade", false)
    }
    fun applyMode(m: Int) { mode = m; prefs?.edit()?.putInt("mode", m)?.apply() }

    /** النمط الفعلي: في وضع الوقت: نهارًا افتراضي، مساءً عميق، ليلًا أسود. */
    private fun eff(): Int = if (mode != 3) mode else {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when { h in 6..16 -> 0; h in 17..21 -> 1; else -> 2 }
    }
    private fun hour() = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)

    // هوية «أورورا»: خلفية بنفسجية داكنة، طبقات زجاجية، تدرّج بنفسجي ← سماوي للتمييز.
    // لون إضافي ديناميكي يأتي من غلاف الأغنية. غيّر Signal/Blue لتغيير ألوان التطبيق كله.
    val Ink: Color get() = when (eff()) { 2 -> Color(0xFF000000); 1 -> Color(0xFF05040A); else -> Color(0xFF07060D) }
    val Surface: Color get() = when (eff()) { 2 -> Color(0xFF0B0A12); 1 -> Color(0xFF100E19); else -> Color(0xFF15131F) }
    val Raised: Color get() = when (eff()) { 2 -> Color(0xFF181625); 1 -> Color(0xFF1C1A2A); else -> Color(0xFF211E31) }
    val Deep: Color get() = when (eff()) { 2 -> Color(0xFF0B0A12); 1 -> Color(0xFF14121E); else -> Color(0xFF14121E) }
    val Signal = Color(0xFF8B5CF6)          // بنفسجي أورورا — اللون الأساسي للتطبيق
    val Violet: Color get() = Signal
    val VioletSoft: Color get() = Color(0xFFB69CFF)
    val Blue: Color get() = Color(0xFF22D3EE)   // سماوي: الطرف الثاني للتدرّج
    val Emerald = Color(0xFF34D399)
    val Gold = Color(0xFFFBBF24)
    val Text = Color(0xFFF5F3FF)
    val Muted = Color(0xFF9A96AE)
    val Separator = Color(0x29C4B5FD)
}

@Composable
fun TMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = TM.Violet, onPrimary = Color.White,
            background = TM.Ink, onBackground = TM.Text,
            surface = TM.Surface, onSurface = TM.Text,
            surfaceVariant = TM.Raised, onSurfaceVariant = TM.Muted
        ),
        typography = Typography(
            headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 32.sp),
            titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp),       // Title 2
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp),  // Headline
            bodyMedium = TextStyle(fontSize = 15.sp),                                     // Subheadline
            bodySmall = TextStyle(fontSize = 13.sp)                                       // Footnote
        ),
        shapes = androidx.compose.material3.Shapes(
            small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
            large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
            extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(32.dp)
        ),
        content = content
    )
}
