package com.tmusic.app

/**
 * إعداد ريلز T Music (الفيديوهات تُخزَّن في قناة تيليجرام عبر وسيط Cloudflare Worker).
 * بعد نشر الـWorker (انظر reels-server/README.md) ضع رابطه هنا، مثل:
 *   const val API_URL = "https://tm-reels.اسمك.workers.dev"
 */
object ReelsConfig {
    const val API_URL = ""
    val enabled: Boolean get() = API_URL.isNotBlank()
}
