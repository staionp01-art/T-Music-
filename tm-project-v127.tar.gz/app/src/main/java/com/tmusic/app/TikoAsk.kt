package com.tmusic.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private fun nrm(s: String): String = Quran.normalize(s).lowercase(Locale.ROOT)

/** أسئلة سريعة تظهر كأزرار في نافذة «اسأل تيكو». */
val tikoQuickQuestions = listOf("ماذا أسمع الآن؟", "كم أغنية عندي؟", "أكثر أغنية سمعتها؟", "من فنانك الأكثر؟", "اقترح لي أغنية", "هل يوجد تحديث؟", "احكِ لي نكتة")

/**
 * يجيب تيكو عن أسئلة المستخدم من بيانات مكتبته وحالة المشغّل، بلا إنترنت.
 * أمثلة: «شغّل <اسم أغنية أو فنان>»، «ماذا أسمع الآن»، «كم أغنية عندي»، «اقترح لي».
 */
fun tikoAnswer(raw: String, songs: List<Song>, albums: List<Album>, byId: Map<Long, Song>, ui: PlayerUi): String {
    val q = nrm(raw)
    if (q.isBlank()) return "اكتب سؤالك أو اختر من الأسئلة السريعة 🙂"
    fun has(vararg k: String) = k.any { q.contains(nrm(it)) }

    if (has("شغل", "شغلي", "play")) {
        val key = nrm(raw).replace("شغلي", "").replace("شغل", "").replace("play", "").trim()
        if (key.isEmpty()) return "ماذا تريدني أن أشغّل؟ قل مثلًا: شغّل اسم أغنية أو فنان"
        val bySong = songs.indexOfFirst { nrm(it.title).contains(key) }
        if (bySong >= 0) { ui.play(songs, bySong, false); return "حاضر! أشغّل لك «${songs[bySong].title}» ▶️" }
        val byArtist = songs.filter { nrm(it.artist).contains(key) }
        if (byArtist.isNotEmpty()) { ui.play(byArtist, 0, false); return "أشغّل لك أغاني ${byArtist.first().artist} (${byArtist.size}) 🎧" }
        return "لم أجد «$key» في مكتبتك، جرّب كتابة جزء آخر من الاسم"
    }
    val cur = byId[ui.currentId]
    return when {
        has("ماذا اسمع", "ايش اسمع", "الان", "الحالي", "ما هذه الاغنيه") ->
            if (cur != null) "الآن: «${cur.title}» لـ ${cur.artist}" + (if (ui.isPlaying) " 🎶" else " (متوقفة مؤقتًا)")
            else "لا شيء يعمل الآن. قل لي: شغّل أغنية معينة أو اضغط «فاجئني»"
        has("كم اغنيه", "عدد الاغاني", "كم عندي", "حجم المكتبه", "مكتبتي") -> {
            val hrs = songs.sumOf { it.duration } / 3_600_000.0
            "في مكتبتك ${songs.size} أغنية في ${albums.size} ألبوم، ومدتها نحو " + String.format(Locale.US, "%.1f", hrs) + " ساعة"
        }
        has("فنان", "مغني") -> {
            val best = songs.groupBy { it.artist }.maxByOrNull { it.value.size }
            if (best != null) "أكثر فنان في مكتبتك: ${best.key} (${best.value.size} أغنية)" else "مكتبتك فارغة حاليًا"
        }
        has("اكثر اغنيه", "الاكثر استماعا", "اكثر ما سمعت", "الاكثر") -> {
            val top = songs.maxByOrNull { ui.plays[it.id] ?: 0 }
            val n = if (top == null) 0 else (ui.plays[top.id] ?: 0)
            if (top != null && n > 0) "أكثر أغنية سمعتها: «${top.title}» ($n مرة) 🔁" else "لم أجمع سجلًا كافيًا بعد، اسمع أكثر وسأخبرك 😉"
        }
        has("اقترح", "اقتراح", "رشح", "اختر لي") -> {
            if (songs.isEmpty()) "مكتبتك فارغة، نزّل بعض الأغاني أولًا"
            else { val s = songs.random(); "جرّب «${s.title}» لـ ${s.artist}. قل «شغّل ${s.title}» وأشغّلها لك ✨" }
        }
        has("تحديث") -> if (Updater.available) "نعم، يوجد تحديث جديد جاهز. اضغط «حدّث الآن» في بطاقتي" else "تطبيقك محدّث، لا شيء جديد الآن ✅"
        has("نكته", "اضحكني") -> listOf(
            "لماذا لا يلعب الموزّع الموسيقي الغميضة؟ لأنه دائمًا يُسمَع قبل أن يُرى 😄",
            "قال البيانو للغيتار: أنت متوتر! قال: لا، أنا فقط مشدود الأوتار 🎸",
            "سألتُ السمّاعة عن حالها فقالت: أنا أسمعك جيدًا 🎧"
        ).random()
        has("القران", "قران", "تلاوه") -> "افتح تبويب T Quran من الأعلى، وهناك تجد السور والقرّاء 📖"
        has("من انت", "اسمك", "عرفني") -> "أنا تيكو، رفيقك في T Music. أعرف مكتبتك وأشغّل ما تطلب وأرقص مع الإيقاع 🎧"
        has("مساعده", "ماذا تستطيع", "ماذا تفعل", "help") -> "اسألني: ماذا أسمع الآن، كم أغنية عندي، أكثر أغنية سمعتها، اقترح لي، أو قل «شغّل …» وأشغّل لك"
        has("مرحبا", "اهلا", "هلا", "السلام") -> "أهلًا بك! أنا جاهز، ماذا نسمع اليوم؟ 👋"
        else -> {
            val found = songs.filter { nrm(it.title).contains(q) || nrm(it.artist).contains(q) }.take(4)
            if (found.isNotEmpty()) "وجدت: " + found.joinToString("، ") { "«${it.title}»" } + ". قل «شغّل …» وأشغّل لك"
            else "لم أفهم تمامًا 🤔 اكتب «مساعدة» لأخبرك بما أستطيع"
        }
    }
}

@Composable
fun TikoAskDialog(songs: List<Song>, albums: List<Album>, byId: Map<Long, Song>, ui: PlayerUi, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("اسألني عن مكتبتك، أو اطلب مني تشغيل شيء 🙂") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اسأل تيكو", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(a, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TM.Raised).padding(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tikoQuickQuestions) { s ->
                        Text(s, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(TM.Raised)
                            .clickable { a = tikoAnswer(s, songs, albums, byId, ui) }.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("اكتب سؤالك…") })
                    Button(onClick = { a = tikoAnswer(q, songs, albums, byId, ui); q = "" }) { Text("اسأل") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
