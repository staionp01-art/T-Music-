package com.tmusic.app

import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * شريط تمرير بتصميم T Music: خط ناعم بتدرّج لون الأغنية ومقبض دائري يتضخّم تحت الإصبع.
 * يُسحب بالإصبع في أي مكان ويستجيب للّمس المباشر. (يعمل بالاتجاه من اليسار لليمين دائمًا)
 */
@Composable
fun TmSlider(
    value: Float,
    accent: Color,
    modifier: Modifier = Modifier,
    onChange: (Float) -> Unit,
    onEnd: () -> Unit = {}
) {
    val change by rememberUpdatedState(onChange)
    val end by rememberUpdatedState(onEnd)
    var w by remember { mutableFloatStateOf(1f) }
    var down by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (down) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "tm-slider-grow")
    val pad = with(LocalDensity.current) { 12.dp.toPx() }
    val v = value.coerceIn(0f, 1f)

    fun frac(x: Float): Float = ((x - pad) / (w - 2f * pad).coerceAtLeast(1f)).coerceIn(0f, 1f)

    Canvas(
        modifier.height(48.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures(onPress = { o ->
                    down = true
                    change(frac(o.x))
                    tryAwaitRelease()
                    down = false
                    end()
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { down = true },
                    onDragEnd = { down = false; end() },
                    onDragCancel = { down = false; end() },
                    onHorizontalDrag = { c, _ -> c.consume(); change(frac(c.position.x)) }
                )
            }
    ) {
        // التصميم: قرص ممتلئ يسارًا، مقبض أبيض عمودي، فجوة، ثم مسار رمادي بنقطة في طرفه
        val barH = 28.dp.toPx()
        val big = barH / 2f
        val small = 4.dp.toPx()
        val hw = 6.dp.toPx() - 2.dp.toPx() * grow
        val handleH = 40.dp.toPx()
        val gap = 6.dp.toPx()
        val cy = size.height / 2f
        val x0 = pad
        val x1 = size.width - pad
        val hx = x0 + (x1 - x0) * v
        val leftEnd = hx - hw / 2f - gap
        val rightStart = hx + hw / 2f + gap
        val top = cy - barH / 2f

        if (leftEnd - x0 > 2f) {
            val path = Path().apply {
                addRoundRect(RoundRect(x0, top, leftEnd, top + barH, CornerRadius(big), CornerRadius(small), CornerRadius(small), CornerRadius(big)))
            }
            drawPath(path, accent)
        }
        if (x1 - rightStart > 2f) {
            val path = Path().apply {
                addRoundRect(RoundRect(rightStart, top, x1, top + barH, CornerRadius(small), CornerRadius(big), CornerRadius(big), CornerRadius(small)))
            }
            drawPath(path, Color.White.copy(alpha = 0.16f))
            if (x1 - rightStart > barH) drawCircle(accent, radius = 3.dp.toPx(), center = Offset(x1 - big, cy))
        }
        drawRoundRect(Color.White, Offset(hx - hw / 2f, cy - handleH / 2f), Size(hw, handleH), CornerRadius(hw / 2f))
    }
}

/** شريط التحكم بصوت الموسيقى داخل شاشة التشغيل (بدل أزرار الهاتف). يتزامن مع أزرار الهاتف أيضًا. */
@Composable
fun VolumeBar(accent: Color, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var v by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(dragging) {
        while (!dragging) { v = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max; delay(300) }
    }
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (v <= 0f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeDown, "الصوت", Modifier.size(22.dp), tint = Color.White.copy(0.75f))
        TmSlider(
            value = v, accent = accent, modifier = Modifier.weight(1f),
            onChange = { dragging = true; v = it; runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).roundToInt(), 0) } },
            onEnd = { dragging = false }
        )
        Icon(Icons.Rounded.VolumeUp, null, Modifier.size(22.dp), tint = Color.White.copy(0.75f))
    }
}
