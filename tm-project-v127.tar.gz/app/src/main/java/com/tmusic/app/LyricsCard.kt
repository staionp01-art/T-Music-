package com.tmusic.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** بطاقة كلمات بمقاس القصص (1080×1920): الأسطر التي اخترتها فوق خلفية من غلاف الأغنية. */
suspend fun shareLyricsCard(ctx: Context, song: Song, lines: List<String>) {
    val art = Art.get(ctx, song)
    val file = withContext(Dispatchers.Default) {
        val w = 1080; val h = 1920
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (art != null) {
            val small = Bitmap.createScaledBitmap(art, 24, 24, true)
            c.drawBitmap(small, null, RectF(-200f, 0f, w + 200f, h.toFloat()), p)
        } else {
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF3A2A7A.toInt(), 0xFF101028.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        }
        p.color = 0xAA000000.toInt(); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)

        // غلاف صغير في الأعلى
        val box = RectF(430f, 200f, 650f, 420f)
        if (art != null) {
            val clip = android.graphics.Path().apply { addRoundRect(box, 36f, 36f, android.graphics.Path.Direction.CW) }
            c.save(); c.clipPath(clip); c.drawBitmap(art, null, box, p); c.restore()
        } else { p.color = 0xFF2B1B55.toInt(); c.drawRoundRect(box, 36f, 36f, p) }

        // الكلمات: يُصغَّر الخط تلقائيًا حتى يتّسع النص
        val text = lines.joinToString("\n")
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; typeface = Typeface.DEFAULT_BOLD }
        val textW = 900
        var size = 72f
        fun build(sz: Float): StaticLayout {
            tp.textSize = sz
            return StaticLayout.Builder.obtain(text, 0, text.length, tp, textW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.3f).build()
        }
        var layout = build(size)
        while (layout.height > 960 && size > 34f) { size -= 4f; layout = build(size) }
        val top = 520f + (960f - layout.height.coerceAtMost(960)) / 2f
        c.save(); c.translate((w - textW) / 2f, top); layout.draw(c); c.restore()

        // العنوان والفنان
        val np = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; textSize = 54f }
        c.drawText(android.text.TextUtils.ellipsize(song.title, np, 880f, android.text.TextUtils.TruncateAt.END).toString(), w / 2f, 1640f, np)
        np.typeface = Typeface.DEFAULT; np.textSize = 40f; np.color = 0xCCFFFFFF.toInt()
        c.drawText(android.text.TextUtils.ellipsize(song.artist, np, 880f, android.text.TextUtils.TruncateAt.END).toString(), w / 2f, 1710f, np)
        np.color = 0xAAFFFFFF.toInt(); np.textSize = 36f; np.typeface = Typeface.DEFAULT_BOLD
        c.drawText("T Music", w / 2f, 1820f, np)

        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        File(dir, "lyrics.png").also { f -> f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }
    val uri = FileProvider.getUriForFile(ctx, "com.tmusic.app.files", file)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "مشاركة بطاقة الكلمات").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** اختر الأسطر التي تريدها (حتى 8) ثم شاركها كصورة. تُحدَّد تلقائيًا الأسطر القريبة من الموضع الحالي. */
@Composable
fun LyricsShareDialog(song: Song, lyrics: Lyrics, ui: PlayerUi, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lines = remember(lyrics) { lyrics.lines.map { it.text }.withIndex().filter { it.value.isNotBlank() && it.value != "♪" } }
    val picked = remember { mutableStateListOf<Int>() }
    LaunchedEffect(Unit) {
        val real = if (lyrics.synced) lyrics.lines.indexOfLast { it.timeMs <= ui.position + 250 } else 0
        val start = lines.indexOfFirst { it.index >= real }.coerceAtLeast(0)
        for (k in start until (start + 3).coerceAtMost(lines.size)) picked.add(lines[k].index)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بطاقة الكلمات") },
        text = {
            Column {
                Text("اختر حتى 8 أسطر", color = TM.Muted, fontSize = 12.sp)
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    itemsIndexed(lines) { _, l ->
                        val on = l.index in picked
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (on) picked.remove(l.index) else if (picked.size < 8) picked.add(l.index)
                            },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(on, null)
                            Spacer(Modifier.width(8.dp))
                            Text(l.value, fontSize = 14.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                val chosen = lines.filter { it.index in picked }.sortedBy { it.index }.map { it.value }
                if (chosen.isEmpty()) { Toast.makeText(ctx, "اختر سطرًا واحدًا على الأقل", Toast.LENGTH_SHORT).show(); return@TextButton }
                scope.launch { runCatching { shareLyricsCard(ctx, song, chosen) }; onDismiss() }
            }) { Text("مشاركة") }
        },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } }
    )
}
