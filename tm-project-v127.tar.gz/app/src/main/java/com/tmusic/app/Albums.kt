package com.tmusic.app

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** المشغّل الحالي، لتصل إليه قائمة الضغط المستمر من أي شاشة. */
var activeUi: PlayerUi? = null

// ===================== ألبومات المستخدم =====================
class UAlbum(val id: Long, name: String, ids: List<Long>) {
    var name by mutableStateOf(name)
    val songIds = mutableStateListOf<Long>().apply { addAll(ids) }
}

object UserAlbums {
    val list = mutableStateListOf<UAlbum>()
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences("tm_albums", Context.MODE_PRIVATE)
        runCatching {
            val a = JSONArray(prefs!!.getString("albums", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val ids = o.getJSONArray("ids")
                list.add(UAlbum(o.getLong("id"), o.getString("name"), (0 until ids.length()).map { ids.getLong(it) }))
            }
        }
    }

    private fun save() {
        val a = JSONArray()
        list.forEach { al -> a.put(JSONObject().put("id", al.id).put("name", al.name).put("ids", JSONArray(al.songIds.toList()))) }
        prefs?.edit()?.putString("albums", a.toString())?.apply()
    }

    fun create(name: String, firstSong: Long? = null): UAlbum {
        val al = UAlbum(System.currentTimeMillis(), name.trim().ifBlank { "ألبوم جديد" }, listOfNotNull(firstSong))
        list.add(0, al); save(); return al
    }
    fun rename(al: UAlbum, n: String) { al.name = n.trim().ifBlank { al.name }; save() }
    fun delete(al: UAlbum) { list.remove(al); save() }
    fun add(al: UAlbum, id: Long) { if (id !in al.songIds) { al.songIds.add(id); save() } }
    fun remove(al: UAlbum, id: Long) { al.songIds.remove(id); save() }
    fun move(al: UAlbum, from: Int, to: Int) {
        if (from == to || from !in al.songIds.indices || to !in al.songIds.indices) return
        al.songIds.add(to, al.songIds.removeAt(from)); save()
    }
    fun purge(id: Long) { list.forEach { it.songIds.remove(id) }; save() }
}

// ===================== حذف أغنية من الهاتف =====================
private fun deleteLocal(ctx: Context, s: Song, launch: (IntentSender) -> Unit, done: () -> Unit) {
    try {
        if (ctx.contentResolver.delete(s.uri, null, null) > 0) done()
        else android.widget.Toast.makeText(ctx, "تعذّر حذف الملف", android.widget.Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        when {
            Build.VERSION.SDK_INT >= 30 -> launch(MediaStore.createDeleteRequest(ctx.contentResolver, listOf(s.uri)).intentSender)
            Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException -> launch(e.userAction.actionIntent.intentSender)
            else -> android.widget.Toast.makeText(ctx, "لا توجد صلاحية لحذف هذا الملف", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}

// ===================== نقر + ضغط مستمر =====================
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.bounceCombined(scaleDown: Float = 0.97f, onLongClick: () -> Unit, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) scaleDown else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press2")
    return this.graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLongClick)
}

// ===================== قائمة خيارات الأغنية =====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongMenuSheet(song: Song, inAlbum: UAlbum?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val local = song.remoteUrl == null
    val scope = rememberCoroutineScope()
    var page by remember { mutableIntStateOf(0) }   // 0 القائمة، 1 اختيار ألبوم، 2 معلومات، 3 تأكيد الحذف
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    fun toast(t: String) = android.widget.Toast.makeText(ctx, t, android.widget.Toast.LENGTH_SHORT).show()
    fun deleted() { UserAlbums.purge(song.id); Mp3Dl.refreshLibrary(); toast("حُذفت الأغنية"); onDismiss() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            if (Build.VERSION.SDK_INT >= 30) deleted()
            else deleteLocal(ctx, song, { }, ::deleted)
        }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(song, Modifier.size(52.dp), 10.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = TM.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Color.White.copy(0.08f))
            when (page) {
                0 -> {
                    val fav = Favorites.has(song.id)
                    MenuRow(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (fav) "إزالة من المفضلة" else "إضافة إلى المفضلة") {
                        val added = Favorites.toggle(song); toast(if (added) "أُضيفت إلى المفضلة" else "أُزيلت من المفضلة"); onDismiss()
                    }
                    MenuRow(Icons.Rounded.SkipNext, "تشغيل التالي") { activeUi?.playNext(song); toast("سيُشغَّل بعد الأغنية الحالية"); onDismiss() }
                    MenuRow(Icons.Rounded.QueueMusic, "إضافة إلى قائمة التشغيل") { activeUi?.addToQueue(song); toast("أُضيفت إلى القائمة"); onDismiss() }
                    if (local) MenuRow(Icons.Rounded.PlaylistAdd, "إضافة إلى ألبوم") { page = 1 }
                    MenuRow(Icons.Rounded.AutoAwesome, "مشاركة بطاقة الأغنية") { scope.launch { shareSongCard(ctx, song) }; onDismiss() }
                    MenuRow(Icons.Rounded.Movie, "نشر ريلز بالأغنية") { ReelUi.open(song); onDismiss() }
                    if (inAlbum != null) MenuRow(Icons.Rounded.RemoveCircleOutline, "إزالة من هذا الألبوم") { UserAlbums.remove(inAlbum, song.id); onDismiss() }
                    if (!local && song.downloadUrl != null) MenuRow(Icons.Rounded.Download, "تنزيل الأغنية") { downloadSong(ctx, song); onDismiss() }
                    if (local) {
                        MenuRow(Icons.Rounded.Share, "مشاركة") {
                            val i = Intent(Intent.ACTION_SEND).apply { type = "audio/*"; putExtra(Intent.EXTRA_STREAM, song.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                            ctx.startActivity(Intent.createChooser(i, "مشاركة الأغنية"))
                            onDismiss()
                        }
                        MenuRow(Icons.Rounded.Info, "معلومات الأغنية") { page = 2 }
                        MenuRow(Icons.Rounded.DeleteOutline, "حذف الأغنية", Color(0xFFFF6B8A)) { page = 3 }
                    }
                }
                1 -> {
                    var newName by remember { mutableStateOf("") }
                    Text("اختر ألبومًا", Modifier.padding(horizontal = 20.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("اسم ألبوم جديد") })
                        Spacer(Modifier.width(8.dp))
                        FilledTonalButton({
                            val a = UserAlbums.create(newName.ifBlank { "ألبوم جديد" }, song.id)
                            toast("أُنشئ «${a.name}» وأُضيفت إليه الأغنية"); onDismiss()
                        }) { Text("إنشاء") }
                    }
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(UserAlbums.list, key = { it.id }) { a ->
                            val has = song.id in a.songIds
                            MenuRow(if (has) Icons.Rounded.CheckCircle else Icons.Rounded.LibraryMusic, a.name + "  ·  ${a.songIds.size}") {
                                UserAlbums.add(a, song.id); toast("أُضيفت إلى «${a.name}»"); onDismiss()
                            }
                        }
                    }
                }
                2 -> {
                    var name = ""; var size = 0L
                    runCatching {
                        ctx.contentResolver.query(song.uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use {
                            if (it.moveToFirst()) { name = it.getString(0) ?: ""; size = it.getLong(1) }
                        }
                    }
                    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoLine("العنوان", song.title); InfoLine("الفنان", song.artist)
                        if (song.album.isNotBlank()) InfoLine("الألبوم", song.album)
                        InfoLine("المدة", fmt(song.duration))
                        if (name.isNotBlank()) InfoLine("الملف", name)
                        if (size > 0) InfoLine("الحجم", String.format(java.util.Locale.US, "%.1f MB", size / 1_048_576f))
                        TextButton({ page = 0 }) { Text("رجوع") }
                    }
                }
                else -> Column(Modifier.padding(horizontal = 20.dp)) {
                    Text("حذف «${song.title}» من هاتفك نهائيًا؟", fontWeight = FontWeight.SemiBold)
                    Text("لا يمكن التراجع عن هذا الإجراء.", color = TM.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button({ deleteLocal(ctx, song, { launcher.launch(IntentSenderRequest.Builder(it).build()) }, ::deleted) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5486B), contentColor = Color.White), modifier = Modifier.weight(1f)) { Text("حذف") }
                        OutlinedButton({ page = 0 }, Modifier.weight(1f)) { Text("إلغاء") }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoLine(k: String, v: String) {
    Row { Text(k, color = TM.Muted, modifier = Modifier.width(80.dp)); Text(v, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun MenuRow(icon: ImageVector, text: String, tint: Color = TM.Text, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (tint == TM.Text) TM.VioletSoft else tint)
        Spacer(Modifier.width(16.dp))
        Text(text, color = tint, fontWeight = FontWeight.Medium)
    }
}

// ===================== واجهة «ألبوماتي» =====================
@Composable
private fun NameDialog(title: String, initial: String, ok: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = TM.Surface,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, placeholder = { Text("اسم الألبوم") }) },
        confirmButton = { TextButton({ onOk(v) }) { Text(ok, color = TM.VioletSoft) } },
        dismissButton = { TextButton(onCancel) { Text("إلغاء") } }
    )
}

@Composable
fun MyAlbums(byId: Map<Long, Song>, ui: PlayerUi) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { UserAlbums.init(ctx) }
    var openId by remember { mutableStateOf<Long?>(null) }
    var creating by remember { mutableStateOf(false) }
    val open = UserAlbums.list.firstOrNull { it.id == openId }
    if (creating) NameDialog("ألبوم جديد", "", "إنشاء", { UserAlbums.create(it).also { a -> openId = a.id }; creating = false }, { creating = false })
    if (open != null) { AlbumDetail(open, byId, ui, onBack = { openId = null }, onDeleted = { openId = null }); return }
    LazyVerticalGrid(
        GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "new") {
            Column(Modifier.bounceClick(0.96f) { creating = true }.clip(RoundedCornerShape(14.dp))) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(TM.Violet.copy(0.18f), TM.Blue.copy(0.12f)))),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Add, null, Modifier.size(44.dp), tint = Color.White) }
                Text("ألبوم جديد", Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("سمِّه وأضف أغانيك", fontSize = 12.sp, color = TM.Muted)
            }
        }
        items(UserAlbums.list, key = { it.id }) { a ->
            val first = a.songIds.firstNotNullOfOrNull { byId[it] }
            val hue = abs(a.id * 37 % 360).toFloat()
            Column(Modifier.bounceClick(0.96f) { openId = a.id }.clip(RoundedCornerShape(14.dp))) {
                if (first != null) Cover(first, Modifier.fillMaxWidth().aspectRatio(1f), 14.dp)
                else Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Color.hsv(hue, 0.5f, 0.5f), Color.hsv((hue + 40) % 360, 0.6f, 0.22f)))),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(40.dp), tint = Color.White.copy(0.6f)) }
                Text(a.name, Modifier.padding(top = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("${a.songIds.size} أغنية", fontSize = 12.sp, color = TM.Muted)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlbumDetail(a: UAlbum, byId: Map<Long, Song>, ui: PlayerUi, onBack: () -> Unit, onDeleted: () -> Unit) {
    val songs = a.songIds.mapNotNull { byId[it] }
    var rename by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    if (rename) NameDialog("إعادة تسمية الألبوم", a.name, "حفظ", { UserAlbums.rename(a, it); rename = false }, { rename = false })
    if (confirmDel) AlertDialog(
        onDismissRequest = { confirmDel = false }, containerColor = TM.Surface,
        title = { Text("حذف الألبوم؟") }, text = { Text("سيُحذف الألبوم فقط، وتبقى أغانيك على هاتفك.", color = TM.Muted) },
        confirmButton = { TextButton({ UserAlbums.delete(a); confirmDel = false; onDeleted() }) { Text("حذف", color = Color(0xFFFF6B8A)) } },
        dismissButton = { TextButton({ confirmDel = false }) { Text("إلغاء") } }
    )
    if (adding) AddSongsSheet(a, byId.values.sortedBy { it.title.lowercase() }) { adding = false }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text(a.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${songs.size} أغنية", color = TM.Muted, fontSize = 12.sp)
            }
            Box {
                IconButton({ more = true }) { Icon(Icons.Rounded.MoreVert, null) }
                DropdownMenu(more, { more = false }) {
                    DropdownMenuItem({ Text("إعادة تسمية") }, { more = false; rename = true }, leadingIcon = { Icon(Icons.Rounded.Edit, null) })
                    DropdownMenuItem({ Text("حذف الألبوم", color = Color(0xFFFF6B8A)) }, { more = false; confirmDel = true }, leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null, tint = Color(0xFFFF6B8A)) })
                }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ ui.play(songs, 0, false) }, enabled = songs.isNotEmpty()) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("تشغيل") }
            FilledTonalButton({ ui.play(songs, 0, true) }, enabled = songs.isNotEmpty()) { Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("عشوائي") }
            FilledTonalButton({ adding = true }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة أغانٍ") }
        }
        if (songs.isEmpty()) EmptyState(Icons.Rounded.LibraryMusic, "الألبوم فارغ", "اضغط «إضافة أغانٍ» لتختار منها، أو اضغط مطوّلًا على أي أغنية واختر «إضافة إلى ألبوم».")
        else EditableSongList(songs, ui, a)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddSongsSheet(a: UAlbum, all: List<Song>, onDone: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val shown = remember(q, all) { if (q.isBlank()) all else all.filter { it.title.contains(q, true) || it.artist.contains(q, true) } }
    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.85f)) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("ابحث في أغانيك") }, leadingIcon = { Icon(Icons.Rounded.Search, null) })
                Spacer(Modifier.width(8.dp))
                Button(onDone) { Text("تم (${a.songIds.size})") }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(shown, key = { it.id }) { s ->
                    val on = s.id in a.songIds
                    Row(
                        Modifier.fillMaxWidth().clickable { if (on) UserAlbums.remove(a, s.id) else UserAlbums.add(a, s.id) }.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Cover(s, Modifier.size(44.dp), 8.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = TM.Muted, fontSize = 12.sp)
                        }
                        Checkbox(on, { if (it) UserAlbums.add(a, s.id) else UserAlbums.remove(a, s.id) })
                    }
                }
            }
        }
    }
}
