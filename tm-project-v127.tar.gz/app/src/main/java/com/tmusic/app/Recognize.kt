package com.tmusic.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class RecResult(val title: String, val artist: String, val album: String)

/**
 * التعرّف على أغنية من الميكروفون: يسجّل 10 ثوانٍ ويرسلها إلى خدمة AudD (تحتاج مفتاحًا مجانيًا من audd.io).
 * ليس تعرّفًا محليًا: بصمة الأغاني تحتاج قاعدة بيانات ضخمة لا تُوضع داخل التطبيق.
 */
object SongRec {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("tm_settings", Context.MODE_PRIVATE)
    fun token(ctx: Context): String = prefs(ctx).getString("audd_token", "") ?: ""
    fun saveToken(ctx: Context, t: String) { prefs(ctx).edit().putString("audd_token", t.trim()).apply() }

    private suspend fun record(ctx: Context, seconds: Int): File = withContext(Dispatchers.IO) {
        val f = File(ctx.cacheDir, "rec.m4a").also { it.delete() }
        @Suppress("DEPRECATION")
        val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(44100)
            mr.setAudioEncodingBitRate(96000)
            mr.setOutputFile(f.absolutePath)
            mr.prepare(); mr.start()
            delay(seconds * 1000L)
            runCatching { mr.stop() }
        } finally { runCatching { mr.release() } }
        f
    }

    private fun upload(token: String, file: File): RecResult? {
        val boundary = "----tm" + System.currentTimeMillis()
        val c = URL("https://api.audd.io/").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.outputStream.use { out ->
                fun text(name: String, v: String) {
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$v\r\n".toByteArray())
                }
                text("api_token", token)
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"rec.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n".toByteArray())
                file.inputStream().use { it.copyTo(out) }
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }
            if (c.responseCode != 200) return null
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val r = j.optJSONObject("result") ?: return null
            return RecResult(r.optString("title"), r.optString("artist"), r.optString("album"))
        } finally { c.disconnect() }
    }

    /** يرجع null إن لم يتعرّف، ويرمي استثناءً عند فشل الشبكة. */
    suspend fun identify(ctx: Context): RecResult? {
        val t = token(ctx)
        val f = record(ctx, 10)
        return withContext(Dispatchers.IO) { upload(t, f) }
    }
}

@Composable
fun RecognizeDialog(songs: List<Song>, ui: PlayerUi, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(SongRec.token(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<RecResult?>(null) }
    var msg by remember { mutableStateOf("") }

    fun go() {
        busy = true; result = null; msg = "أستمع الآن… 10 ثوانٍ (أوقفتُ التشغيل مؤقتًا)"
        ui.controller?.pause()
        scope.launch {
            try {
                val r = SongRec.identify(ctx)
                result = r
                msg = if (r == null) "لم أتعرّف على الأغنية. قرّب الهاتف من المصدر وأعد المحاولة." else ""
            } catch (e: Exception) {
                msg = "تعذّر التعرّف: تحقق من الإنترنت ومن المفتاح"
            }
            busy = false
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) go() else Toast.makeText(ctx, "يلزم إذن الميكروفون", Toast.LENGTH_SHORT).show()
    }
    fun start() {
        if (token.isBlank()) { msg = "أدخل مفتاح AudD أولًا"; return }
        SongRec.saveToken(ctx, token)
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("تعرّف على أغنية") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val r = result
                if (r != null) {
                    Text(r.title, fontSize = 20.sp, color = TM.VioletSoft)
                    Text(r.artist + if (r.album.isNotBlank()) " · ${r.album}" else "", color = TM.Muted)
                    val a = r.title.lowercase().filter { it.isLetterOrDigit() }
                    val mine = songs.firstOrNull { s ->
                        val b = s.title.lowercase().filter { it.isLetterOrDigit() }
                        a.length > 2 && b.length > 2 && (b.contains(a) || a.contains(b))
                    }
                    if (mine != null) TextButton({ ui.play(listOf(mine), 0); onDismiss() }) { Text("شغّلها من مكتبتي") }
                    TextButton({
                        val q = Uri.encode("${r.title} ${r.artist}")
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text("ابحث عنها في يوتيوب") }
                } else {
                    Text("اضغط «استمع» وقرّب الهاتف من مصدر الموسيقى.", color = TM.Muted, fontSize = 13.sp)
                    OutlinedTextField(
                        token, { token = it }, singleLine = true, enabled = !busy,
                        label = { Text("مفتاح AudD (من audd.io)") }
                    )
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotBlank()) Text(msg, color = TM.Gold, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton({ start() }, enabled = !busy) { Text(if (result == null) "استمع" else "من جديد") } },
        dismissButton = { TextButton(onDismiss, enabled = !busy) { Text("إغلاق") } }
    )
}
