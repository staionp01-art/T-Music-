package com.tmusic.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max

/**
 * تجهيز غلاف الأغنية لقوالب الريلز: يقصّ الأشرطة الجانبية/العلوية (غلاف مركزي حوله خلفية مموّهة أو داكنة)
 * ثم يُرسم بملء الإطار كاملًا بدل ترك أشرطة فارغة على الجانبين.
 */
object ReelArt {
    private var lastIn: Bitmap? = null
    private var lastOut: Bitmap? = null

    fun trimmed(art: Bitmap): Bitmap {
        if (art === lastIn) lastOut?.let { return it }
        val out = runCatching { doTrim(art) }.getOrDefault(art)
        lastIn = art; lastOut = out
        return out
    }

    private fun doTrim(art: Bitmap): Bitmap {
        val w = art.width; val h = art.height
        if (w < 32 || h < 32) return art
        val n = 160
        val s = Bitmap.createScaledBitmap(art, n, n, true)
        val px = IntArray(n * n)
        s.getPixels(px, 0, n, 0, 0, n, n)
        if (s !== art) s.recycle()
        val g = FloatArray(n * n) { val p = px[it]; 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p) }
        // قوة الحافة: عمودية لكل عمود وأفقية لكل صف
        val col = FloatArray(n)
        val row = FloatArray(n)
        for (x in 1 until n) { var a = 0f; for (y in 0 until n) a += abs(g[y * n + x] - g[y * n + x - 1]); col[x] = a / n }
        for (y in 1 until n) { var a = 0f; for (x in 0 until n) a += abs(g[y * n + x] - g[(y - 1) * n + x]); row[y] = a / n }
        val cx = bars(col, n)
        val cy = bars(row, n)
        val x0 = (cx?.first ?: 0) * w / n
        val x1 = (cx?.second ?: n) * w / n
        val y0 = (cy?.first ?: 0) * h / n
        val y1 = (cy?.second ?: n) * h / n
        if (cx == null && cy == null) return art
        val cw = x1 - x0; val ch = y1 - y0
        if (cw < w / 4 || ch < h / 4) return art
        return Bitmap.createBitmap(art, x0, y0, cw, ch)
    }

    /** يبحث عن حافتين حادّتين متماثلتين تقريبًا تحيطان بمحتوى، وخلفهما منطقة هادئة (شريط). */
    private fun bars(e: FloatArray, n: Int): Pair<Int, Int>? {
        val sorted = e.copyOfRange(1, n).sorted()
        val med = sorted[sorted.size / 2]
        val thr = max(9f, med * 2.2f)
        var lx = -1; var lv = 0f
        for (x in 3..(n * 42 / 100)) if (e[x] > lv) { lv = e[x]; lx = x }
        var rx = -1; var rv = 0f
        for (x in (n * 58 / 100)..(n - 3)) if (e[x] > rv) { rv = e[x]; rx = x }
        if (lx < 0 || rx < 0 || lv < thr || rv < thr) return null
        var ls = 0f; for (x in 1 until lx) ls += e[x]; ls /= (lx - 1)
        var rs = 0f; for (x in (rx + 1) until n) rs += e[x]; rs /= max(1, n - 1 - rx)
        if (lv < ls * 2.5f || rv < rs * 2.5f) return null
        val lw = lx; val rw = n - rx
        if (lw < n * 4 / 100 && rw < n * 4 / 100) return null
        if (abs(lw - rw) > n * 22 / 100) return null
        return Pair(lx, rx)
    }
}

/** مستطيل المصدر لرسم الصورة بملء الإطار (قص من الوسط بدل تمدّد أو أشرطة). */
internal fun coverCrop(art: Bitmap, dst: RectF): Rect {
    val da = dst.width() / dst.height()
    val sa = art.width.toFloat() / art.height
    return if (sa > da) {
        val nw = (art.height * da).toInt().coerceIn(1, art.width)
        val x = (art.width - nw) / 2
        Rect(x, 0, x + nw, art.height)
    } else {
        val nh = (art.width / da).toInt().coerceIn(1, art.height)
        val y = (art.height - nh) / 2
        Rect(0, y, art.width, y + nh)
    }
}
