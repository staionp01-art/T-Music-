package com.tmusic.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * وضع التركيز/الدراسة: يشغّل قائمة من اختيارك بترتيب عشوائي لمدة محددة، ويكتم الإشعارات (وضع «المهم فقط»)
 * إن منحتَ التطبيق إذن «عدم الإزعاج». عند انتهاء المدة يتوقف التشغيل وتعود إعدادات الإشعارات كما كانت.
 */
object FocusMode {
    var endAt by mutableLongStateOf(0L)
        private set
    private var prevFilter = -1
    private val handler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null

    val active: Boolean get() = endAt > 0L

    fun hasDndAccess(ctx: Context): Boolean =
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted

    fun openDndSettings(ctx: Context) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    /** source: 0 المفضلة، 1 المشغّلة مؤخرًا، 2 كل المكتبة */
    fun start(ctx: Context, ui: PlayerUi, songs: List<Song>, byId: Map<Long, Song>, minutes: Int, source: Int): Boolean {
        val app = ctx.applicationContext
        val pool = when (source) {
            0 -> Favorites.songs(byId).filter { it.remoteUrl == null }
            1 -> ui.recents.mapNotNull { byId[it] }
            else -> songs
        }.ifEmpty { songs }
        if (pool.isEmpty()) return false
        ui.play(pool.shuffled(), 0, true)
        if (hasDndAccess(app)) {
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (prevFilter < 0) prevFilter = nm.currentInterruptionFilter
            runCatching { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY) }
        }
        stopRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable { stop(app, ui, finished = true) }
        stopRunnable = r
        endAt = System.currentTimeMillis() + minutes * 60_000L
        handler.postDelayed(r, minutes * 60_000L)
        return true
    }

    fun stop(ctx: Context, ui: PlayerUi?, finished: Boolean = false) {
        stopRunnable?.let { handler.removeCallbacks(it) }
        stopRunnable = null
        endAt = 0L
        val app = ctx.applicationContext
        if (prevFilter >= 0 && hasDndAccess(app)) {
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            runCatching { nm.setInterruptionFilter(prevFilter) }
        }
        prevFilter = -1
        if (finished) {
            ui?.controller?.pause()
            Toast.makeText(app, "انتهت جلسة التركيز 👏", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun FocusDialog(ui: PlayerUi, songs: List<Song>, byId: Map<Long, Song>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var minutes by remember { mutableIntStateOf(45) }
    var source by remember { mutableIntStateOf(if (Favorites.ids.isNotEmpty()) 0 else 2) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(FocusMode.endAt) { while (FocusMode.active) { now = System.currentTimeMillis(); delay(1000) } }
    val dnd = FocusMode.hasDndAccess(ctx)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("وضع التركيز / الدراسة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (FocusMode.active) {
                    val rem = ((FocusMode.endAt - now) / 60_000L).coerceAtLeast(0L) + 1
                    Text("الجلسة تعمل · المتبقي نحو $rem دقيقة", color = TM.VioletSoft)
                } else {
                    Text("المدة", color = TM.Muted, fontSize = 13.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(25, 45, 60, 90, 120).forEach { m -> FilterChip(minutes == m, { minutes = m }, label = { Text("$m د") }) }
                    }
                    Text("الموسيقى من", color = TM.Muted, fontSize = 13.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(source == 0, { source = 0 }, label = { Text("المفضلة") })
                        FilterChip(source == 1, { source = 1 }, label = { Text("المشغّلة مؤخرًا") })
                        FilterChip(source == 2, { source = 2 }, label = { Text("كل المكتبة") })
                    }
                    Text("اختر قائمة هادئة تعرفها أنت؛ التطبيق لا يستطيع الحكم على هدوء الأغنية من صوتها.", color = TM.Muted, fontSize = 11.sp)
                }
                if (dnd) Text("كتم الإشعارات: مفعّل (المهم فقط)", color = TM.Emerald, fontSize = 12.sp)
                else TextButton({ FocusMode.openDndSettings(ctx) }) { Text("امنح إذن «عدم الإزعاج» لكتم الإشعارات") }
            }
        },
        confirmButton = {
            if (FocusMode.active) TextButton({ FocusMode.stop(ctx, ui); onDismiss() }) { Text("إنهاء الجلسة") }
            else TextButton({
                if (FocusMode.start(ctx, ui, songs, byId, minutes, source)) onDismiss()
                else Toast.makeText(ctx, "لا توجد أغانٍ لتشغيلها", Toast.LENGTH_SHORT).show()
            }) { Text("ابدأ") }
        },
        dismissButton = { TextButton(onDismiss) { Text("إغلاق") } }
    )
}
