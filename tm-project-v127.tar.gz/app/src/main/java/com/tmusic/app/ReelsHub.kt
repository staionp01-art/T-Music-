package com.tmusic.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class PubReel(
    val id: String, val fileId: String, val thumbId: String, val caption: String,
    val song: String, val artist: String, val author: String, val uid: String,
    val at: Long, val likes: Long, val reports: Long
)

private suspend fun <T> Task<T>.awaitT(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
}

/**
 * ريلز T Music: الفيديو يُرفع إلى قناة تيليجرام عبر الوسيط (Cloudflare Worker) ولا يوجد توكن داخل التطبيق،
 * والقائمة والإعجابات والإبلاغات في Firestore (مجموعة tm_reels).
 */
object ReelsHub {
    var open by mutableStateOf(false)
    var items by mutableStateOf<List<PubReel>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf("")
        private set
    val liked = mutableStateListOf<String>()
    private const val COL = "tm_reels"
    private var inited = false

    fun url(fileId: String) = ReelsConfig.API_URL.trimEnd('/') + "/f/" + fileId

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val sp = ctx.applicationContext.getSharedPreferences("tm_reels_local", Context.MODE_PRIVATE)
        liked.addAll(sp.getStringSet("liked", emptySet()) ?: emptySet())
    }

    suspend fun refresh(ctx: Context) {
        if (!ReelsConfig.enabled) return
        if (!Cloud.ready(ctx)) { error = "خدمة الحساب (Firebase) غير مفعّلة في هذه النسخة"; return }
        loading = true; error = ""
        try {
            val snap = FirebaseFirestore.getInstance().collection(COL)
                .orderBy("at", Query.Direction.DESCENDING).limit(40).get().awaitT()
            items = snap.documents.mapNotNull { d ->
                val f = d.getString("fileId") ?: return@mapNotNull null
                PubReel(
                    d.id, f, d.getString("thumbId") ?: "", d.getString("caption") ?: "",
                    d.getString("song") ?: "", d.getString("artist") ?: "", d.getString("author") ?: "",
                    d.getString("uid") ?: "", d.getLong("at") ?: 0L, d.getLong("likes") ?: 0L, d.getLong("reports") ?: 0L
                )
            }.filter { it.reports < 3 }
        } catch (e: Exception) { error = "تعذّر التحميل: ${e.message ?: ""}" }
        loading = false
    }

    private fun upload(token: String, file: File, caption: String): JSONObject? {
        val c = URL(ReelsConfig.API_URL.trimEnd('/') + "/upload?caption=" + URLEncoder.encode(caption, "UTF-8")).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "video/mp4")
            c.setFixedLengthStreamingMode(file.length())
            c.connectTimeout = 15000; c.readTimeout = 120000
            file.inputStream().use { i -> c.outputStream.use { o -> i.copyTo(o) } }
            if (c.responseCode != 200) return null
            return JSONObject(c.inputStream.bufferedReader().readText())
        } finally { c.disconnect() }
    }

    /** يرفع الفيديو إلى تيليجرام ثم يسجّله في Firestore. يرجع رسالة للمستخدم. */
    suspend fun publish(ctx: Context, file: File, song: Song, caption: String): String {
        if (!ReelsConfig.enabled) return "لم يُضبط خادم الريلز بعد"
        if (!Cloud.ready(ctx) || !Cloud.signedIn) return "سجّل الدخول أولًا (الإعدادات ← الحساب)"
        if (file.length() > 19L * 1024 * 1024) return "الفيديو أكبر من 19 ميغابايت (حد تيليجرام)"
        return try {
            val token = FirebaseAuth.getInstance().currentUser!!.getIdToken(false).awaitT().token
                ?: return "تعذّر التحقق من الحساب"
            val res = withContext(Dispatchers.IO) { upload(token, file, caption) } ?: return "فشل الرفع إلى الخادم"
            val fileId = res.optString("fileId")
            if (fileId.isBlank()) return "ردّ الخادم غير صحيح"
            FirebaseFirestore.getInstance().collection(COL).add(
                mapOf(
                    "fileId" to fileId, "thumbId" to res.optString("thumbId"), "caption" to caption,
                    "song" to song.title, "artist" to song.artist, "author" to Profile.name.ifBlank { "مستخدم T Music" },
                    "uid" to FirebaseAuth.getInstance().currentUser!!.uid, "at" to System.currentTimeMillis(),
                    "likes" to 0L, "reports" to 0L
                )
            ).awaitT()
            "تم النشر ✔ سيراه الجميع في «ريلز»"
        } catch (e: Exception) { "تعذّر النشر: ${e.message ?: ""}" }
    }

    fun toggleLike(ctx: Context, r: PubReel) {
        val was = r.id in liked
        if (was) liked.remove(r.id) else liked.add(r.id)
        ctx.applicationContext.getSharedPreferences("tm_reels_local", Context.MODE_PRIVATE).edit().putStringSet("liked", liked.toSet()).apply()
        val d = if (was) -1L else 1L
        runCatching { FirebaseFirestore.getInstance().collection(COL).document(r.id).update("likes", FieldValue.increment(d)) }
        items = items.map { if (it.id == r.id) it.copy(likes = (it.likes + d).coerceAtLeast(0L)) else it }
    }

    fun report(ctx: Context, r: PubReel) {
        runCatching { FirebaseFirestore.getInstance().collection(COL).document(r.id).update("reports", FieldValue.increment(1L)) }
        Toast.makeText(ctx, "شكرًا، تم الإبلاغ", Toast.LENGTH_SHORT).show()
    }

    fun delete(r: PubReel) {
        runCatching { FirebaseFirestore.getInstance().collection(COL).document(r.id).delete() }
        items = items.filter { it.id != r.id }
    }
}

/** شاشة ريلز بملء الشاشة: اسحب للأعلى للتالي، المس لإيقاف الفيديو، وأسفلها شريحة الأغنية. */
@Composable
fun ReelsFeedOverlay(ui: PlayerUi, songs: List<Song>) {
    if (!ReelsHub.open) return
    val ctx = LocalContext.current
    BackHandler { ReelsHub.open = false }
    LaunchedEffect(Unit) { ReelsHub.init(ctx); ReelsHub.refresh(ctx) }
    // الموسيقى تتوقف أثناء مشاهدة الريلز وتعود عند الإغلاق إن كانت تعمل
    DisposableEffect(Unit) {
        val was = ui.isPlaying
        ui.controller?.pause()
        onDispose { if (was) ui.controller?.play() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable(enabled = false) {}) {
        val list = ReelsHub.items
        when {
            !ReelsConfig.enabled -> CenterNote("الريلز غير مفعّلة بعد", "ضع رابط الخادم في ReelsConfig.kt (الخطوات في reels-server/README.md).")
            ReelsHub.loading && list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Color.White) }
            list.isEmpty() -> CenterNote(
                if (ReelsHub.error.isNotBlank()) "تعذّر التحميل" else "لا توجد ريلز بعد",
                if (ReelsHub.error.isNotBlank()) ReelsHub.error else "كن أول من ينشر: شغّل أغنية ← زر الريلز ← انشر في T Music."
            )
            else -> {
                val pager = rememberPagerState { list.size }
                VerticalPager(pager, Modifier.fillMaxSize()) { page ->
                    ReelPage(list[page], pager.currentPage == page, ui, songs)
                }
            }
        }
        // الشريط العلوي
        Row(Modifier.fillMaxWidth().systemBarsPadding().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ ReelsHub.open = false }) { Icon(Icons.Rounded.Close, "إغلاق", tint = Color.White) }
            Text("ريلز", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            IconButton({
                val cur = songs.firstOrNull { it.id == ui.currentId }
                if (cur == null) Toast.makeText(ctx, "شغّل أغنية أولًا ثم اضغط +", Toast.LENGTH_SHORT).show()
                else { ReelsHub.open = false; ReelUi.open(cur) }
            }) { Icon(Icons.Rounded.AddCircle, "نشر ريلز", tint = Color.White, modifier = Modifier.size(30.dp)) }
        }
    }
}

@Composable
private fun CenterNote(title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Rounded.PlayCircle, null, Modifier.size(56.dp), tint = TM.Muted)
        Spacer(Modifier.height(14.dp))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, color = TM.Muted, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ReelPage(r: PubReel, active: Boolean, ui: PlayerUi, songs: List<Song>) {
    val ctx = LocalContext.current
    val local = remember(r.song, songs) {
        val a = r.song.lowercase().filter { it.isLetterOrDigit() }
        if (a.length < 3) null else songs.firstOrNull { s -> s.title.lowercase().filter { it.isLetterOrDigit() } == a }
    }
    val me = remember { if (Cloud.ready(ctx)) runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull() else null }
    val liked = r.id in ReelsHub.liked
    Box(Modifier.fillMaxSize()) {
        if (active) ReelVideoView(ReelsHub.url(r.fileId))
        else {
            val bmp by produceState<Bitmap?>(null, r.thumbId) {
                value = if (r.thumbId.isNotBlank()) runCatching { Art.remote(ReelsHub.url(r.thumbId)) }.getOrNull() else null
            }
            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(260.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        // أزرار الجانب
        Column(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 10.dp, bottom = 90.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton({ ReelsHub.toggleLike(ctx, r) }, Modifier.size(54.dp)) {
                Icon(if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "إعجاب", Modifier.size(32.dp), tint = if (liked) Color(0xFFFF375F) else Color.White)
            }
            Text(r.likes.toString(), color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            IconButton({ ReelsHub.report(ctx, r) }, Modifier.size(48.dp)) { Icon(Icons.Rounded.Flag, "إبلاغ", Modifier.size(26.dp), tint = Color.White) }
            if (me != null && me == r.uid) IconButton({ ReelsHub.delete(r) }, Modifier.size(48.dp)) { Icon(Icons.Rounded.Delete, "حذف", Modifier.size(26.dp), tint = Color.White) }
        }
        // معلومات الناشر وشريحة الأغنية
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(0.78f).navigationBarsPadding().padding(start = 16.dp, bottom = 22.dp)) {
            Text(r.author, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (r.caption.isNotBlank()) Text(r.caption, color = Color.White.copy(0.9f), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.clip(RoundedCornerShape(22.dp)).background(Color(0x66FFFFFF)).clickable {
                    if (local != null) { ReelsHub.open = false; ui.play(listOf(local), 0) }
                    else runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(r.song + " " + r.artist))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (local != null) Icons.Rounded.PlayArrow else Icons.Rounded.MusicNote, null, Modifier.size(18.dp), tint = Color.White)
                Spacer(Modifier.width(6.dp))
                Text(r.song + if (r.artist.isNotBlank()) " · " + r.artist else "", color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ReelVideoView(url: String) {
    val ctx = LocalContext.current
    var ratio by remember(url) { mutableFloatStateOf(9f / 16f) }
    var paused by remember(url) { mutableStateOf(false) }
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setAudioAttributes(AudioAttributes.DEFAULT, true)
            repeatMode = Player.REPEAT_MODE_ONE
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) ratio = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
            paused = !paused; player.playWhenReady = !paused
        },
        Alignment.Center
    ) {
        AndroidView(
            factory = { c -> SurfaceView(c).also { player.setVideoSurfaceView(it) } },
            modifier = Modifier.fillMaxWidth().aspectRatio(ratio)
        )
        if (paused) Box(Modifier.size(84.dp).clip(CircleShape).background(Color(0x66000000)), Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(52.dp), tint = Color.White)
        }
    }
}
