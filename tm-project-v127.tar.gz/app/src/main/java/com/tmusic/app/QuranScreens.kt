package com.tmusic.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.sp

/** مبدّل الأقسام العلوي: T Music | T Quran */
@Composable
fun SectionSwitch(section: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .glass(RoundedCornerShape(24.dp), strength = 0.7f).padding(4.dp)
    ) {
        listOf("T Music" to Icons.Rounded.MusicNote, "T Quran" to Icons.Rounded.MenuBook).forEachIndexed { i, (label, icon) ->
            val on = section == i
            val bg by animateColorAsState(
                if (on) (if (i == 0) TM.Violet else TM.Emerald) else Color.Transparent, tween(250), label = "section-bg"
            )
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(bg)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, Modifier.size(18.dp), tint = if (on) Color.Black else TM.Muted)
                Spacer(Modifier.width(6.dp))
                Text(label, fontWeight = FontWeight.Bold, color = if (on) Color.Black else TM.Muted)
            }
        }
    }
}

/** قسم القرآن كاملًا: قائمة السور، وعند اختيار سورة تُفتح شاشة القراءة. */
@Composable
fun QuranTab(ui: PlayerUi, songs: List<Song>, openSurah: Int, onYoutube: (YtVideo) -> Unit, onOpen: (Int) -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (openSurah != 0) SurahReader(openSurah, ui) { onOpen(0) }
        else SurahList(ui, songs, onYoutube, onOpen)
    }
}

@Composable
fun SurahRow(s: SurahInfo, active: Boolean, playing: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).background(TM.Emerald.copy(alpha = if (active) 0.28f else 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(Quran.digits(s.number), color = TM.Emerald, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "سورة ${s.name}", fontWeight = FontWeight.SemiBold, fontSize = 18.sp,
                color = if (active) TM.Emerald else TM.Text, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("${Quran.digits(s.ayahs)} آية", fontSize = 12.sp, color = TM.Muted)
        }
        if (active) EqBars(playing, TM.Emerald)
    }
}

/** قائمة السور؛ والبحث فيها عام: يجد السور والأغاني معًا. */
@Composable
private fun SurahList(ui: PlayerUi, songs: List<Song>, onYoutube: (YtVideo) -> Unit, onOpen: (Int) -> Unit) {
    val markCtx = LocalContext.current
    LaunchedEffect(Unit) { QuranMarks.init(markCtx) }
    var q by remember { mutableStateOf("") }
    val surahHits = remember(q) { Quran.search(q) }
    val (online, loading0) = rememberOnline(q)
    var submitted by remember { mutableStateOf("") }
    LaunchedEffect(q) { if (q.isBlank()) submitted = "" else { kotlinx.coroutines.delay(900); submitted = q.trim() } }
    val (yt, ytLoading) = rememberYoutube(submitted)
    val loading = loading0 || ytLoading
    val songHits = remember(songs, q) {
        val k = q.trim()
        if (k.isEmpty()) emptyList()
        else songs.filter { it.title.contains(k, true) || it.artist.contains(k, true) || it.album.contains(k, true) }.take(50)
    }
    Column(Modifier.fillMaxSize()) {
        Text(
            "القرآن الكريم", style = MaterialTheme.typography.headlineMedium, maxLines = 1,
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp)
        )
        TextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submitted = q.trim() }),
            placeholder = { Text("ابحث عن سورة أو أغنية") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, null) } },
            shape = RoundedCornerShape(14.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = TM.Raised, unfocusedContainerColor = TM.Raised,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        if (q.isNotBlank() && surahHits.isEmpty() && songHits.isEmpty() && online.isEmpty() && yt.isEmpty() && !loading) {
            EmptyState(Icons.Rounded.Search, "لا نتائج لـ «$q»", "جرّب كلمة أقصر أو اسم السورة أو الأغنية." + (if (!Online.ytReady) " لنتائج يوتيوب أضف المفتاح في Online.kt." else if (submitted != q.trim()) " اضغط زر البحث في لوحة المفاتيح لنتائج يوتيوب." else ""))
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (Online.ytReady && q.isNotBlank() && submitted != q.trim()) item {
                    Text("اضغط زر البحث في لوحة المفاتيح لعرض نتائج يوتيوب", color = TM.Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                if (q.isBlank()) {
                    val last = QuranMarks.last
                    if (last != null) item(key = "resume") {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF0F5C47), Color(0xFF123A4A))))
                                .bounceClick(0.98f) { QuranMarks.jump = last.second; onOpen(last.first) }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.AutoStories, null, Modifier.size(26.dp), tint = Color.White)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("تابع القراءة", fontWeight = FontWeight.Bold, color = Color.White)
                                Text("سورة ${Quran.surahs[last.first - 1].name}" + (if (last.second > 0) " · الآية ${Quran.digits(last.second)}" else ""), fontSize = 12.sp, color = Color.White.copy(0.75f))
                            }
                            Icon(Icons.Rounded.ChevronLeft, null, tint = Color.White.copy(0.8f))
                        }
                    }
                    if (QuranMarks.marks.isNotEmpty()) {
                        item(key = "marks-title") { SectionTitle("العلامات المرجعية") }
                        items(QuranMarks.marks.toList(), key = { "mk$it" }) { k ->
                            val parts = k.split(":")
                            val sN = parts[0].toInt(); val aN = parts[1].toInt()
                            if (sN in 1..114) Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp).clip(RoundedCornerShape(14.dp))
                                    .background(TM.Raised).bounceClick(0.98f) { QuranMarks.jump = aN; onOpen(sN) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Bookmark, null, Modifier.size(20.dp), tint = TM.Gold)
                                Spacer(Modifier.width(10.dp))
                                Text("سورة ${Quran.surahs[sN - 1].name} · الآية ${Quran.digits(aN)}", Modifier.weight(1f))
                            }
                        }
                        item(key = "marks-gap") { Spacer(Modifier.height(6.dp)) }
                    }
                }
                val surahs = if (q.isBlank()) Quran.surahs else surahHits
                if (q.isNotBlank() && surahs.isNotEmpty()) item { SectionTitle("السور") }
                items(surahs, key = { "s${it.number}" }) { s ->
                    SurahRow(s, ui.quranSurah == s.number, ui.isPlaying) { onOpen(s.number) }
                }
                if (songHits.isNotEmpty()) {
                    item { SectionTitle("على جهازك") }
                    itemsIndexed(songHits, key = { _, s -> "m${s.id}" }) { i, s ->
                        SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(songHits, i) }
                    }
                }
                if (yt.isNotEmpty()) {
                    item { SectionTitle("من يوتيوب") }
                    items(yt, key = { "y${it.id}" }) { v -> YtRow(v) { onYoutube(v) } }
                }
                if (online.isNotEmpty()) {
                    item { SectionTitle("من الإنترنت") }
                    itemsIndexed(online, key = { _, s -> "o${s.id}" }) { i, s ->
                        SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(online, i) }
                    }
                }
                if (loading) item {
                    Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                        CircularProgressIndicator(color = TM.Emerald, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReciterPicker(ui: PlayerUi, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton({ open = true }) {
            Text(
                Quran.reciters[ui.reciterIdx].name, color = TM.Emerald, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 130.dp)
            )
            Icon(Icons.Rounded.ArrowDropDown, null, tint = TM.Emerald)
        }
        DropdownMenu(open, { open = false }) {
            Quran.reciters.forEachIndexed { i, r ->
                DropdownMenuItem(text = { Text(r.name) }, onClick = { open = false; onPick(i) })
            }
        }
    }
}

@Composable
private fun SurahReader(n: Int, ui: PlayerUi, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val info = Quran.surahs[n - 1]
    var lines by remember(n) { mutableStateOf<List<String>?>(null) }
    var failed by remember(n) { mutableStateOf(false) }
    var attempt by remember(n) { mutableIntStateOf(0) }
    LaunchedEffect(n, attempt) {
        failed = false
        val r = Quran.load(ctx, n)
        lines = r
        failed = r == null
    }
    BackHandler(onBack = onBack)
    var showSpeed by remember { mutableStateOf(false) }

    val active = ui.quranSurah == n
    val listState = rememberLazyListState()
    val ls = lines
    LaunchedEffect(n) { QuranMarks.init(ctx) }
    LaunchedEffect(ls != null) {
        if (ls != null && QuranMarks.jump > 0) { listState.scrollToItem(QuranMarks.jump.coerceAtMost(ls.size)); QuranMarks.jump = 0 }
    }
    LaunchedEffect(n, ls != null) {
        if (ls != null) snapshotFlow { listState.firstVisibleItemIndex }.collect { QuranMarks.setLast(ctx, n, it) }
    }
    val tapHaptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    LaunchedEffect(ui.quranAyah, active, ls != null) {
        if (active && ls != null) listState.animateScrollToItem(ui.quranAyah.coerceAtLeast(0))
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text("سورة ${info.name}", style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${Quran.digits(info.ayahs)} آية", fontSize = 12.sp, color = TM.Muted)
            }
            ReciterPicker(ui) { i ->
                ui.setReciter(i)
                if (active) ui.playQuran(n, ui.quranAyah.coerceAtLeast(1))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "السرعة " + AppPrefs.speedLabel(), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = if (AppPrefs.speed == 1f) TM.Muted else TM.Emerald,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { showSpeed = true }.padding(horizontal = 10.dp, vertical = 8.dp)
            )
            VolumeBar(TM.Emerald, Modifier.weight(1f))
        }
        if (showSpeed) SpeedDialog { showSpeed = false }

        when {
            ls != null -> LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 24.dp), modifier = Modifier.fillMaxSize()) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(22.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF0F5C47), Color(0xFF123A4A))))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("سورة ${info.name}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        if (Quran.hasBasmala(n)) {
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", fontSize = 24.sp, textAlign = TextAlign.Center,
                                color = if (active && ui.quranAyah == 0) TM.Gold else Color.White.copy(0.9f)
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { if (active) ui.togglePlay() else ui.playQuran(n, 1) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Icon(if (active && ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(22.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (active && ui.isPlaying) "إيقاف مؤقت" else "استماع للسورة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                itemsIndexed(ls) { i, text ->
                    val a = i + 1
                    val on = active && ui.quranAyah == a
                    val bg by animateColorAsState(if (on) TM.Emerald.copy(alpha = 0.16f) else Color.Transparent, tween(300), label = "ayah-bg")
                    Text(
                        buildAnnotatedString {
                            append(text)
                            append(" ")
                            withStyle(SpanStyle(color = TM.Gold, fontSize = 22.sp)) { append("﴿${Quran.digits(a)}﴾") }
                            if (QuranMarks.has(n, a)) withStyle(SpanStyle(color = TM.Gold, fontSize = 20.sp)) { append(" ★") }
                        },
                        fontSize = 28.sp, lineHeight = 52.sp, color = if (on) Color.White else TM.Text,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(14.dp)).background(bg)
                            .pointerInput(n, a) {
                                detectTapGestures(
                                    onTap = { ui.playQuran(n, a) },
                                    onLongPress = {
                                        tapHaptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                        QuranMarks.toggle(ctx, n, a)
                                    }
                                )
                            }.padding(14.dp)
                    )
                }
            }
            failed -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Rounded.CloudOff, null, Modifier.size(56.dp), tint = TM.Muted)
                Spacer(Modifier.height(16.dp))
                Text("تعذّر تحميل السورة", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("تأكد من اتصالك بالإنترنت، وبعد التحميل الأول تُحفظ السورة على جهازك.", color = TM.Muted, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                FilledTonalButton({ attempt++ }) { Text("إعادة المحاولة") }
            }
            else -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = TM.Emerald) }
        }
    }
}

@Composable
fun QuranMiniPlayer(ui: PlayerUi, onOpen: () -> Unit) {
    val info = Quran.surahs.getOrNull(ui.quranSurah - 1) ?: return
    val reciter = Quran.reciters[ui.reciterIdx].name
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF12372E)).clickable(onClick = onOpen)
    ) {
        Row(Modifier.padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(Brush.linearGradient(listOf(Color(0xFF0F5C47), TM.Emerald)), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.MenuBook, null, tint = Color.White) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("سورة ${info.name}", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    if (ui.quranAyah > 0) "الآية ${Quran.digits(ui.quranAyah)} • $reciter" else reciter,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.White.copy(0.7f)
                )
            }
            IconButton(ui::togglePlay) {
                Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(30.dp))
            }
            IconButton(ui::next) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(28.dp)) }
        }
    }
}
