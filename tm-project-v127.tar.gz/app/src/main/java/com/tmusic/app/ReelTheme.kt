package com.tmusic.app

import android.graphics.Bitmap
import android.graphics.Color

/**
 * سمة مشهد الريلز تُختار من لون غلاف الأغنية:
 * 0 ساكورا · 1 غروب ومعبد توري · 2 غابة وباغودا · 3 قمر وثلج · 4 حبر وجبال (للأغلفة الرمادية/الأبيض والأسود).
 */
internal class ReelTheme(
    val kind: Int,
    val skyTop: Int, val skyMid: Int, val skyLow: Int,
    val glow: Int, val leafA: Int, val leafB: Int,
    val petalA: Int, val petalB: Int, val water1: Int, val water2: Int
) {
    fun leaf(tone: Float): Int = mix(leafA, leafB, tone)
    fun petal(k: Float): Int = mix(petalA, petalB, k)
    fun glowA(a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(glow), Color.green(glow), Color.blue(glow))

    companion object {
        fun mix(a: Int, b: Int, t: Float): Int {
            val k = t.coerceIn(0f, 1f)
            return Color.rgb(
                (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
                (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
                (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
            )
        }

        private fun c(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)

        fun of(kind: Int): ReelTheme = when (kind) {
            1 -> ReelTheme(1, c(24, 6, 6), c(80, 20, 14), c(170, 60, 24), c(255, 140, 60), c(200, 40, 24), c(255, 150, 50),
                c(255, 110, 40), c(255, 200, 90), c(90, 26, 14), c(16, 4, 4))
            2 -> ReelTheme(2, c(4, 16, 14), c(10, 48, 40), c(24, 96, 70), c(110, 255, 190), c(40, 150, 90), c(170, 235, 120),
                c(120, 230, 140), c(210, 255, 170), c(12, 60, 48), c(3, 14, 12))
            3 -> ReelTheme(3, c(5, 8, 24), c(14, 28, 66), c(40, 72, 130), c(150, 200, 255), c(150, 190, 240), c(240, 248, 255),
                c(230, 240, 255), c(255, 255, 255), c(18, 36, 84), c(4, 8, 22))
            4 -> ReelTheme(4, c(10, 10, 14), c(30, 32, 40), c(70, 74, 86), c(200, 205, 220), c(120, 124, 140), c(225, 228, 238),
                c(210, 214, 226), c(255, 255, 255), c(36, 38, 48), c(8, 8, 12))
            else -> ReelTheme(0, c(16, 5, 24), c(46, 12, 52), c(92, 26, 84), c(255, 110, 200), c(255, 95, 160), c(255, 185, 230),
                c(255, 150, 195), c(255, 230, 195), c(70, 18, 70), c(10, 3, 16))
        }

        /** يختار السمة من متوسط لون الغلاف: الألوان الحمراء/البرتقالية غروب، الخضراء غابة، الزرقاء قمر وثلج، الرمادية حبر. */
        fun pick(art: Bitmap?): ReelTheme {
            if (art == null) return of(0)
            return try {
                val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
                val hsv = FloatArray(3)
                Color.colorToHSV(px, hsv)
                val h = hsv[0]; val s = hsv[1]
                of(
                    when {
                        s < 0.20f -> 4
                        h >= 340f || h < 55f -> 1
                        h < 170f -> 2
                        h < 265f -> 3
                        else -> 0
                    }
                )
            } catch (_: Throwable) { of(0) }
        }
    }
}
