package com.tmusic.app

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شارات وإنجازات تُحسب من سجل الاستماع الموجود أصلًا (عدد مرات التشغيل × مدة الأغنية). */
data class AchBadge(val id: String, val title: String, val desc: String, val value: Long, val target: Long)

object Achievements {
    private const val P = "tm_ach"

    fun stats(plays: Map<Long, Int>, byId: Map<Long, Song>, libSize: Int): List<AchBadge> {
        val total = plays.values.sum().toLong()
        val unique = plays.size.toLong()
        val top = (plays.values.maxOrNull() ?: 0).toLong()
        val hours = plays.entries.sumOf { (id, n) -> (byId[id]?.duration ?: 0L) * n } / 3_600_000L
        val favs = Favorites.ids.size.toLong()
        return listOf(
            AchBadge("p10", "بداية الرحلة", "شغّل 10 أغانٍ", total, 10),
            AchBadge("p100", "مستمع نشط", "شغّل 100 أغنية", total, 100),
            AchBadge("p500", "عاشق الموسيقى", "شغّل 500 أغنية", total, 500),
            AchBadge("p2000", "أسطورة الاستماع", "شغّل 2000 أغنية", total, 2000),
            AchBadge("h5", "خمس ساعات", "استمع لخمس ساعات", hours, 5),
            AchBadge("h24", "يوم كامل", "استمع لمدة 24 ساعة", hours, 24),
            AchBadge("h100", "مئة ساعة", "استمع لمئة ساعة", hours, 100),
            AchBadge("h500", "خمسمئة ساعة", "استمع لخمسمئة ساعة", hours, 500),
            AchBadge("u20", "فضولي", "شغّل 20 أغنية مختلفة", unique, 20),
            AchBadge("u100", "مستكشف", "شغّل 100 أغنية مختلفة", unique, 100),
            AchBadge("t20", "مدمن الأغنية", "أعد أغنية واحدة 20 مرة", top, 20),
            AchBadge("f10", "ذوّاقة", "ضع 10 أغانٍ في المفضلة", favs, 10),
            AchBadge("f50", "أمين المفضلة", "ضع 50 أغنية في المفضلة", favs, 50),
            AchBadge("l100", "جامع", "مكتبة فيها 100 أغنية", libSize.toLong(), 100),
            AchBadge("l500", "خزانة موسيقى", "مكتبة فيها 500 أغنية", libSize.toLong(), 500)
        )
    }

    /** يُظهر إشعارًا عند فتح شارة جديدة. أول تشغيل يحفظ ما هو مفتوح أصلًا بصمت. */
    fun check(ctx: Context, plays: Map<Long, Int>, byId: Map<Long, Song>, libSize: Int) {
        val sp = ctx.applicationContext.getSharedPreferences(P, Context.MODE_PRIVATE)
        val done = (sp.getString("done", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
        val first = !sp.getBoolean("init", false)
        val fresh = stats(plays, byId, libSize).filter { it.value >= it.target && it.id !in done }
        if (fresh.isEmpty() && !first) return
        done += fresh.map { it.id }
        sp.edit().putString("done", done.joinToString(",")).putBoolean("init", true).apply()
        if (!first) fresh.forEach { Toast.makeText(ctx, "🏆 إنجاز جديد: ${it.title}", Toast.LENGTH_LONG).show() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AchievementsSheet(ui: PlayerUi, byId: Map<Long, Song>, libSize: Int, onDismiss: () -> Unit) {
    val list = remember(ui.plays, byId, libSize, Favorites.ids.size) { Achievements.stats(ui.plays, byId, libSize) }
    val got = list.count { it.value >= it.target }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.EmojiEvents, null, tint = TM.Gold)
                Spacer(Modifier.width(10.dp))
                Text("الإنجازات", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                Text("$got / ${list.size}", color = TM.Muted)
            }
            LazyColumn(Modifier.heightIn(max = 560.dp)) {
                items(list, key = { it.id }) { b ->
                    val ok = b.value >= b.target
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (ok) TM.Gold.copy(alpha = 0.12f) else TM.Raised).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(if (ok) Icons.Rounded.EmojiEvents else Icons.Rounded.Lock, null, Modifier.size(30.dp), tint = if (ok) TM.Gold else TM.Muted)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(b.title, fontWeight = FontWeight.SemiBold)
                            Text(b.desc, color = TM.Muted, fontSize = 12.sp)
                            if (!ok) {
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { (b.value.toFloat() / b.target).coerceIn(0f, 1f) },
                                    Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                    color = TM.VioletSoft, trackColor = Color.White.copy(0.1f)
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(if (ok) "✔" else "${b.value}/${b.target}", color = if (ok) TM.Gold else TM.Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
