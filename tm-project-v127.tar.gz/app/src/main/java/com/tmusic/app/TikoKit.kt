package com.tmusic.app

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** أحداث التطبيق التي يتفاعل معها تيكو. أضف حدثًا جديدًا هنا ثم أضف ردّه في TikoKit.reactions فقط. */
enum class TikoEvent { AppOpened, PlaybackStarted, PlaybackPaused, SongLiked, UpdateAvailable, DownloadDone, Error, Tapped, LongIdle }

/** المؤثر الصوتي القصير المصاحب (يُولَّد برمجيًا، بلا ملفات صوت). */
enum class TikoSfx { None, Chime, Pop, Alert }

/**
 * ردّ تيكو: [clip] اسم الحركة داخل tiko.glb (idle, wave, laugh, love, music (يرقص), dance, sleep, alert, think, talk, nod, no, wink, shy, jump, spin, enter),
 * [say] جملة تظهر في الفقاعة، [sfx] مؤثر صوتي.
 */
data class TikoReaction(val clip: String, val say: String? = null, val sfx: TikoSfx = TikoSfx.None)

/**
 * طبقة تيكو الخاصة بهذا التطبيق: هنا فقط تُحدَّد «شخصية» تيكو في T Music.
 * في تطبيق آخر انسخ الملف وغيّر جدول reactions وحده؛ ملف tiko.glb يبقى نفسه.
 */
object TikoKit {
    var enabled by mutableStateOf(true)
    var soundOn by mutableStateOf(true)
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tm_tikokit", Context.MODE_PRIVATE)
        prefs = p
        enabled = p.getBoolean("enabled", true)
        soundOn = p.getBoolean("sound", true)
    }
    fun chooseEnabled(v: Boolean) { enabled = v; prefs?.edit()?.putBoolean("enabled", v)?.apply() }
    fun chooseSound(v: Boolean) { soundOn = v; prefs?.edit()?.putBoolean("sound", v)?.apply() }

    /** جدول الأحداث ← الردود. عدّل هذا الجدول فقط ليتغير سلوك تيكو في التطبيق. */
    val reactions: Map<TikoEvent, TikoReaction> = mapOf(
        TikoEvent.AppOpened to TikoReaction("wave", "أهلاً بك من جديد", TikoSfx.Chime),
        TikoEvent.PlaybackStarted to TikoReaction("music", null, TikoSfx.None),
        TikoEvent.PlaybackPaused to TikoReaction("idle"),
        TikoEvent.SongLiked to TikoReaction("love", "ذوقك جميل", TikoSfx.Pop),
        TikoEvent.UpdateAvailable to TikoReaction("alert", "وصلني تحديث جديد", TikoSfx.Alert),
        TikoEvent.DownloadDone to TikoReaction("laugh", "تم التنزيل", TikoSfx.Pop),
        TikoEvent.Error to TikoReaction("no", "حدث خطأ، جرّب مرة أخرى"),
        TikoEvent.Tapped to TikoReaction("wink"),
        TikoEvent.LongIdle to TikoReaction("sleep", null),
    )

    /** يعيد رد الحدث، أو null إن كان تيكو معطّلًا. يشغّل المؤثر الصوتي إذا كان الصوت مفعّلًا. */
    fun react(ctx: Context, e: TikoEvent): TikoReaction? {
        init(ctx)
        if (!enabled) return null
        val r = reactions[e] ?: return null
        if (soundOn) playSfx(r.sfx)
        return r
    }

    private fun playSfx(s: TikoSfx) {
        val tone = when (s) {
            TikoSfx.Chime -> ToneGenerator.TONE_PROP_ACK
            TikoSfx.Pop -> ToneGenerator.TONE_PROP_BEEP
            TikoSfx.Alert -> ToneGenerator.TONE_PROP_PROMPT
            TikoSfx.None -> return
        }
        try {
            val g = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 45)
            g.startTone(tone, 160)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ g.release() }, 400)
        } catch (_: Throwable) {}
    }
}
