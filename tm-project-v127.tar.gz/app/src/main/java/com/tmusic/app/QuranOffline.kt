package com.tmusic.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * القرآن دون إنترنت: ينزّل نص السور الـ114 مرة واحدة ويحفظها على الجهاز (Quran.load يقرأ من هذا المخزن أولًا).
 * يعمل تلقائيًا في الخلفية عند أول اتصال، ويمكن تشغيله يدويًا من الإعدادات.
 */
object QuranOffline {
    var ready by mutableIntStateOf(0)       // عدد السور المحفوظة
    var busy by mutableStateOf(false)
    var failed by mutableStateOf(false)
    const val TOTAL = 114

    private fun file(ctx: Context, s: Int) = File(File(ctx.filesDir, "quran"), "$s.txt")

    suspend fun refresh(ctx: Context) = withContext(Dispatchers.IO) {
        ready = Quran.surahs.count { sr ->
            val f = file(ctx, sr.number)
            f.exists() && f.readLines().size == sr.ayahs
        }
    }

    /** ينزّل ما ينقص فقط؛ يتوقف عند أول فشل شبكة (بلا إنترنت) ويمكن إعادة المحاولة لاحقًا. */
    suspend fun downloadAll(ctx: Context) {
        if (busy) return
        busy = true; failed = false
        try {
            refresh(ctx)
            for (sr in Quran.surahs) {
                val f = file(ctx, sr.number)
                if (f.exists() && withContext(Dispatchers.IO) { f.readLines().size } == sr.ayahs) continue
                val ok = Quran.load(ctx, sr.number) != null
                if (!ok) { failed = true; break }
                ready = (ready + 1).coerceAtMost(TOTAL)
            }
        } finally {
            busy = false
            refresh(ctx)
        }
    }
}
