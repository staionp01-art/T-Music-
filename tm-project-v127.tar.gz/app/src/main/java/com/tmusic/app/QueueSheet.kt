package com.tmusic.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

/**
 * قائمة الانتظار: اسحب المقبض ⠿ لإعادة الترتيب بإصبعك، زر «شغّل بعدها» ينقل الأغنية لتأتي مباشرة بعد الحالية،
 * والضغط على الصف يقفز إليه، و✕ يحذفه من القائمة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(ui: PlayerUi, onDismiss: () -> Unit) {
    val c = ui.controller
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(c) {
        val l = object : Player.Listener {
            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) { tick++ }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { tick++ }
        }
        c?.addListener(l)
        onDispose { c?.removeListener(l) }
    }
    val items: List<MediaItem> = remember(tick, c) {
        if (c == null) emptyList() else (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
    }
    val current = c?.currentMediaItemIndex ?: -1
    val rowH = 62.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    val state = rememberLazyListState()
    LaunchedEffect(Unit) { if (current > 1) state.scrollToItem((current - 1).coerceAtLeast(0)) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = TM.Surface, contentColor = TM.Text) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("قائمة الانتظار", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                Text("${items.size} أغنية", color = TM.Muted, fontSize = 13.sp)
            }
            Text("اسحب ⠿ لإعادة الترتيب · ⏭ لتشغيلها بعد الحالية", color = TM.Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp))
            if (items.isEmpty()) {
                Text("القائمة فارغة", color = TM.Muted, modifier = Modifier.padding(24.dp))
            } else {
                LazyColumn(state = state, modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    itemsIndexed(items, key = { i, it -> "${it.mediaId}#${items.take(i).count { x -> x.mediaId == it.mediaId }}" }) { i, mi ->
                        QueueRow(ui, mi, i, items.size, current, rowH, rowPx)
                    }
                }
            }
        }
    }
}

@Composable
private fun QueueRow(ui: PlayerUi, mi: MediaItem, index: Int, count: Int, current: Int, rowH: androidx.compose.ui.unit.Dp, rowPx: Float) {
    val c = ui.controller ?: return
    val idx by rememberUpdatedState(index)
    val last by rememberUpdatedState(count - 1)
    var acc by remember { mutableFloatStateOf(0f) }
    val active = index == current
    Row(
        Modifier.fillMaxWidth().height(rowH)
            .graphicsLayer { translationY = acc }
            .background(if (active) TM.Violet.copy(alpha = 0.13f) else Color.Transparent)
            .clickable { c.seekToDefaultPosition(index); c.play() }
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Rounded.DragHandle, "اسحب للترتيب",
            Modifier.size(44.dp).padding(10.dp).pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { acc = 0f },
                    onDragCancel = { acc = 0f },
                    onDrag = { change, amount ->
                        change.consume()
                        acc += amount.y
                        while (acc > rowPx / 2f && idx < last) { c.moveMediaItem(idx, idx + 1); acc -= rowPx }
                        while (acc < -rowPx / 2f && idx > 0) { c.moveMediaItem(idx, idx - 1); acc += rowPx }
                    }
                )
            },
            tint = TM.Muted
        )
        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
            Text(
                mi.mediaMetadata.title?.toString() ?: "—", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold, color = if (active) TM.VioletSoft else TM.Text
            )
            Text(
                mi.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = TM.Muted
            )
        }
        if (!active) {
            IconButton({
                val target = if (index > current) current + 1 else current
                if (index != target && target >= 0) c.moveMediaItem(index, target)
            }, Modifier.size(40.dp)) { Icon(Icons.Rounded.SkipNext, "شغّل بعدها", Modifier.size(22.dp), tint = TM.VioletSoft) }
            IconButton({ c.removeMediaItem(index) }, Modifier.size(40.dp)) { Icon(Icons.Rounded.Close, "حذف", Modifier.size(20.dp), tint = TM.Muted) }
        } else {
            EqBars(ui.isPlaying, TM.VioletSoft)
            Spacer(Modifier.width(14.dp))
        }
    }
}
