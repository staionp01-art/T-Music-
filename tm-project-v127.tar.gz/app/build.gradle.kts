plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// تسجيل الدخول والمزامنة (Firebase) يعملان فقط إذا وُجد الملف app/google-services.json
if (file("google-services.json").exists()) apply(plugin = "com.google.gms.google-services")

android {
    namespace = "com.tmusic.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tmusic.app"
        minSdk = 24
        targetSdk = 35
        val buildNum = (project.findProperty("buildNum") as String?)?.toIntOrNull() ?: 1
        versionCode = buildNum
        versionName = "1.$buildNum"
        buildConfigField("String", "GH_REPO", "\"${project.findProperty("ghRepo") ?: ""}\"")
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += listOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES") }
    }
    signingConfigs {
        // مفتاح ثابت: يلزم لكي تُثبَّت التحديثات فوق النسخة القديمة ولتسجيل SHA-1 في Firebase
        getByName("debug") {
            storeFile = file("tm-debug.keystore")
            storePassword = "android"
            keyAlias = "tmusic"
            keyPassword = "android"
        }
    }
    androidResources { noCompress += listOf("mp4") }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.media3:media3-exoplayer:1.5.0")
    implementation("androidx.media3:media3-session:1.5.0")
    implementation("androidx.palette:palette-ktx:1.0.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.4")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.4")
}
