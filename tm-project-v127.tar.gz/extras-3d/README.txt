تيكو ثلاثي الأبعاد (اختياري، غير مفعّل ولا يؤثر على البناء):
1) انسخ Tiko3D.kt.txt إلى app/src/main/java/com/tmusic/app/Tiko3D.kt
2) ضع نموذج GLB في app/src/main/assets/models/tiko.glb
3) في app/build.gradle.kts أضف: implementation("io.github.sceneview:sceneview:2.2.1")
   وداخل packaging: jniLibs.pickFirsts += listOf("**/libc++_shared.so")
4) في Mascot.kt أول دالة Tiko(): if (TikoLook.mode3d) { Tiko3D(anim, modifier, onDone); return }
   وأضف var mode3d by mutableStateOf(true) في TikoLook. وفي الهيرو اجعل: if (big > 8.dp) Tiko(...)
