# إضافة تيكو (GLB) إلى T Music
1. الملف: app/src/main/assets/tiko.glb  (موضوع مسبقًا في هذه النسخة)
2. طبقة التفاعل: TikoKit.kt — جدول `reactions` يربط حدث التطبيق بحركة من الـGLB + جملة + مؤثر صوتي.
3. الإعدادات: مفتاحان جديدان في الإعدادات: «إظهار تيكو» و«أصوات تيكو».
4. من أي شاشة: val r = TikoKit.react(context, TikoEvent.SongLiked)  → r.clip / r.say
5. للعرض الفعلي بالـGLB أضف مكتبة SceneView (io.github.sceneview:sceneview) ثم حمّل "tiko.glb" وشغّل الحركة باسم r.clip.
   حتى تُضاف المكتبة يبقى تيكو الحالي (الصور المتحركة) يعمل كما هو.
