package com.tmusic.app

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.log10
import kotlin.math.roundToInt

/** تعزيز الصوت فوق 100% عبر LoudnessEnhancer على جلسة المشغّل. */
object VolBoost {
    private var le: LoudnessEnhancer? = null
    private var prefs: android.content.SharedPreferences? = null
    /** 100..300 (يبدأ دائمًا من 100 عند فتح التطبيق حفاظًا على السمع). */
    var percent by mutableIntStateOf(100); private set
    /** أقصى تعزيز مسموح من الإعدادات: 100 (معطّل) / 150 / 200 / 300 */
    var maxPercent by mutableIntStateOf(300)
    /** استبدال أزرار الصوت بشريط التطبيق بدل لوحة النظام */
    var hudOn by mutableStateOf(true)

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tm_volume", Context.MODE_PRIVATE)
        prefs = p
        maxPercent = p.getInt("max", 300)
        hudOn = p.getBoolean("hud", true)
    }

    fun saveSettings() { prefs?.edit()?.putInt("max", maxPercent)?.putBoolean("hud", hudOn)?.apply() }

    fun attach(sessionId: Int) {
        release()
        if (sessionId == 0) return
        runCatching { le = LoudnessEnhancer(sessionId) }
        apply()
    }

    fun release() { runCatching { le?.release() }; le = null }

    fun set(p: Int) { percent = p.coerceIn(100, maxPercent.coerceAtLeast(100)); apply() }

    private fun apply() {
        // dB = 20·log10(النسبة) و mB = dB × 100
        val mb = (2000.0 * log10(percent / 100.0)).roundToInt()
        runCatching { le?.setTargetGain(mb); le?.setEnabled(percent > 100) }
    }
}

/** شريط الصوت الخاص بالتطبيق: يظهر في الأعلى بدل لوحة النظام. */
object VolumeHud {
    var visible by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)        // 0..1 ضمن 0..100%
    var boost by mutableIntStateOf(100)
    var stamp by mutableLongStateOf(0L)

    fun key(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (up) {
            if (cur >= max && VolBoost.maxPercent > 100) VolBoost.set(VolBoost.percent + 10)
            else am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
        } else {
            if (VolBoost.percent > 100) VolBoost.set(VolBoost.percent - 10)
            else am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
        }
        val now = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        level = now / max.toFloat()
        boost = VolBoost.percent
        visible = true
        stamp = SystemClock.uptimeMillis()
    }

    /** ضبط الصوت بالسحب على الشريط (يُبقي الشريط ظاهرًا أثناء السحب). */
    fun setLevel(ctx: Context, f: Float) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        if (VolBoost.percent > 100) VolBoost.set(100)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (f.coerceIn(0f, 1f) * max).roundToInt(), 0) }
        level = am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
        boost = VolBoost.percent
        visible = true
        stamp = SystemClock.uptimeMillis()
    }
}

private val BoostBlue = Color(0xFF4DB6FF)

@Composable
fun VolumeHudOverlay() {
    val hudCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(VolumeHud.stamp) {
        val s = VolumeHud.stamp
        delay(1700)
        if (VolumeHud.stamp == s) VolumeHud.visible = false
    }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 10.dp, start = 14.dp, end = 14.dp), Alignment.TopCenter) {
        AnimatedVisibility(
            VolumeHud.visible,
            enter = slideInVertically { -it * 2 } + fadeIn(),
            exit = slideOutVertically { -it * 2 } + fadeOut()
        ) {
            val boosted = VolumeHud.boost > 100
            val pct = if (boosted) VolumeHud.boost else (VolumeHud.level * 100).roundToInt()
            val col = if (boosted) BoostBlue else Color.White
            // بطاقة صغيرة داكنة: النسبة بالأعلى، وتحتها خط أبيض (أزرق عند التعزيز) يُسحب لضبط الصوت
            val frac = if (boosted) ((VolumeHud.boost - 100) / 200f).coerceIn(0.05f, 1f) else VolumeHud.level
            Column(
                Modifier.width(236.dp).background(Color(0xF2111113), RoundedCornerShape(13.dp))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    if (boosted) {
                        Waves(VolumeHud.boost, true)
                        Spacer(Modifier.width(6.dp))
                        Text("Volume $pct%", color = col, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        Waves(VolumeHud.boost, false)
                    } else {
                        Icon(
                            when { pct == 0 -> Icons.Rounded.VolumeOff; pct < 50 -> Icons.Rounded.VolumeDown; else -> Icons.Rounded.VolumeUp },
                            null, Modifier.size(14.dp), tint = col.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text("$pct%", color = col, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                HudBar(frac, col) { VolumeHud.setLevel(hudCtx, it) }
            }
        }
    }
}

/** خط الصوت: الجزء المملوء بالأبيض، والباقي نقاط صغيرة. يُسحب أو يُضغط لضبط المستوى. */
@Composable
private fun HudBar(frac: Float, col: Color, onChange: (Float) -> Unit) {
    val cb by rememberUpdatedState(onChange)
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr
    ) {
        Canvas(
            Modifier.fillMaxWidth().height(16.dp)
                .pointerInput(Unit) {
                    androidx.compose.foundation.gestures.detectTapGestures { cb((it.x / size.width).coerceIn(0f, 1f)) }
                }
                .pointerInput(Unit) {
                    androidx.compose.foundation.gestures.detectHorizontalDragGestures(
                        onDragStart = { cb((it.x / size.width).coerceIn(0f, 1f)) },
                        onHorizontalDrag = { c, _ -> c.consume(); cb((c.position.x / size.width).coerceIn(0f, 1f)) }
                    )
                }
        ) {
            val cy = size.height / 2f
            val fw = size.width * frac.coerceIn(0f, 1f)
            val th = 5.dp.toPx()
            drawLine(col, Offset(th / 2f, cy), Offset(fw.coerceAtLeast(th / 2f), cy), strokeWidth = th, cap = StrokeCap.Round)
            // الجزء الفارغ نقاط صغيرة
            var x = fw + 9.dp.toPx()
            while (x < size.width - 2.dp.toPx()) {
                drawCircle(Color.White.copy(alpha = 0.38f), 1.5.dp.toPx(), Offset(x, cy))
                x += 8.dp.toPx()
            }
        }
    }
}

/** قوسا الموجة الصوتية على جانبي «الصوت»؛ يزداد وهجهما مع التعزيز. */
@Composable
private fun Waves(boost: Int, mirror: Boolean) {
    val a1 = 0.45f + ((boost - 100) / 200f) * 0.55f
    Canvas(Modifier.size(width = 16.dp, height = 20.dp)) {
        val sw = 2.2.dp.toPx()
        val cx = if (mirror) 0f else size.width
        fun arc(rad: Float, a: Float) {
            drawArc(
                BoostBlue.copy(alpha = a.coerceIn(0f, 1f)),
                startAngle = if (mirror) -55f else 125f, sweepAngle = 110f, useCenter = false,
                topLeft = Offset(cx - rad, size.height / 2f - rad), size = Size(rad * 2, rad * 2),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        arc(size.width * 0.45f, a1)
        arc(size.width * 0.95f, a1 * 0.7f)
    }
}
