package com.tmusic.app

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.os.Build
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.max
import kotlin.math.sin

/** قوالب الريلز المبنية على مقاطع فيديو حقيقية (assets/reelbg/bgN.mp4). */
val reelVideoNames = listOf("ساكورا رمادي", "ساكورا ليلي", "عيون الساكورا", "الساموراي", "مجرّة")

/** عدد قوالب الرسم القديمة قبل قوالب الفيديو (زجاجي، ساكورا، غلاف نابض، أسطوانة). */
const val REEL_VIDEO_BASE = 4

/** أبعاد الريلز لقوالب الفيديو: عرضي 16:9 مثل المقاطع الأصلية (بدون أشرطة ولا قص). */
const val REEL_LAND_W = 1280
const val REEL_LAND_H = 720

/**
 * مشهد عرضي 1280×720: الفيديو يملأ الإطار كاملًا بدون أي غشاء أو تمويه أو أشرطة،
 * وفوقه بطاقة مشغّل مثل فيديو الساكورا المرجعي: الغلاف على اليسار، والعبارة والعنوان والفنان،
 * أعمدة الصوت الحقيقية، شريط التقدم بالأزمنة، وأزرار التحكم.
 */
class VideoScene(
    ctx: Context, private val song: Song, private val art: Bitmap?, private val lenSec: Int,
    label: String, private val spec: Spectrum, private val startMs: Long, index: Int
) : ReelFrame {
    private val W = REEL_LAND_W.toFloat()
    private val H = REEL_LAND_H.toFloat()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val logo: Bitmap? = runCatching { BitmapFactory.decodeResource(ctx.resources, R.drawable.tm_logo) }.getOrNull()
    private val accent: Int = run {
        if (art == null) return@run Color.rgb(255, 140, 200)
        runCatching {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = hsv[1].coerceAtLeast(0.45f); hsv[2] = hsv[2].coerceAtLeast(0.92f)
            Color.HSVToColor(hsv)
        }.getOrDefault(Color.rgb(255, 140, 200))
    }

    private val mmr = MediaMetadataRetriever()
    private var durUs = 1_000_000L
    private var ready = false
    private var lastIdx = -1
    private var frame: Bitmap? = null

    private val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 46f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
    private val tt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.04f }
    private val ta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 255, 255); textSize = 18f }
    private val tm = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 255, 255, 255); textSize = 19f }
    private val cta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 26f; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 2f, Color.argb(200, 0, 0, 0))
    }
    private val camera = Camera()
    private val cm = Matrix()

    // بطاقة واحدة: الغلاف ملتصق بيسارها بطول كامل، والنصوص والتحكم على يمينها
    private val card = RectF(110f, 170f, 900f, 540f)
    private val coverR = RectF(card.left, card.top, card.left + 300f, card.bottom)
    private val textX = coverR.right + 34f
    private val textR = card.right - 30f
    private val textW = textR - textX
    private val tTitle = TextUtils.ellipsize(song.title.uppercase(), tt, textW, TextUtils.TruncateAt.END).toString()
    private val tArtist = TextUtils.ellipsize(song.artist, ta, textW, TextUtils.TruncateAt.END).toString()
    private val brand = label.ifBlank { "T MUSIC" }.take(26).uppercase().let { s ->
        while (head.textSize > 20f && head.measureText(s) > textW) head.textSize -= 1f
        s
    }
    private val bars = FloatArray(46)

    init {
        runCatching {
            ctx.assets.openFd("reelbg/bg${index + 1}.mp4").use { fd ->
                mmr.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            }
            durUs = max((mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 1000L) * 1000L, 1_000_000L)
            ready = true
        }
    }

    private fun grab(t: Float) {
        if (!ready) return
        // تكرار بالتناوب (للأمام ثم للخلف) فلا يظهر قفز عند نهاية المقطع
        val tu = (t * 1_000_000f).toLong()
        val cyc = durUs * 2
        val m = ((tu % cyc) + cyc) % cyc
        val pos = if (m < durUs) m else cyc - m
        val idx = (pos / 33_333L).toInt()
        if (idx == lastIdx && frame != null) return
        lastIdx = idx
        val at = pos.coerceAtMost(durUs - 1)
        val bmp = runCatching {
            if (Build.VERSION.SDK_INT >= 27) mmr.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 1024, 576)
            else mmr.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        }.getOrNull()
        if (bmp != null) { val old = frame; frame = bmp; if (old != null && old !== bmp) old.recycle() }
    }

    private fun mmss(ms: Long): String { val s = (ms / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

    private fun hue(t: Float, off: Float): Int = Color.HSVToColor(floatArrayOf(((t * 45f + off) % 360f + 360f) % 360f, 0.82f, 1f))

    override fun draw(c: Canvas, t: Float) {
        grab(t)
        val full = RectF(0f, 0f, W, H)
        val fr = frame
        c.drawColor(Color.BLACK)
        // الفيديو بحجمه الطبيعي يملأ الإطار، بدون تعتيم ولا تمويه
        if (fr != null) c.drawBitmap(fr, coverCrop(fr, full), full, paint)

        logo?.let {
            val h = 46f; val w = h * it.width / it.height
            paint.alpha = 220
            c.drawBitmap(it, null, RectF(26f, 22f, 26f + w, 22f + h), paint)
            paint.alpha = 255
        }

        // تمايل ثلاثي الأبعاد ناعم للبطاقة كلها (مثل المشغّل المرجعي)
        c.save()
        camera.save()
        camera.rotateY(7f * sin(0.9f * t))
        camera.rotateX(4f * sin(0.7f * t + 1f))
        camera.getMatrix(cm)
        camera.restore()
        val cx = card.centerX(); val cy = card.centerY()
        cm.preTranslate(-cx, -cy); cm.postTranslate(cx, cy + 10f * sin(1.3f * t))
        c.concat(cm)

        val rr = 28f
        val shape = Path().apply { addRoundRect(card, rr, rr, Path.Direction.CW) }
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(185, 14, 6, 20); c.drawPath(shape, paint)

        c.save()
        c.clipPath(shape)
        // الغلاف يملأ يسار البطاقة بطول كامل مع نبض خفيف بالجهير
        val k = 1f + 0.02f * spec.bass(t)
        c.save()
        c.scale(k, k, coverR.centerX(), coverR.centerY())
        val a = art
        if (a != null) c.drawBitmap(a, coverCrop(a, coverR), coverR, paint) else { paint.color = accent; c.drawRect(coverR, paint) }
        c.restore()

        // أعمدة الصوت الحادّة المتوهجة: تصعد من أسفل البطاقة فوق النصوص
        spec.at(t, bars)
        val n = bars.size; val bw = 4f; val gap = (textW - n * bw) / (n - 1)
        var x = textX
        for (i in 0 until n) {
            val v = bars[i].coerceIn(0f, 1f)
            val h = 6f + 175f * Math.pow(v.toDouble(), 1.6).toFloat()
            paint.color = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(RectF(x - 3f, card.bottom - h, x + bw + 3f, card.bottom + 4f), 5f, 5f, paint)
            paint.color = Color.argb(235, 255, 255, 255)
            c.drawRoundRect(RectF(x, card.bottom - h, x + bw, card.bottom + 4f), 2f, 2f, paint)
            x += bw + gap
        }
        c.restore()

        // قطع ملوّنة تتبدل ألوانها على حافة الغلاف
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 6f; paint.color = hue(t, 0f)
        c.drawLine(coverR.left + 70f, card.top + 4f, coverR.left + 170f, card.top + 4f, paint)
        paint.strokeWidth = 5f; paint.color = hue(t, 140f)
        c.drawLine(coverR.right - 3f, card.top + 40f, coverR.right - 3f, card.top + 120f, paint)
        paint.strokeCap = Paint.Cap.BUTT
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f; paint.color = Color.argb(60, 255, 255, 255)
        c.drawPath(shape, paint)
        paint.style = Paint.Style.FILL

        // النصوص
        c.drawText(brand, textX, card.top + 74f, head)
        c.drawText(tTitle, textX, card.top + 128f, tt)
        c.drawText(tArtist, textX, card.top + 154f, ta)

        // شريط التقدم (لون المقدّمة يتبدل) مع الأزمنة
        val py = card.top + 190f
        paint.color = Color.argb(235, 255, 255, 255); c.drawRect(textX, py, textR, py + 3f, paint)
        val frac = (t / lenSec).coerceIn(0f, 1f)
        paint.color = hue(t, 60f); c.drawRect(textX, py - 1f, textX + textW * frac, py + 4f, paint)
        c.drawText(mmss(startMs + (t * 1000).toLong()), textX, py + 32f, tm)
        val endTxt = mmss(startMs + lenSec * 1000L)
        c.drawText(endTxt, textR - tm.measureText(endTxt), py + 32f, tm)

        controls(c, textX, textR, card.top + 292f)
        c.restore()

        c.drawText("استمع إلى المزيد على T Music", W / 2f, H - 34f, cta)
    }

    private fun controls(c: Canvas, x0: Float, x1: Float, cy: Float) {
        val step = (x1 - x0) / 5f
        val xs = FloatArray(6) { x0 + 12f + it * (step - 2.4f) }
        paint.color = Color.WHITE
        // نوتة
        paint.style = Paint.Style.FILL
        c.drawCircle(xs[0] - 4f, cy + 8f, 5.5f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.6f
        c.drawLine(xs[0] + 1f, cy + 8f, xs[0] + 1f, cy - 12f, paint)
        c.drawLine(xs[0] + 1f, cy - 12f, xs[0] + 10f, cy - 8f, paint)
        paint.style = Paint.Style.FILL
        fun tri(x: Float, dir: Int, s: Float) {
            c.drawPath(Path().apply { moveTo(x + dir * s, cy - s); lineTo(x - dir * s, cy); lineTo(x + dir * s, cy + s); close() }, paint)
        }
        tri(xs[1] - 7f, 1, 9f); tri(xs[1] + 5f, 1, 9f)      // السابق
        tri(xs[2], -1, 12f)                                  // تشغيل
        tri(xs[3] - 5f, -1, 9f); tri(xs[3] + 7f, -1, 9f)     // التالي
        // تكرار
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.6f
        c.drawArc(RectF(xs[4] - 11f, cy - 8f, xs[4] + 11f, cy + 8f), 30f, 300f, false, paint)
        // عشوائي
        c.drawLine(xs[5] - 11f, cy - 8f, xs[5] + 11f, cy + 8f, paint)
        c.drawLine(xs[5] - 11f, cy + 8f, xs[5] + 11f, cy - 8f, paint)
        paint.style = Paint.Style.FILL
    }

    override fun recycle() {
        runCatching { mmr.release() }
        runCatching { frame?.recycle() }
    }
}
