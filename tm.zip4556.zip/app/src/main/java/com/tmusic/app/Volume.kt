package com.tmusic.app

import android.content.Context
import android.media.AudioManager
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** شريط التحكم بصوت الموسيقى داخل شاشة التشغيل (بدل أزرار الهاتف). يتزامن مع أزرار الهاتف أيضًا. */
@Composable
fun VolumeBar(accent: Color, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var v by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(dragging) {
        while (!dragging) { v = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max; delay(300) }
    }
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (v <= 0f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeDown, "الصوت", Modifier.size(22.dp), tint = Color.White.copy(0.75f))
        Slider(
            value = v,
            onValueChange = { dragging = true; v = it; runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).roundToInt(), 0) } },
            onValueChangeFinished = { dragging = false },
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = accent, inactiveTrackColor = Color.White.copy(0.2f))
        )
        Icon(Icons.Rounded.VolumeUp, null, Modifier.size(22.dp), tint = Color.White.copy(0.75f))
    }
}
