package com.tmusic.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ===================== بحث ذكي: يتجاوز الأخطاء الإملائية ويبحث داخل الكلمات =====================
object Fuzzy {
    private val diac = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    fun similar(a: String, b: String): Boolean { val x = norm(a).trim(); val y = norm(b).trim(); return x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x)) }
    fun norm(s: String): String = diac.replace(s.lowercase(), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه').replace('ؤ', 'و').replace('ئ', 'ي')

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun tokenMatch(q: String, text: String): Boolean {
        if (text.contains(q)) return true
        val tol = when { q.length <= 3 -> 0; q.length <= 6 -> 1; else -> 2 }
        if (tol == 0) return false
        for (w in text.split(' ', '-', '_', ',', '\n', '(', ')')) {
            if (w.length < 2) continue
            if (kotlin.math.abs(w.length - q.length) <= tol && lev(w, q) <= tol) return true
            if (w.length > q.length && lev(w.take(q.length), q) <= tol) return true
        }
        return false
    }

    private val lyricCache = HashMap<Long, String>()
    private fun lyricsText(ctx: Context, id: Long): String = lyricCache.getOrPut(id) {
        LyricsStore.load(ctx, id)?.lines?.joinToString(" ") { it.text }?.let(::norm) ?: ""
    }

    fun search(ctx: Context, songs: List<Song>, query: String): List<Song> {
        val words = norm(query.trim()).split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val scored = ArrayList<Pair<Int, Song>>()
        for (s in songs) {
            val hay = norm(s.title + " " + s.artist + " " + s.album)
            if (words.all { tokenMatch(it, hay) }) {
                scored += (if (norm(s.title).contains(words[0])) 0 else 1) to s
            } else {
                val ly = lyricsText(ctx, s.id)
                if (ly.isNotEmpty() && words.all { tokenMatch(it, ly) }) scored += 2 to s
            }
        }
        return scored.sortedBy { it.first }.map { it.second }
    }
}

// ===================== ميلان الغلاف مع حركة الهاتف =====================
class Tilt { var x by mutableFloatStateOf(0f); var y by mutableFloatStateOf(0f) }

@Composable
fun rememberTilt(): Tilt {
    val ctx = LocalContext.current
    val t = remember { Tilt() }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val nx = (-e.values[0] / 6f).coerceIn(-1f, 1f)
                val ny = ((e.values[1] - 4.5f) / 6f).coerceIn(-1f, 1f)
                t.x += (nx - t.x) * 0.12f
                t.y += (ny - t.y) * 0.12f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm?.unregisterListener(l) }
    }
    return t
}

// ===================== الثيمات =====================
@Composable
fun ThemeDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val names = listOf("الافتراضي", "داكن عميق", "AMOLED أسود", "ألوان حسب الوقت")
    val wp = remember { ctx.getSharedPreferences("tm_widget", Context.MODE_PRIVATE) }
    var wAlpha by remember { mutableFloatStateOf(wp.getInt("alpha", 255) / 255f) }
    var wRadius by remember { mutableIntStateOf(wp.getInt("radius", 1)) }
    var wCover by remember { mutableStateOf(wp.getBoolean("cover", false)) }
    fun applyWidget() {
        wp.edit().putInt("alpha", (wAlpha * 255).toInt()).putInt("radius", wRadius).putBoolean("cover", wCover).apply()
        PlayerWidget.push(ctx, null); QuranWidget.push(ctx)
    }
    AlertDialog(
        onDismissRequest = onClose, containerColor = TM.Surface,
        title = { Text("الإعدادات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                names.forEachIndexed { i, n ->
                    Row(Modifier.fillMaxWidth().clickable { TM.applyMode(i) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(TM.mode == i, { TM.applyMode(i) })
                        Text(n)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("غلاف دائري يدور كأسطوانة", Modifier.weight(1f))
                    Switch(TM.vinyl, { TM.applyVinyl(it) })
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("انتقال متلاشٍ بين الأغاني")
                        Text("يخفت الصوت في نهاية الأغنية ويرتفع تدريجيًا في بداية التالية", color = TM.Muted, fontSize = 11.sp)
                    }
                    Switch(TM.fade, { TM.applyFade(it) })
                }
                Text("الويدجت", Modifier.padding(top = 16.dp), color = TM.VioletSoft, fontWeight = FontWeight.SemiBold)
                Text("الشفافية", Modifier.padding(top = 6.dp), fontSize = 13.sp, color = TM.Muted)
                Slider(wAlpha, { wAlpha = it }, valueRange = 0.2f..1f, onValueChangeFinished = { applyWidget() })
            }
        },
        confirmButton = { TextButton(onClose) { Text("تم", color = TM.VioletSoft) } }
    )
}

// ===================== أقسام الصفحة الرئيسية =====================
@Composable
private fun SongsRow(title: String, list: List<Song>, ui: PlayerUi) {
    if (list.isEmpty()) return
    SectionTitle(title)
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list.size, key = { list[it].id }) { i ->
            val s = list[i]
            Column(Modifier.width(120.dp).clickable { ui.play(list, i) }) {
                Cover(s, Modifier.size(120.dp), 14.dp)
                Text(s.title, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = TM.Muted)
            }
        }
    }
}

@Composable
fun HomeSections(songs: List<Song>, byId: Map<Long, Song>, ui: PlayerUi) {
    val fresh = remember(songs) { songs.sortedByDescending { it.added }.take(12) }
    val top = remember(songs, ui.plays) { songs.filter { (ui.plays[it.id] ?: 0) > 1 }.sortedByDescending { ui.plays[it.id] ?: 0 }.take(12) }
    Column(Modifier.padding(bottom = 8.dp)) {
        SongsRow("أُضيفت حديثًا", fresh, ui)
        SongsRow("الأكثر استماعًا", top, ui)
    }
}

// ===================== شاشة الفنان =====================
@Composable
fun ArtistScreen(artist: Artist, ui: PlayerUi, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    val songs = artist.songs
    val popular = remember(artist, ui.plays) {
        songs.sortedByDescending { ui.plays[it.id] ?: 0 }.take(5)
    }
    val albums = remember(artist) { songs.toAlbums() }
    LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } }
                Cover(songs.first(), Modifier.size(150.dp), 75.dp)
                Text(artist.name, Modifier.padding(top = 12.dp, start = 16.dp, end = 16.dp), style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("${songs.size} أغنية  ·  ${albums.size} ألبوم", color = TM.Muted, fontSize = 13.sp)
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button({ ui.play(songs, 0, false) }) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("تشغيل") }
                    FilledTonalButton({ ui.play(songs, 0, true) }) { Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("عشوائي") }
                }
            }
        }
        item { SectionTitle("الأشهر") }
        items(popular.size, key = { "p${popular[it].id}" }) { i -> SongRow(popular[i], popular[i].id == ui.currentId, ui.isPlaying) { ui.play(popular, i) } }
        if (albums.size > 1) item {
            SectionTitle("الألبومات")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(albums, key = { it.id }) { AlbumCard(it, ui, Modifier.width(148.dp)) }
            }
        }
        item { SectionTitle("كل الأغاني") }
        items(songs.size, key = { "a${songs[it].id}" }) { i -> SongRow(songs[i], songs[i].id == ui.currentId, ui.isPlaying) { ui.play(songs, i) } }
    }
}

// ===================== الألبومات الذكية =====================
@Composable
fun SmartAlbums(songs: List<Song>, ui: PlayerUi) {
    var open by remember { mutableIntStateOf(-1) }
    val most = remember(songs, ui.plays) { songs.filter { (ui.plays[it.id] ?: 0) > 0 }.sortedByDescending { ui.plays[it.id] ?: 0 }.take(50) }
    val recent = remember(songs) { songs.sortedByDescending { it.added }.take(50) }
    val downloaded = remember(songs) { songs.filter { it.path.contains("/TMusic/", true) }.sortedByDescending { it.added } }
    val sets = listOf(
        Triple("الأكثر استماعًا", most, Icons.Rounded.Whatshot),
        Triple("أُضيفت حديثًا", recent, Icons.Rounded.NewReleases),
        Triple("المنزَّلة", downloaded, Icons.Rounded.Download)
    )
    if (open >= 0) {
        val (name, list, _) = sets[open]
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ open = -1 }) { Icon(Icons.Rounded.ArrowBack, null) }
                Column {
                    Text(name, style = MaterialTheme.typography.titleLarge)
                    Text("${list.size} أغنية", color = TM.Muted, fontSize = 12.sp)
                }
            }
            if (list.isEmpty()) EmptyState(Icons.Rounded.LibraryMusic, "لا شيء هنا بعد", "ستمتلئ هذه القائمة تلقائيًا.")
            else EditableSongList(list, ui, null)
        }
        return
    }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        sets.forEachIndexed { i, (name, list, icon) ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(TM.Violet.copy(0.16f), TM.Blue.copy(0.10f))))
                    .clickable { open = i }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, Modifier.size(30.dp), tint = Color.White)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.Bold)
                    Text("${list.size} أغنية", color = TM.Muted, fontSize = 12.sp)
                }
                IconButton({ if (list.isNotEmpty()) ui.play(list, 0, false) }) { Icon(Icons.Rounded.PlayArrow, null) }
            }
        }
    }
}

// ===================== اكتشاف المكرر وحذفه =====================
@Composable
fun DuplicatesTab(songs: List<Song>, ui: PlayerUi) {
    val ctx = LocalContext.current
    val groups = remember(songs) {
        songs.filter { it.remoteUrl == null }
            .groupBy { Fuzzy.norm(it.title).trim() + "|" + Fuzzy.norm(it.artist).trim() }
            .values.filter { it.size > 1 }
    }
    // نُبقي النسخة الأطول مدة (والأقدم عند التساوي) ونحذف الباقي
    val extra = remember(groups) { groups.flatMap { g -> g.sortedWith(compareByDescending<Song> { it.duration }.thenBy { it.id }).drop(1) } }
    var confirm by remember { mutableStateOf(false) }
    fun finish() { extra.forEach { UserAlbums.purge(it.id) }; Mp3Dl.refreshLibrary() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) finish()
    }
    fun deleteAll() {
        if (Build.VERSION.SDK_INT >= 30) {
            launcher.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(ctx.contentResolver, extra.map { it.uri }).intentSender).build())
        } else {
            var ok = 0
            extra.forEach { s -> runCatching { if (ctx.contentResolver.delete(s.uri, null, null) > 0) ok++ } }
            if (ok > 0) finish()
            else android.widget.Toast.makeText(ctx, "تعذّر الحذف", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = TM.Surface,
        title = { Text("حذف ${extra.size} نسخة زائدة؟") },
        text = { Text("نُبقي نسخة واحدة من كل أغنية مكررة (الأطول مدة) ونحذف الباقي من الهاتف نهائيًا.", color = TM.Muted) },
        confirmButton = { TextButton({ confirm = false; deleteAll() }) { Text("حذف", color = Color(0xFFFF6B8A)) } },
        dismissButton = { TextButton({ confirm = false }) { Text("إلغاء") } }
    )
    if (groups.isEmpty()) { EmptyState(Icons.Rounded.CheckCircle, "لا توجد أغانٍ مكررة", "مكتبتك نظيفة."); return }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${groups.size} أغنية مكررة", Modifier.weight(1f), color = TM.Muted)
            Button({ confirm = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5486B), contentColor = Color.White)) { Text("حذف الزائد (${extra.size})") }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
            groups.forEach { g ->
                item(key = "h${g.first().id}") { SectionTitle(g.first().title) }
                items(g, key = { "d${it.id}" }) { s -> SongRow(s, s.id == ui.currentId, ui.isPlaying) { ui.play(g, g.indexOf(s)) } }
            }
        }
    }
}

// ===================== بطاقة مشاركة الأغنية (ستوري) =====================
suspend fun shareSongCard(ctx: Context, song: Song) {
    val art = Art.get(ctx, song)
    val frac = activeUi?.let { if (it.currentId == song.id && it.duration > 0) (it.position.toFloat() / it.duration).coerceIn(0f, 1f) else null } ?: 0.4f
    val file = withContext(Dispatchers.Default) {
        val w = 1080; val h = 1920
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (art != null) {
            val small = Bitmap.createScaledBitmap(art, 24, 24, true)
            c.drawBitmap(small, null, RectF(-200f, 0f, w + 200f, h.toFloat()), p)
        } else {
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF3A2A7A.toInt(), 0xFF101028.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        }
        p.color = 0x99000000.toInt(); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        // الغلاف
        val box = RectF(160f, 380f, 920f, 1140f)
        p.color = 0x55000000; c.drawRoundRect(RectF(box.left, box.top + 20, box.right, box.bottom + 20), 48f, 48f, p)
        if (art != null) {
            val clip = android.graphics.Path().apply { addRoundRect(box, 48f, 48f, android.graphics.Path.Direction.CW) }
            c.save(); c.clipPath(clip); c.drawBitmap(art, null, box, p); c.restore()
        } else { p.color = 0xFF2B1B55.toInt(); c.drawRoundRect(box, 48f, 48f, p) }
        // النص
        val tp = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; textSize = 68f }
        c.drawText(android.text.TextUtils.ellipsize(song.title, tp, 880f, android.text.TextUtils.TruncateAt.END).toString(), w / 2f, 1260f, tp)
        tp.typeface = Typeface.DEFAULT; tp.textSize = 46f; tp.color = 0xCCFFFFFF.toInt()
        c.drawText(android.text.TextUtils.ellipsize(song.artist, tp, 880f, android.text.TextUtils.TruncateAt.END).toString(), w / 2f, 1340f, tp)
        // خط التقدّم بالنجوم
        val n = 16; val lit = (frac * n).toInt()
        tp.textSize = 52f
        for (i in 0 until n) {
            tp.color = if (i <= lit) 0xFFFFE08A.toInt() else 0x55FFFFFF
            c.drawText("★", 160f + 760f * (i + 0.5f) / n, 1470f, tp)
        }
        tp.color = 0xAAFFFFFF.toInt(); tp.textSize = 40f; tp.typeface = Typeface.DEFAULT_BOLD
        c.drawText("T Music", w / 2f, 1720f, tp)
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        File(dir, "card.png").also { f -> f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }
    val uri = FileProvider.getUriForFile(ctx, "com.tmusic.app.files", file)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "مشاركة البطاقة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

// ===================== الوضع السينمائي: أشرطة سوداء + كلمات كترجمة فيلم تتلوّن كلمة بكلمة =====================
@Composable
fun CinemaMode(song: Song, lyrics: Lyrics?, ui: PlayerUi, onClose: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onClose)
    val lines = lyrics?.lines.orEmpty()
    val synced = lyrics?.synced == true
    val idx = if (synced) lines.indexOfLast { it.timeMs <= ui.position } else -1
    Column(Modifier.fillMaxSize().background(Color.Black).clickable { onClose() }) {
        Box(Modifier.fillMaxWidth().height(86.dp), contentAlignment = Alignment.BottomCenter) {
            Text(song.title + "  ·  " + song.artist, Modifier.padding(bottom = 10.dp, start = 20.dp, end = 20.dp), color = Color.White.copy(0.45f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Cover(song, Modifier.fillMaxSize().graphicsLayer { alpha = 0.55f }, 0.dp)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.65f)))))
            val line = lines.getOrNull(idx)
            Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 24.dp, vertical = 28.dp)) {
                if (line != null) {
                    val t0 = line.timeMs
                    val t1 = lines.getOrNull(idx + 1)?.timeMs ?: (t0 + 5000)
                    val f = ((ui.position - t0).toFloat() / minOf(t1 - t0, 8000L).coerceAtLeast(1L)).coerceIn(0f, 1f)
                    val words = line.text.split(' ').filter { it.isNotEmpty() }
                    val lit = f * words.size
                    val txt = buildAnnotatedString {
                        words.forEachIndexed { i, w ->
                            val a = (lit - i).coerceIn(0f, 1f)
                            withStyle(SpanStyle(color = Color.White.copy(alpha = 0.35f + 0.65f * a))) { append(w) }
                            if (i < words.lastIndex) append(" ")
                        }
                    }
                    Text(txt, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 36.sp, modifier = Modifier.fillMaxWidth())
                } else if (!synced) {
                    Text(if (lyrics == null) "لا توجد كلمات لهذه الأغنية" else "الكلمات غير متزامنة (تحتاج تنسيق LRC)", color = Color.White.copy(0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        Spacer(Modifier.fillMaxWidth().height(86.dp))
    }
}

// ===================== قائمة أغانٍ قابلة للتحديد المتعدد والسحب للترتيب =====================
@Composable
fun EditableSongList(songs: List<Song>, ui: PlayerUi, album: UAlbum?) {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf(false) }
    val sel = remember { mutableStateListOf<Long>() }
    var addDlg by remember { mutableStateOf(false) }
    var delConfirm by remember { mutableStateOf(false) }
    val rowPx = with(LocalDensity.current) { 66.dp.toPx() }
    val chosen = songs.filter { it.id in sel }

    fun afterDelete() { sel.toList().forEach { UserAlbums.purge(it) }; sel.clear(); editing = false; Mp3Dl.refreshLibrary() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) afterDelete()
    }
    fun deleteChosen() {
        val local = chosen.filter { it.remoteUrl == null }
        if (local.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            launcher.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(ctx.contentResolver, local.map { it.uri }).intentSender).build())
        } else {
            var ok = 0
            local.forEach { s -> runCatching { if (ctx.contentResolver.delete(s.uri, null, null) > 0) ok++ } }
            if (ok > 0) afterDelete() else android.widget.Toast.makeText(ctx, "تعذّر الحذف", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    if (delConfirm) AlertDialog(
        onDismissRequest = { delConfirm = false }, containerColor = TM.Surface,
        title = { Text("حذف ${chosen.size} أغنية من الهاتف؟") },
        text = { Text("ستُحذف الملفات نهائيًا.", color = TM.Muted) },
        confirmButton = { TextButton({ delConfirm = false; deleteChosen() }) { Text("حذف", color = Color(0xFFFF6B8A)) } },
        dismissButton = { TextButton({ delConfirm = false }) { Text("إلغاء") } }
    )
    if (addDlg) AlertDialog(
        onDismissRequest = { addDlg = false }, containerColor = TM.Surface,
        title = { Text("إضافة ${chosen.size} إلى ألبوم") },
        text = {
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                item { TextButton({ val n = UserAlbums.create("ألبوم جديد"); chosen.forEach { UserAlbums.add(n, it.id) }; addDlg = false; sel.clear(); editing = false }) { Text("+ ألبوم جديد", color = TM.VioletSoft) } }
                items(UserAlbums.list.toList(), key = { it.id }) { al ->
                    TextButton({ chosen.forEach { UserAlbums.add(al, it.id) }; addDlg = false; sel.clear(); editing = false }) { Text(al.name) }
                }
            }
        },
        confirmButton = { TextButton({ addDlg = false }) { Text("إلغاء") } }
    )

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (editing) {
                Text("${sel.size} محدّدة", Modifier.weight(1f), color = TM.VioletSoft)
                TextButton({ if (sel.size == songs.size) sel.clear() else { sel.clear(); sel.addAll(songs.map { it.id }) } }) { Text("الكل") }
                TextButton({ editing = false; sel.clear() }) { Text("تم") }
            } else {
                Spacer(Modifier.weight(1f))
                TextButton({ editing = true }) { Icon(Icons.Rounded.Checklist, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(if (album != null) "تحديد / ترتيب" else "تحديد") }
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(songs.size, key = { songs[it].id }) { i ->
                val s = songs[i]
                if (!editing) {
                    SongRow(s, s.id == ui.currentId, ui.isPlaying, album) { ui.play(songs, i) }
                } else {
                    var acc by remember(s.id) { mutableFloatStateOf(0f) }
                    Row(
                        Modifier.fillMaxWidth().height(66.dp).padding(horizontal = 8.dp)
                            .clickable { if (s.id in sel) sel.remove(s.id) else sel.add(s.id) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(s.id in sel, { if (it) sel.add(s.id) else sel.remove(s.id) })
                        Cover(s, Modifier.size(46.dp), 10.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = TM.Muted, fontSize = 12.sp)
                        }
                        if (album != null) Icon(
                            Icons.Rounded.DragHandle, null, tint = TM.Muted,
                            modifier = Modifier.size(40.dp).padding(8.dp).pointerInput(s.id) {
                                detectDragGestures(
                                    onDragEnd = { acc = 0f }, onDragCancel = { acc = 0f },
                                    onDrag = { ch, d ->
                                        ch.consume(); acc += d.y
                                        val idx = album.songIds.indexOf(s.id)
                                        if (acc > rowPx && idx < album.songIds.lastIndex) { UserAlbums.move(album, idx, idx + 1); acc -= rowPx }
                                        else if (acc < -rowPx && idx > 0) { UserAlbums.move(album, idx, idx - 1); acc += rowPx }
                                    }
                                )
                            }
                        )
                    }
                }
            }
        }
        if (editing && sel.isNotEmpty()) Row(
            Modifier.fillMaxWidth().background(TM.Raised).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton({ addDlg = true }) { Icon(Icons.Rounded.PlaylistAdd, null); Spacer(Modifier.width(4.dp)); Text("لألبوم") }
            if (album != null) TextButton({ chosen.forEach { UserAlbums.remove(album, it.id) }; sel.clear() }) { Icon(Icons.Rounded.RemoveCircleOutline, null); Spacer(Modifier.width(4.dp)); Text("إزالة") }
            TextButton({ delConfirm = true }) { Icon(Icons.Rounded.DeleteOutline, null, tint = Color(0xFFFF6B8A)); Spacer(Modifier.width(4.dp)); Text("حذف", color = Color(0xFFFF6B8A)) }
        }
    }
}

// ===================== تعبئة الغلاف والفنان تلقائيًا (iTunes) =====================
private fun itunes(term: String): org.json.JSONObject? = try {
    val u = java.net.URL("https://itunes.apple.com/search?media=music&entity=song&limit=3&term=" + java.net.URLEncoder.encode(term, "UTF-8"))
    val c = u.openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 10000; c.readTimeout = 15000
    val txt = try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    org.json.JSONObject(txt)
} catch (e: Exception) { null }

@Composable
fun MetaFixTab(songs: List<Song>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val local = remember(songs) { songs.filter { it.remoteUrl == null } }
    var noArtist by remember { mutableStateOf(local.filter { it.artist == "فنان غير معروف" }) }
    var noCover by remember { mutableStateOf<List<Song>?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var done by remember { mutableIntStateOf(0) }
    var fixedCovers by remember { mutableIntStateOf(0) }
    var fixedArtists by remember { mutableIntStateOf(0) }
    LaunchedEffect(local) {
        scanning = true
        noCover = withContext(Dispatchers.IO) { local.filter { Art.get(ctx, it) == null } }
        scanning = false
    }
    val todo = remember(noArtist, noCover) { (noArtist + (noCover ?: emptyList())).distinctBy { it.id } }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إصلاح الأغلفة والفنانين", style = MaterialTheme.typography.titleLarge)
        Text(if (scanning) "جارٍ الفحص…" else "بدون غلاف: ${noCover?.size ?: 0}   ·   بدون فنان: ${noArtist.size}", color = TM.Muted)
        if (running) {
            LinearProgressIndicator(progress = { if (todo.isEmpty()) 1f else done.toFloat() / todo.size }, modifier = Modifier.fillMaxWidth(), color = TM.Violet)
            Text("$done / ${todo.size}   ·   أغلفة: $fixedCovers   فنانون: $fixedArtists", color = TM.VioletSoft)
        }
        Button(
            onClick = {
                running = true; done = 0; fixedCovers = 0; fixedArtists = 0
                scope.launch {
                    val meta = ctx.applicationContext.getSharedPreferences("tm_meta", Context.MODE_PRIVATE)
                    val coverSet = noCover?.map { it.id }?.toSet() ?: emptySet()
                    for (s in todo) {
                        withContext(Dispatchers.IO) {
                            val needArtist = s.artist == "فنان غير معروف"
                            val term = if (needArtist) s.title else s.title + " " + s.artist
                            val r = itunes(term)?.optJSONArray("results")
                            var hit: org.json.JSONObject? = null
                            if (r != null) for (i in 0 until r.length()) {
                                val o = r.getJSONObject(i)
                                if (Fuzzy.similar(o.optString("trackName"), s.title)) { hit = o; break }
                            }
                            if (hit != null) {
                                if (needArtist) {
                                    val a = hit.optString("artistName")
                                    if (a.isNotBlank()) { meta.edit().putString("a${s.id}", a).apply(); fixedArtists++ }
                                }
                                if (s.id in coverSet) {
                                    val url = hit.optString("artworkUrl100").replace("100x100", "600x600")
                                    if (url.isNotBlank()) Art.remote(url)?.let { Art.putCover(ctx, s.id, it); fixedCovers++ }
                                }
                            }
                        }
                        done++
                    }
                    running = false
                    if (fixedArtists > 0) Mp3Dl.refreshLibrary()
                    noCover = withContext(Dispatchers.IO) { (noCover ?: emptyList()).filter { Art.get(ctx, it) == null } }
                    noArtist = noArtist.filter { meta.getString("a${it.id}", null) == null }
                }
            },
            enabled = !running && !scanning && todo.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (todo.isEmpty() && !scanning) "كل شيء مكتمل" else "إصلاح الكل (${todo.size})") }
        val noLyrics = remember(local) { local.filter { LyricsStore.load(ctx, it.id) == null } }
        var lyrRun by remember { mutableStateOf(false) }
        var lyrDone by remember { mutableIntStateOf(0) }
        var lyrOk by remember { mutableIntStateOf(0) }
        OutlinedButton(
            onClick = {
                lyrRun = true; lyrDone = 0; lyrOk = 0
                scope.launch {
                    for (s in noLyrics) { if (Lrclib.fetch(ctx, s)) lyrOk++; lyrDone++; kotlinx.coroutines.delay(150) }
                    lyrRun = false
                }
            },
            enabled = !lyrRun && noLyrics.isNotEmpty(), modifier = Modifier.fillMaxWidth()
        ) { Text(if (lyrRun) "جلب الكلمات $lyrDone / ${noLyrics.size} (وُجد $lyrOk)" else "جلب الكلمات للأغاني الناقصة (${noLyrics.size})") }
        Text("يبحث عن الغلاف والفنان عبر الإنترنت (iTunes) ويحفظهما داخل التطبيق دون تعديل ملفاتك. يحتاج اتصالًا بالإنترنت.", color = TM.Muted, fontSize = 12.sp)
    }
}

// ===================== جلب الكلمات من LRCLIB =====================
object Lrclib {
    private const val BROWSER = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private fun get(url: String, ua: String = "TMusic/1.0"): String? = try {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Language", "en,ar;q=0.8")
        c.instanceFollowRedirects = true
        c.connectTimeout = 10000; c.readTimeout = 15000
        try { if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null } finally { c.disconnect() }
    } catch (e: Exception) { null }

    private fun org.json.JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)
    private fun enc(x: String) = java.net.URLEncoder.encode(x, "UTF-8")

    /** ينظّف العنوان من (Slowed) و[Official Video] و- Topic وغيرها. */
    private fun clean(t: String): String {
        var x = t.replace(Regex("""\s*[\(\[][^)\]]*(slowed|reverb|sped|speed|official|lyric|video|audio|visuali[sz]er|remaster|nightcore|8d|mv|hd|4k|music)[^)\]]*[\)\]]""", RegexOption.IGNORE_CASE), "")
        x = x.replace(Regex("""(?i)\b(slowed( ?\+? ?reverb)?|sped up|official (music )?video|lyrics?)\b"""), "")
        x = x.replace(Regex("""(?i)\s*[-–|]\s*topic$"""), "")
        return x.replace(Regex("\\s+"), " ").trim(' ', '-', '–', '|')
    }

    private fun lrc(artist: String?, title: String, sec: Int): String? {
        var o: org.json.JSONObject? = null
        if (!artist.isNullOrBlank()) o = get("https://lrclib.net/api/get?artist_name=${enc(artist)}&track_name=${enc(title)}&duration=$sec")
            ?.let { runCatching { org.json.JSONObject(it) }.getOrNull() }
        if (o == null || (o.str("syncedLyrics").isBlank() && o.str("plainLyrics").isBlank())) {
            val arr = get("https://lrclib.net/api/search?q=${enc(if (artist.isNullOrBlank()) title else "$title $artist")}")
                ?.let { runCatching { org.json.JSONArray(it) }.getOrNull() }
            var best: org.json.JSONObject? = null
            if (arr != null) {
                val all = (0 until arr.length()).map { arr.getJSONObject(it) }
                best = all.firstOrNull { it.str("syncedLyrics").isNotBlank() && kotlin.math.abs(it.optDouble("duration", 0.0) - sec) <= 5 }
                    ?: all.firstOrNull { it.str("syncedLyrics").isNotBlank() }
                    ?: all.firstOrNull { it.str("plainLyrics").isNotBlank() }
            }
            o = best
        }
        return o?.let { it.str("syncedLyrics").ifBlank { it.str("plainLyrics") } }?.takeIf { it.isNotBlank() }
    }

    // ---------- Genius (احتياطي: كلمات كاملة بدون توقيت) ----------
    private fun nz(x: String) = x.lowercase().filter { it.isLetterOrDigit() }

    private fun geniusText(html: String): String {
        val key = "data-lyrics-container=\"true\""
        val sb = StringBuilder()
        var from = 0
        while (true) {
            val k = html.indexOf(key, from)
            if (k < 0) break
            val st = html.indexOf('>', k) + 1
            var depth = 1; var p = st; var end = -1
            while (true) {
                val o = html.indexOf("<div", p); val c = html.indexOf("</div>", p)
                if (c < 0) break
                if (o in 0 until c) { depth++; p = o + 4 } else { depth--; if (depth == 0) { end = c; break }; p = c + 6 }
            }
            if (end < 0) break
            sb.append(html, st, end).append("<br/>")
            from = end
        }
        val marked = sb.toString().replace(Regex("(?i)<br\\s*/?>"), "@@NL@@")
        val txt = android.text.Html.fromHtml(marked, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace("@@NL@@", "\n")
        return txt.lines().map { it.trim() }.filter { !(it.startsWith("[") && it.endsWith("]")) }
            .joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private fun genius(q: String, title: String): String? {
        val j = get("https://genius.com/api/search/song?per_page=5&q=${enc(q)}", BROWSER)
            ?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return null
        val hits = j.optJSONObject("response")?.optJSONArray("sections")?.optJSONObject(0)?.optJSONArray("hits") ?: return null
        val nt = nz(title)
        for (i in 0 until hits.length()) {
            val r = hits.getJSONObject(i).optJSONObject("result") ?: continue
            val gt = nz(r.str("title"))
            if (nt.isNotEmpty() && gt.isNotEmpty() && !(gt.contains(nt) || nt.contains(gt))) continue
            val url = r.str("url")
            if (url.isBlank()) continue
            val html = get(url, BROWSER) ?: continue
            val t = geniusText(html)
            if (t.length > 40) return t
        }
        return null
    }

    suspend fun fetch(ctx: Context, s: Song): Boolean = withContext(Dispatchers.IO) {
        val known = s.artist != "فنان غير معروف"
        val sec = (s.duration / 1000).toInt()
        val t0 = clean(s.title)
        // احتمالات (فنان، عنوان): الأصلي، ثم "فنان - عنوان" المضمّن داخل العنوان
        val variants = mutableListOf<Pair<String?, String>>()
        if (known) variants += s.artist to t0
        val parts = t0.split(" - ", " – ", limit = 2)
        if (parts.size == 2) {
            variants += clean(parts[0]) to clean(parts[1])
            variants += clean(parts[1]) to clean(parts[0])
        }
        variants += null to t0
        var raw: String? = null
        for ((a, t) in variants) { raw = lrc(a, t, sec); if (raw != null) break }
        // لو وُجدت الكلمات بلا توقيت أو لم تُوجد، جرّب Genius
        val needGenius = raw == null || !TS.containsMatchIn(raw)
        if (needGenius) {
            for ((a, t) in variants) {
                val g = genius(if (a.isNullOrBlank()) t else "$a $t", t) ?: continue
                if (raw == null || g.length > raw.length) raw = g
                break
            }
        }
        if (raw.isNullOrBlank()) false else { LyricsStore.save(ctx, s.id, raw); true }
    }
}
