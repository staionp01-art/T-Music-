package com.tmusic.app

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * خدمة التشغيل. صارت MediaLibraryService ليتصفّح Android Auto مكتبتك (الأغاني، الألبومات، الفنانون)،
 * وتُشغّل تلقائيًا عند توصيل سماعات/بلوتوث إن كان الخيار مفعّلًا.
 */
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private var audioManager: AudioManager? = null
    private var devReadyAt = 0L
    private var songsCache: List<Song> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private var callPoll: Runnable? = null

    /** بعد انتهاء المكالمة (أو رفضها) يستأنف التشغيل تلقائيًا، حتى لو فقد المشغّل التركيز نهائيًا. */
    private fun resumeAfterCall() {
        callPoll?.let { handler.removeCallbacks(it) }
        val am = audioManager ?: return
        val started = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                val p = session?.player ?: return
                if (System.currentTimeMillis() - started > 3 * 60 * 60_000L) return
                if (am.mode == AudioManager.MODE_NORMAL) { if (!p.isPlaying) p.play() }
                else handler.postDelayed(this, 1500)
            }
        }
        callPoll = r
        handler.postDelayed(r, 1500)
    }

    private fun songs(): List<Song> {
        if (songsCache.isEmpty()) songsCache = runCatching { loadSongs(applicationContext) }.getOrDefault(emptyList())
        return songsCache
    }

    private fun songItem(s: Song): MediaItem = MediaItem.Builder()
        .setUri(s.uri).setMediaId(s.id.toString())
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album)
                .setArtworkUri(s.art).setIsBrowsable(false).setIsPlayable(true).build()
        ).build()

    private fun folder(id: String, title: String): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setIsBrowsable(true).setIsPlayable(false).build())
        .build()

    private val libCallback = object : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession, browser: MediaSession.ControllerInfo, params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(folder("root", "T Music"), params))

        override fun onGetChildren(
            session: MediaLibrarySession, browser: MediaSession.ControllerInfo,
            parentId: String, page: Int, pageSize: Int, params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            songsCache = runCatching { loadSongs(applicationContext) }.getOrDefault(songsCache)
            val all = songsCache
            val items: List<MediaItem> = when {
                parentId == "root" -> listOf(folder("recent", "أُضيفت حديثًا"), folder("all", "كل الأغاني"), folder("fav", "المفضلة"))
                parentId == "all" -> all.take(500).map(::songItem)
                parentId == "recent" -> all.sortedByDescending { it.added }.take(50).map(::songItem)
                parentId == "fav" -> {
                    val byId = all.associateBy { it.id }
                    Favorites.init(applicationContext)
                    Favorites.songs(byId).filter { it.remoteUrl == null }.map(::songItem)
                }
                else -> emptyList()
            }
            val from = minOf(page.toLong() * pageSize, items.size.toLong()).toInt()
            val to = minOf(from.toLong() + pageSize, items.size.toLong()).toInt()
            return Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items.subList(from, to)), params))
        }

        override fun onGetItem(
            session: MediaLibrarySession, browser: MediaSession.ControllerInfo, mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val s = mediaId.toLongOrNull()?.let { id -> songs().firstOrNull { it.id == id } }
            return if (s != null) Futures.immediateFuture(LibraryResult.ofItem(songItem(s), null))
            else Futures.immediateFuture(LibraryResult.ofItem(folder(mediaId, mediaId), null))
        }

        /** عناصر Android Auto تصل بمعرّفها فقط؛ نحوّلها إلى عناصر قابلة للتشغيل (برابطها). */
        override fun onAddMediaItems(
            mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val out = mediaItems.map { mi ->
                if (mi.localConfiguration != null) mi
                else mi.mediaId.toLongOrNull()?.let { id -> songs().firstOrNull { it.id == id } }?.let(::songItem) ?: mi
            }.toMutableList()
            return Futures.immediateFuture(out)
        }
    }

    /** تشغيل تلقائي عند توصيل سماعات سلكية أو بلوتوث (A2DP) أو USB. */
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            if (!AppPrefs.autoPlayOnConnect || System.currentTimeMillis() < devReadyAt) return
            val ok = addedDevices?.any {
                it.isSink && (it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_USB_HEADSET)
            } == true
            val p = session?.player ?: return
            if (ok && p.mediaItemCount > 0 && !p.isPlaying) p.play()
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        AppPrefs.init(applicationContext)
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        Eq.attach(applicationContext, player.audioSessionId)
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Eq.attach(applicationContext, audioSessionId) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS) {
                    // إن كان السبب مكالمة (وضع الصوت ليس عاديًا) فانتظر نهايتها ثم أكمل
                    handler.postDelayed({
                        val m = audioManager?.mode ?: AudioManager.MODE_NORMAL
                        if (m != AudioManager.MODE_NORMAL) resumeAfterCall()
                    }, 800)
                } else if (playWhenReady || reason == Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST) {
                    callPoll?.let { handler.removeCallbacks(it) }; callPoll = null
                }
            }
        })
        session = MediaLibrarySession.Builder(this, player, libCallback).build()
        // إشعار ملوّن بلون الأغنية + إضافات سامسونج/أندرويد 16 للشريحة العلوية
        setMediaNotificationProvider(LiveMediaProvider(this))
        // الدالة تُستدعى فورًا للأجهزة الموصولة أصلًا، فنتجاهل أول ثانيتين
        devReadyAt = System.currentTimeMillis() + 2000L
        runCatching { audioManager?.registerAudioDeviceCallback(deviceCb, Handler(Looper.getMainLooper())) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.tmusic.app.SEEK") {
            val p = session?.player
            if (p == null || p.mediaItemCount == 0) { stopSelf(startId); return START_NOT_STICKY }
            val d = p.duration
            if (d != C.TIME_UNSET && d > 0) {
                val pos = (d * intent.getFloatExtra("f", 0f)).toLong()
                p.seekTo(pos)
                PlayerWidget.pushProgress(applicationContext, pos, d)
            }
            return START_NOT_STICKY
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onDestroy() {
        callPoll?.let { handler.removeCallbacks(it) }
        runCatching { audioManager?.unregisterAudioDeviceCallback(deviceCb) }
        AppState.onChange = null
        session?.run { player.release(); release() }
        session = null
        Eq.release()
        super.onDestroy()
    }
}
