package com.tmusic.app

import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player

/** وضع السيارة بأسلوب CarPlay: غلاف كبير، عنوان مقروء من بعيد، شريط تقدّم سميك، وأزرار ضخمة. */
object CarMode {
    var on by mutableStateOf(false)
}

@Composable
fun CarModeOverlay(song: Song?, ui: PlayerUi) {
    if (!CarMode.on) return
    val ctx = LocalContext.current
    BackHandler { CarMode.on = false }
    DisposableEffect(Unit) {
        val w = ctx.hostActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    val cfg = LocalConfiguration.current
    val land = cfg.screenWidthDp > cfg.screenHeightDp
    Box(Modifier.fillMaxSize().background(Color.Black).clickable(enabled = false) {}) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp, vertical = 14.dp)) {
            // الشريط العلوي: زر الإنهاء على اليمين
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF1C1C1E)).clickable { CarMode.on = false }
                        .padding(horizontal = 22.dp, vertical = 14.dp),
                    Alignment.Center
                ) { Text("إنهاء", color = TM.Violet, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.weight(1f))
            }
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Cover(song, Modifier.fillMaxHeight(0.82f).aspectRatio1(), 28.dp)
                    Spacer(Modifier.width(28.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        CarInfo(song, TextAlign.Start)
                        Spacer(Modifier.height(18.dp))
                        CarSeek(ui)
                        Spacer(Modifier.height(18.dp))
                        CarControls(ui, small = false)
                    }
                }
            } else {
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth(), Alignment.Center) { Cover(song, Modifier.fillMaxWidth(0.72f).aspectRatio1(), 32.dp) }
                Spacer(Modifier.height(24.dp))
                CarInfo(song, TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                CarSeek(ui)
                Spacer(Modifier.weight(1f))
                CarControls(ui, small = false)
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

private fun Modifier.aspectRatio1(): Modifier = this.then(Modifier.aspectRatio(1f))

@Composable
private fun CarInfo(song: Song?, align: TextAlign) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (align == TextAlign.Center) Alignment.CenterHorizontally else Alignment.Start) {
        Text(
            song?.title ?: "لا شيء قيد التشغيل", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold,
            textAlign = align, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 38.sp, modifier = Modifier.fillMaxWidth()
        )
        if (song != null) Text(
            song.artist, color = TM.Muted, fontSize = 22.sp, textAlign = align, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        )
    }
}

/** شريط تقدّم سميك يُلمَس أو يُسحب للتقديم، مع الوقت المنقضي والمتبقي. */
@Composable
private fun CarSeek(ui: PlayerUi) {
    val frac = if (ui.duration > 0) (ui.position.toFloat() / ui.duration).coerceIn(0f, 1f) else 0f
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                Modifier.fillMaxWidth().height(36.dp)
                    .pointerInput(ui.duration) {
                        detectTapGestures { o -> if (ui.duration > 0) ui.seek((o.x / size.width * ui.duration).toLong().coerceIn(0L, ui.duration)) }
                    }
                    .pointerInput(ui.duration) {
                        detectHorizontalDragGestures { change, _ ->
                            change.consume()
                            if (ui.duration > 0) ui.seek((change.position.x / size.width * ui.duration).toLong().coerceIn(0L, ui.duration))
                        }
                    },
                Alignment.CenterStart
            ) {
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF2C2C2E)))
                Box(Modifier.fillMaxWidth(frac).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color.White))
            }
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(ui.position), color = TM.Muted, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text("-" + fmt((ui.duration - ui.position).coerceAtLeast(0L)), color = TM.Muted, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun CarControls(ui: PlayerUi, small: Boolean) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            CarButton(if (ui.shuffle) Icons.Rounded.Shuffle else Icons.Rounded.Shuffle, 84.dp, 38.dp, if (ui.shuffle) TM.Violet else Color(0xFF1C1C1E), "عشوائي", tint = Color.White) { ui.toggleShuffle() }
            CarButton(Icons.Rounded.SkipPrevious, 104.dp, 58.dp, Color(0xFF1C1C1E), "السابق") { ui.previous() }
            CarButton(
                if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, 132.dp, 80.dp, Color.White,
                if (ui.isPlaying) "إيقاف" else "تشغيل", tint = Color.Black
            ) { ui.togglePlay() }
            CarButton(Icons.Rounded.SkipNext, 104.dp, 58.dp, Color(0xFF1C1C1E), "التالي") { ui.next() }
            CarButton(
                if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, 84.dp, 38.dp,
                if (ui.repeat != Player.REPEAT_MODE_OFF) TM.Violet else Color(0xFF1C1C1E), "تكرار", tint = Color.White
            ) { ui.cycleRepeat() }
        }
    }
}

@Composable
private fun CarButton(icon: ImageVector, box: Dp, iconSize: Dp, bg: Color, desc: String, tint: Color = Color.White, onClick: () -> Unit) {
    Box(Modifier.size(box).clip(CircleShape).background(bg).clickable(onClick = onClick), Alignment.Center) {
        Icon(icon, desc, Modifier.size(iconSize), tint = tint)
    }
}
