package com.tmusic.app

import android.animation.ValueAnimator
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.palette.graphics.Palette
import com.google.common.collect.ImmutableList
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** إعداد «جزيرة T» (تظهر فوق التطبيقات الأخرى أثناء التشغيل). */
object IslandPrefs {
    var enabled by mutableStateOf(false)
    private var inited = false
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        enabled = ctx.applicationContext.getSharedPreferences("tm_island", Context.MODE_PRIVATE).getBoolean("on", false)
    }
    fun set(ctx: Context, v: Boolean) {
        enabled = v
        ctx.applicationContext.getSharedPreferences("tm_island", Context.MODE_PRIVATE).edit().putBoolean("on", v).apply()
        AppState.onChange?.invoke()
    }
}

/** هل التطبيق ظاهر الآن؟ (الجزيرة تظهر فقط عندما تكون خارج التطبيق) */
object AppState {
    @Volatile var foreground = false
    var onChange: (() -> Unit)? = null
    fun set(v: Boolean) { foreground = v; Handler(Looper.getMainLooper()).post { onChange?.invoke() } }
}

/** تحميل غلاف الأغنية بحجم صغير من بيانات الوسائط (بدون شبكة). */
object ArtLoader {
    fun load(ctx: Context, md: MediaMetadata, max: Int): Bitmap? {
        try {
            val data = md.artworkData
            if (data != null) return sample(BitmapFactory.decodeByteArray(data, 0, data.size), max)
            val uri = md.artworkUri ?: return null
            if (uri.scheme == "http" || uri.scheme == "https") return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (_: Throwable) { return null }
    }

    private fun sample(b: Bitmap?, max: Int): Bitmap? {
        if (b == null) return null
        val m = maxOf(b.width, b.height)
        if (m <= max) return b
        val f = max / m.toFloat()
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    fun accent(b: Bitmap?, fallback: Int = 0xFFB388FF.toInt()): Int {
        if (b == null) return fallback
        return try {
            val p = Palette.from(b).maximumColorCount(12).generate()
            p.getVibrantColor(p.getDominantColor(fallback))
        } catch (_: Throwable) { fallback }
    }
}

/**
 * إشعار الوسائط الملوّن بلون الأغنية + إضافات «النشاط الجاري» لسامسونج (شريحة شريط الحالة / Now Bar)
 * + طلب «الإشعار المميّز» في أندرويد 16 (الجزيرة على الأجهزة التي تدعمه). الأجهزة غير المدعومة تتجاهل الإضافات بلا أي ضرر.
 */
object LiveChip {
    fun decorate(ctx: Context, n: Notification, player: Player) {
        val md = player.mediaMetadata
        val title = md.title?.toString().orEmpty()
        val artist = md.artist?.toString().orEmpty()
        val color = ArtLoader.accent(ArtLoader.load(ctx, md, 64))
        n.color = color
        n.flags = n.flags or Notification.FLAG_ONLY_ALERT_ONCE
        // نتيجة الفحص: إشعار الوسائط (MediaStyle) غير قابل للترقية إلى Live Update في أندرويد 37،
        // لذا نجرّب مسار سامسونج لشريحة النشاط الجاري (بدون setColorized لأنه قد يمنع العرض).
        val e = n.extras
        e.putInt("android.ongoingActivityNoti.style", 1)
        e.putString("android.ongoingActivityNoti.primaryInfo", title)
        e.putString("android.ongoingActivityNoti.secondaryInfo", artist)
        e.putString("android.ongoingActivityNoti.nowbarPrimaryInfo", title)
        e.putString("android.ongoingActivityNoti.nowbarSecondaryInfo", artist)
        e.putString("android.ongoingActivityNoti.chipExpandedText", title)
        e.putInt("android.ongoingActivityNoti.chipBgColor", color)
        runCatching { e.putParcelable("android.ongoingActivityNoti.chipIcon", Icon.createWithResource(ctx, R.drawable.ic_stat_tmusic)) }
    }
}

class LiveMediaProvider(private val ctx: Context) : MediaNotification.Provider {
    private val base = DefaultMediaNotificationProvider(ctx).apply {
        setSmallIcon(R.drawable.ic_stat_tmusic)
        // قناة بأهمية «افتراضية» بدل «منخفضة» (الافتراضية في media3)؛ قد تشترطها سامسونج لعرض الشريحة. بلا صوت ولا اهتزاز.
        if (Build.VERSION.SDK_INT >= 26) runCatching {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (nm.getNotificationChannel("tm_media_v2") == null) {
                val ch = android.app.NotificationChannel("tm_media_v2", "تشغيل الموسيقى", android.app.NotificationManager.IMPORTANCE_DEFAULT)
                ch.setSound(null, null); ch.enableVibration(false); ch.setShowBadge(false)
                nm.createNotificationChannel(ch)
            }
            setChannelId("tm_media_v2")
        }
    }

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val mn = base.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        runCatching { LiveChip.decorate(ctx, mn.notification, mediaSession.player) }
        return mn
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        base.handleCustomCommand(session, action, extras)
}

private class BarsView(c: Context) : View(c) {
    var color = Color.WHITE
    var active = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f
        val w = width / 5f
        for (i in 0 until 3) {
            val h = if (active) height * (0.35f + 0.65f * abs(sin(t * (3f + i * 1.3f) + i))) else height * 0.3f
            p.color = color
            cv.drawRoundRect(i * 2 * w, height - h, i * 2 * w + w, height.toFloat(), w / 2f, w / 2f, p)
        }
        if (active) postInvalidateOnAnimation()
    }
}

/**
 * «جزيرة T»: كبسولة عائمة أعلى الشاشة فوق أي تطبيق (تعمل على كل الأجهزة بإذن «الظهور فوق التطبيقات»).
 * اضغط الكبسولة لتتمدّد إلى بطاقة تحكم كاملة، واضغط الغلاف لفتح التطبيق.
 */
class Island(private val ctx: Context, private val player: Player) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var pill: LinearLayout? = null
    private var card: LinearLayout? = null
    private var pillArt: ImageView? = null
    private var cardArt: ImageView? = null
    private var pillTitle: TextView? = null
    private var cardTitle: TextView? = null
    private var cardArtist: TextView? = null
    private var bars: BarsView? = null
    private var progress: ProgressBar? = null
    private var playBtn: ImageView? = null
    private var bg: GradientDrawable? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false
    private var dismissed = false
    private var artKey: CharSequence? = null
    private var accent = Color.WHITE

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying) dismissed = false; refresh() }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { refresh() }
        override fun onPlaybackStateChanged(playbackState: Int) { refresh() }
        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) { dismissed = false; refresh() }
    }

    init { player.addListener(listener) }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private val collapseRun = Runnable { setExpanded(false) }
    private val tick = object : Runnable {
        override fun run() {
            val d = player.duration
            if (expanded && d > 0) progress?.progress = (player.currentPosition * 1000 / d).toInt().coerceIn(0, 1000)
            if (expanded) h.postDelayed(this, 500)
        }
    }

    private fun canShow(): Boolean =
        IslandPrefs.enabled && !AppState.foreground && !dismissed && player.mediaItemCount > 0 &&
            player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED &&
            (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx))

    fun refresh() {
        h.post {
            if (canShow()) { attach(); bind() } else detach()
        }
    }

    private fun attach() {
        if (root != null) return
        val bgd = GradientDrawable().apply { setColor(0xF2000000.toInt()); cornerRadius = dp(18).toFloat() }
        bg = bgd
        val r = FrameLayout(ctx).apply { background = bgd; elevation = dp(8).toFloat() }

        fun art(sizeDp: Int, cornerDp: Int) = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0xFF333333.toInt()); cornerRadius = dp(cornerDp).toFloat() }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }

        // الكبسولة
        val pa = art(24, 12); pillArt = pa
        val pt = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8); marginEnd = dp(8) }
        }
        pillTitle = pt
        val bv = BarsView(ctx).apply { layoutParams = LinearLayout.LayoutParams(dp(16), dp(14)) }
        bars = bv
        val p = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(12), 0)
            addView(pa); addView(pt); addView(bv)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
            setOnClickListener { setExpanded(true) }
        }
        pill = p

        // البطاقة
        val ca = art(60, 14); cardArt = ca
        val ct = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val cr = TextView(ctx).apply { setTextColor(0xB3FFFFFF.toInt()); textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        cardTitle = ct; cardArtist = cr
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) }
            addView(ct); addView(cr)
        }
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(ca); addView(texts)
            setOnClickListener { openApp() }
        }
        val pb = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(12) }
        }
        progress = pb
        fun btn(res: Int, big: Boolean, onClick: () -> Unit) = ImageView(ctx).apply {
            setImageResource(res); setColorFilter(Color.WHITE)
            val s = dp(if (big) 52 else 44)
            layoutParams = LinearLayout.LayoutParams(0, s, 1f)
            setPadding(dp(if (big) 8 else 10), dp(if (big) 8 else 10), dp(if (big) 8 else 10), dp(if (big) 8 else 10))
            setOnClickListener { onClick(); h.removeCallbacks(collapseRun); h.postDelayed(collapseRun, 6000) }
        }
        val play = btn(android.R.drawable.ic_media_pause, true) { if (player.isPlaying) player.pause() else player.play() }
        playBtn = play
        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
            addView(btn(android.R.drawable.ic_media_previous, false) { player.seekToPrevious() })
            addView(play)
            addView(btn(android.R.drawable.ic_media_next, false) { player.seekToNext() })
            addView(btn(android.R.drawable.ic_menu_close_clear_cancel, false) { dismissed = true; setExpanded(false); refresh() })
        }
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(10))
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(head); addView(pb); addView(controls)
        }
        card = c
        r.addView(p); r.addView(c)

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            dp(176), ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(6) }
        params = lp
        root = r
        runCatching {
            wm.addView(r, lp)
            r.alpha = 0f; r.translationY = -dp(24).toFloat()
            r.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(OvershootInterpolator(1.4f)).start()
        }.onFailure { root = null }
    }

    private fun bind() {
        val md = player.mediaMetadata
        val title = md.title?.toString().orEmpty()
        pillTitle?.text = title
        cardTitle?.text = title
        cardArtist?.text = md.artist?.toString().orEmpty()
        bars?.active = player.isPlaying
        bars?.invalidate()
        playBtn?.setImageResource(if (player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        val key = (md.title ?: "").toString() + "|" + md.artworkUri
        if (key != artKey?.toString()) {
            artKey = key
            Thread {
                val b = ArtLoader.load(ctx, md, 160)
                val col = ArtLoader.accent(b)
                h.post {
                    if (artKey?.toString() != key) return@post
                    accent = col
                    if (b != null) { pillArt?.setImageBitmap(b); cardArt?.setImageBitmap(b) } else { pillArt?.setImageDrawable(null); cardArt?.setImageDrawable(null) }
                    bars?.color = col
                    progress?.progressTintList = android.content.res.ColorStateList.valueOf(col)
                    progress?.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x33FFFFFF)
                    // لمسة لون خفيفة على الخلفية
                    bg?.setColor(blend(0xF2000000.toInt(), col))
                }
            }.start()
        }
    }

    private fun blend(base: Int, c: Int): Int {
        val a = 0.14f
        fun mix(x: Int, y: Int) = (x * (1 - a) + y * a).toInt().coerceIn(0, 255)
        return Color.argb(0xF2, mix(Color.red(base), Color.red(c)), mix(Color.green(base), Color.green(c)), mix(Color.blue(base), Color.blue(c)))
    }

    private fun setExpanded(e: Boolean) {
        val r = root ?: return
        val lp = params ?: return
        if (e == expanded) return
        expanded = e
        h.removeCallbacks(collapseRun); h.removeCallbacks(tick)
        val screenW = ctx.resources.displayMetrics.widthPixels
        val from = lp.width
        val to = if (e) min(screenW - dp(24), dp(380)) else dp(176)
        bg?.cornerRadius = dp(if (e) 30 else 18).toFloat()
        pill?.visibility = if (e) View.GONE else View.VISIBLE
        card?.visibility = if (e) View.VISIBLE else View.GONE
        ValueAnimator.ofInt(from, to).apply {
            duration = 280
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener { lp.width = it.animatedValue as Int; runCatching { wm.updateViewLayout(r, lp) } }
            start()
        }
        if (e) { h.postDelayed(collapseRun, 6000); h.post(tick) }
    }

    private fun openApp() {
        runCatching {
            ctx.startActivity(
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }
        setExpanded(false)
    }

    private fun detach() {
        h.removeCallbacks(collapseRun); h.removeCallbacks(tick)
        val r = root ?: return
        root = null; expanded = false
        runCatching { wm.removeView(r) }
        params = null
    }

    fun release() {
        player.removeListener(listener)
        h.post { detach() }
    }
}
