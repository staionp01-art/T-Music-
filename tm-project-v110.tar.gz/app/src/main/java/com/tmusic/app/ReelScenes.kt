package com.tmusic.app

import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** كل قالب ريلز يرسم إطارًا واحدًا على Canvas بحجم 720×1280 عند الزمن t (بالثواني). */
interface ReelFrame {
    fun draw(c: Canvas, t: Float)
    fun recycle()
}

/** أسماء القوالب بالترتيب نفسه الذي يستعمله ReelMaker (0..3). */
val reelTemplateNames = listOf("زجاجي", "ساكورا", "غلاف نابض", "أسطوانة")

/**
 * طيف صوتي لكل إطار فيديو (32 نطاقًا بين 0 و1)، محسوب من الصوت الحقيقي للمقطع.
 * إن فشل فكّ الصوت نرسم طيفًا تقريبيًا حتى لا يتوقف الريلز.
 */
class Spectrum(private val frames: Array<FloatArray>?, private val fps: Int) {
    val real: Boolean get() = frames != null && frames.isNotEmpty()

    /** يملأ out بقيم n عمودًا عند الزمن t. */
    fun at(t: Float, out: FloatArray) {
        val n = out.size
        val fr = frames
        if (fr == null || fr.isEmpty()) {
            for (i in 0 until n) {
                val a = abs(sin(t * 3.1 + i * 0.7)).toFloat()
                val b = 0.55f + 0.45f * sin(t * 1.3 + i * 0.21).toFloat()
                out[i] = (0.12f + 0.8f * a * b).coerceIn(0f, 1f)
            }
            return
        }
        val f = fr[(t * fps).toInt().coerceIn(0, fr.size - 1)]
        for (i in 0 until n) {
            val pos = i * (f.size - 1) / max(1, n - 1).toFloat()
            val lo = pos.toInt().coerceIn(0, f.size - 1)
            val hi = min(lo + 1, f.size - 1)
            val k = pos - lo
            out[i] = f[lo] * (1f - k) + f[hi] * k
        }
    }

    /** شدّة الجهير (أول نطاقات الطيف) للنبض. */
    fun bass(t: Float): Float {
        val fr = frames ?: return 0.5f + 0.5f * sin(2.0 * PI * 2.0 * t).toFloat()
        if (fr.isEmpty()) return 0f
        val f = fr[(t * fps).toInt().coerceIn(0, fr.size - 1)]
        var s = 0f
        val k = min(4, f.size)
        for (i in 0 until k) s += f[i]
        return (s / k).coerceIn(0f, 1f)
    }

    companion object {
        const val BANDS = 32
    }
}

object AudioAnalysis {
    /** يحلّل PCM (16 بت) إلى طيف لكل إطار فيديو بتحويل فورييه سريع (FFT) من 1024 عيّنة. */
    fun analyze(data: ByteArray, rate: Int, ch: Int, fps: Int, bandCount: Int): Array<FloatArray> {
        val frameBytes = 2 * ch
        val totalSamples = data.size / frameBytes
        val frames = (totalSamples.toLong() * fps / rate).toInt().coerceAtLeast(1)
        val n = 1024
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val re = FloatArray(n)
        val im = FloatArray(n)
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }

        // حدود النطاقات: مقياس لوغاريتمي من أول سلة إلى نحو 12 كيلوهرتز
        val binHz = rate / n.toFloat()
        val hiBin = min(n / 2 - 1, (12000f / binHz).toInt()).coerceAtLeast(bandCount + 2)
        val edges = IntArray(bandCount + 1)
        val lnLo = ln(1.0)
        val lnHi = ln(hiBin.toDouble())
        for (b in 0..bandCount) {
            edges[b] = exp(lnLo + (lnHi - lnLo) * b / bandCount).toInt().coerceIn(1, n / 2 - 1)
            // نضمن أن كل نطاق منخفض يأخذ سلة ترددية خاصة به فلا تتكرر أعمدة الجهير
            if (b > 0 && edges[b] <= edges[b - 1]) edges[b] = min(edges[b - 1] + 1, n / 2 - 1)
        }

        val out = Array(frames) { FloatArray(bandCount) }
        val prev = FloatArray(bandCount)
        for (f in 0 until frames) {
            val center = (f.toLong() * rate / fps).toInt()
            val start = center - n / 2
            for (i in 0 until n) {
                val s = start + i
                var v = 0f
                if (s in 0 until totalSamples) {
                    var sum = 0
                    for (c in 0 until ch) sum += bb.getShort((s * ch + c) * 2).toInt()
                    v = sum / (ch * 32768f)
                }
                re[i] = v * win[i]
                im[i] = 0f
            }
            fft(re, im)
            for (b in 0 until bandCount) {
                val lo = edges[b]
                val hi = max(edges[b + 1], lo + 1)
                var m = 0f
                for (k in lo until hi) {
                    val mag = sqrt(re[k] * re[k] + im[k] * im[k]) * 4f / n
                    if (mag > m) m = mag
                }
                // الأصوات العالية أضعف طاقة فنرفعها قليلًا ليتوازن الشكل
                val db = 20f * log10(m + 1e-7f) + b * 0.55f
                val cur = ((db + 72f) / 52f).coerceIn(0f, 1f)
                val p = prev[b]
                val v = if (cur > p) p + (cur - p) * 0.65f else p + (cur - p) * 0.22f
                prev[b] = v
                out[f][b] = v
            }
        }
        return out
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            val half = len / 2
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until half) {
                    val a = i + k
                    val b = a + half
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi
                    re[a] = re[a] + vr; im[a] = im[a] + vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}

private const val SW = 720
private const val SH = 1280

private fun accentOf(art: Bitmap?, fallback: Int): Int {
    if (art == null) return fallback
    return try {
        val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.55f); hsv[2] = hsv[2].coerceAtLeast(0.9f)
        Color.HSVToColor(hsv)
    } catch (_: Throwable) { fallback }
}

private fun tpaint(size: Float, color: Int = Color.WHITE, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; textAlign = align
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

private fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}

/** قالب «زجاجي»: خلفية متحركة من الغلاف وبطاقة زجاجية فيها الغلاف والعنوان وخط التقدّم وموجات حول عبارة. */
class GlassScene(
    ctx: android.content.Context, private val song: Song, private val art: Bitmap?,
    private val lenSec: Int, private val startMs: Long, private val label: String, private val spec: Spectrum
) : ReelFrame {
    private val accent = accentOf(art, Color.rgb(120, 190, 190))
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val logo: Bitmap? = runCatching { BitmapFactory.decodeResource(ctx.resources, R.drawable.tm_logo) }.getOrNull()
    private val bg: Bitmap? = art?.let { Bitmap.createScaledBitmap(it, 40, 40, true) }
    private val title = tpaint(38f, bold = true)
    private val artist = tpaint(29f, Color.argb(190, 255, 255, 255))
    private val small = tpaint(24f, Color.argb(200, 255, 255, 255))
    private val lab = tpaint(32f, Color.WHITE, bold = true, align = Paint.Align.CENTER).apply { letterSpacing = 0.12f }
    private val tag = tpaint(40f, Color.WHITE, bold = true, align = Paint.Align.CENTER)
    private val cta = tpaint(34f, Color.argb(210, 255, 255, 255), align = Paint.Align.CENTER)
    private val tTitle = TextUtils.ellipsize(song.title, title, 540f, TextUtils.TruncateAt.END).toString()
    private val tArtist = TextUtils.ellipsize(song.artist, artist, 540f, TextUtils.TruncateAt.END).toString()
    private val text = (label.ifBlank { "T MUSIC" }).take(22)
    private val coverPath = Path()

    override fun recycle() { runCatching { bg?.recycle() } }

    override fun draw(c: Canvas, t: Float) {
        val bass = spec.bass(t)

        // خلفية متحركة: الغلاف مموَّهًا يتمدد ويدور ببطء وينبض مع الجهير
        c.drawColor(Color.rgb(8, 10, 12))
        if (bg != null) {
            c.save()
            val z = 1.55f + 0.05f * sin(t * 0.35f) + 0.06f * bass
            c.translate(SW / 2f + 40f * sin(t * 0.27f), SH / 2f + 60f * sin(t * 0.21f + 1f))
            c.rotate(6f * sin(t * 0.18f))
            c.scale(z, z)
            val side = SH.toFloat()
            c.drawBitmap(bg, null, RectF(-side / 2f, -side / 2f, side / 2f, side / 2f), paint)
            c.restore()
        }
        c.drawColor(Color.argb(150, 0, 0, 0))
        paint.shader = RadialGradient(
            SW / 2f, 600f, 640f,
            Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, SW.toFloat(), SH.toFloat(), paint); paint.shader = null

        // العلامة العلوية
        logo?.let {
            val h = 64f; val w = h * it.width / it.height
            c.drawBitmap(it, null, RectF(SW / 2f - w / 2f, 70f, SW / 2f + w / 2f, 70f + h), paint)
        }
        c.drawText("T Music", SW / 2f, 190f, tag)

        // البطاقة الزجاجية
        val card = RectF(50f, 330f, 670f, 940f)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(70, 20, 22, 26); c.drawRoundRect(card, 48f, 48f, paint)
        paint.color = Color.argb(34, 255, 255, 255); c.drawRoundRect(card, 48f, 48f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
        paint.color = Color.argb(70, 255, 255, 255); c.drawRoundRect(card, 48f, 48f, paint)
        paint.style = Paint.Style.FILL

        // الغلاف
        val beat = 1f + 0.035f * bass
        val cs = 300f * beat
        val cx = SW / 2f; val cy = 530f
        val dst = RectF(cx - cs / 2, cy - cs / 2, cx + cs / 2, cy + cs / 2)
        c.save()
        coverPath.reset(); coverPath.addRoundRect(dst, 44f, 44f, Path.Direction.CW)
        c.clipPath(coverPath)
        if (art != null) c.drawBitmap(art, coverCrop(art, dst), dst, paint) else { paint.color = accent; c.drawRect(dst, paint) }
        c.restore()

        // العنوان والفنان
        c.drawText(tTitle, 90f, 725f, title)
        c.drawText(tArtist, 90f, 772f, artist)

        // خط التقدّم بزمن الأغنية الحقيقي
        val total = max(song.duration, 1L)
        val nowMs = startMs + (t * 1000f).toLong()
        val frac = (nowMs.toFloat() / total).coerceIn(0f, 1f)
        val x0 = 90f; val x1 = 630f; val py = 815f
        paint.color = Color.argb(80, 255, 255, 255)
        c.drawRoundRect(RectF(x0, py - 3f, x1, py + 3f), 3f, 3f, paint)
        paint.color = Color.WHITE
        c.drawRoundRect(RectF(x0, py - 3f, x0 + (x1 - x0) * frac, py + 3f), 3f, 3f, paint)
        c.drawCircle(x0 + (x1 - x0) * frac, py, 8f, paint)
        c.drawText(clock(nowMs), x0, 858f, small)
        val rem = "-" + clock((total - nowMs).coerceAtLeast(0L))
        small.textAlign = Paint.Align.RIGHT; c.drawText(rem, x1, 858f, small); small.textAlign = Paint.Align.LEFT

        // عبارة في الوسط وموجات متحركة على جانبيها
        val ly = 910f
        c.drawText(text, SW / 2f, ly, lab)
        val half = lab.measureText(text) / 2f + 22f
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.WHITE
        wave(c, x0, SW / 2f - half, ly - 12f, t, bass, false)
        wave(c, SW / 2f + half, x1, ly - 12f, t, bass, true)
        paint.style = Paint.Style.FILL

        c.drawText("استمع إلى المزيد على T Music", SW / 2f, 1240f, cta)
    }

    private val wp = Path()
    private fun wave(c: Canvas, a: Float, b: Float, y: Float, t: Float, bass: Float, mirror: Boolean) {
        if (b - a < 20f) return
        wp.reset()
        val amp = 4f + 16f * bass
        var x = a
        var first = true
        while (x <= b) {
            val k = (x - a) / (b - a)
            val env = sin(PI * k).toFloat()
            val ph = if (mirror) -t * 5.5f else t * 5.5f
            val yy = y + amp * env * sin(x * 0.06f + ph) * (0.6f + 0.4f * sin(x * 0.021f - t * 2f))
            if (first) { wp.moveTo(x, yy); first = false } else wp.lineTo(x, yy)
            x += 4f
        }
        c.drawPath(wp, paint)
    }
}

/**
 * قالب «ساكورا»: مشهد ليلي بأشجار كرز وتساقط بتلات وماء يعكس البطاقة، وبطاقة أفقية فيها الغلاف والعنوان
 * وأزرار التحكم وطيف صوتي حقيقي. لا توجد فيه نجوم أو خطوط مضيئة عمودية.
 */
class SakuraScene(
    ctx: android.content.Context, private val song: Song, private val art: Bitmap?,
    private val lenSec: Int, private val startMs: Long, private val label: String, private val spec: Spectrum
) : ReelFrame {
    private val accent = accentOf(art, Color.rgb(255, 120, 190))
    private val theme = ReelTheme.pick(art)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val logo: Bitmap? = runCatching { BitmapFactory.decodeResource(ctx.resources, R.drawable.tm_logo) }.getOrNull()
    private val tree: Bitmap = buildTree()
    private val horizon = 1000f
    private val card = RectF(40f, 620f, 680f, 960f)
    private val coverRect = RectF(card.left + 12f, card.top + 12f, card.left + 12f + 286f, card.bottom - 12f)
    private val colX = card.left + 12f + 286f + 24f
    private val colR = card.right - 24f
    private val bars = FloatArray(24)
    private val tag = tpaint(40f, Color.WHITE, bold = true, align = Paint.Align.CENTER)
    private val cta = tpaint(34f, Color.argb(210, 255, 255, 255), align = Paint.Align.CENTER)
    private val head = tpaint(32f, Color.WHITE, bold = true).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
    private val tt = tpaint(25f, Color.WHITE, bold = true)
    private val ta = tpaint(20f, Color.argb(200, 255, 255, 255))
    private val small = tpaint(19f, Color.argb(210, 255, 255, 255))
    private val tTitle = TextUtils.ellipsize(song.title, tt, colR - colX, TextUtils.TruncateAt.END).toString()
    private val tArtist = TextUtils.ellipsize(song.artist, ta, colR - colX, TextUtils.TruncateAt.END).toString()
    private val brand: String = run {
        val s = label.ifBlank { "T MUSIC" }.take(26).uppercase()
        while (head.textSize > 18f && head.measureText(s) > colR - colX) head.textSize -= 1f
        s
    }

    private class Petal(val x: Float, val y: Float, val sp: Float, val ph: Float, val sz: Float, val rot: Float, val sway: Float)
    private val petals: List<Petal> = run {
        val r = java.util.Random(7)
        List(48) {
            Petal(
                r.nextFloat() * SW, r.nextFloat() * (SH + 120f), 40f + r.nextFloat() * 70f,
                r.nextFloat() * 6.28f, 9f + r.nextFloat() * 10f, 40f + r.nextFloat() * 120f, 18f + r.nextFloat() * 36f
            )
        }
    }

    private fun buildTree(): Bitmap {
        val w = 420; val h = 660
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // الجذع
        p.color = Color.rgb(38, 16, 28)
        val trunk = Path().apply {
            moveTo(w * 0.46f, h.toFloat()); lineTo(w * 0.50f, h * 0.55f); lineTo(w * 0.47f, h * 0.38f)
            lineTo(w * 0.53f, h * 0.38f); lineTo(w * 0.56f, h * 0.55f); lineTo(w * 0.60f, h.toFloat()); close()
        }
        c.drawPath(trunk, p)
        val br = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 9f; color = Color.rgb(38, 16, 28); strokeCap = Paint.Cap.ROUND }
        c.drawLine(w * 0.50f, h * 0.56f, w * 0.22f, h * 0.36f, br)
        c.drawLine(w * 0.52f, h * 0.52f, w * 0.80f, h * 0.34f, br)
        // التاج: عنقود دوائر وردية بشفافيات مختلفة
        val rnd = java.util.Random(21)
        for (i in 0 until 150) {
            val a = rnd.nextFloat() * 6.28f
            val d = sqrt(rnd.nextFloat())
            val x = w * 0.5f + cos(a.toDouble()).toFloat() * d * w * 0.46f
            val y = h * 0.30f + sin(a.toDouble()).toFloat() * d * h * 0.26f
            val r = 18f + rnd.nextFloat() * 34f
            val tone = rnd.nextFloat()
            p.color = (theme.leaf(tone) and 0x00FFFFFF) or ((70 + rnd.nextInt(120)) shl 24)
            c.drawCircle(x, y, r, p)
        }
        // وهج ناعم فوق التاج
        p.shader = RadialGradient(w * 0.5f, h * 0.30f, w * 0.5f, theme.glowA(70), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(w * 0.5f, h * 0.30f, w * 0.5f, p)
        p.shader = null
        return b
    }

    override fun recycle() { runCatching { tree.recycle() } }

    override fun draw(c: Canvas, t: Float) {
        spec.at(t, bars)
        val bass = spec.bass(t)

        // السماء: تدرّج بنفسجي داكن مع ضوء وردي من الأعلى
        paint.shader = LinearGradient(0f, 0f, 0f, horizon, intArrayOf(theme.skyTop, theme.skyMid, theme.skyLow), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, SW.toFloat(), horizon, paint)
        paint.shader = RadialGradient(
            SW / 2f, 0f, 760f, theme.glowA(120 + (40 * bass).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, SW.toFloat(), horizon, paint); paint.shader = null

        // العلامة العلوية
        logo?.let {
            val h = 64f; val w = h * it.width / it.height
            c.drawBitmap(it, null, RectF(SW / 2f - w / 2f, 70f, SW / 2f + w / 2f, 70f + h), paint)
        }
        c.drawText("T Music", SW / 2f, 190f, tag)

        drawFar(c, t, bass)

        // الأشجار على الجانبين مع تمايل خفيف
        val sway = 2.2f * sin(t * 0.7f)
        drawTree(c, 20f, sway, false)
        drawTree(c, SW - 20f, -sway, true)

        // ضباب وردي عند الأفق
        paint.shader = LinearGradient(0f, horizon - 120f, 0f, horizon + 10f, Color.TRANSPARENT, theme.glowA(150), Shader.TileMode.CLAMP)
        c.drawRect(0f, horizon - 120f, SW.toFloat(), horizon + 10f, paint); paint.shader = null

        // البطاقة تطفو بحركة بسيطة
        val bob = 7f * sin(t * 1.1f)
        val tilt = 1.1f * sin(t * 0.6f)
        c.save()
        c.translate(0f, bob)
        c.rotate(tilt, SW / 2f, (card.top + card.bottom) / 2f)
        drawCardBody(c, t, bass)
        c.restore()

        // الماء والانعكاس
        drawWater(c, t, bob, tilt)

        // البتلات المتساقطة فوق كل شيء
        paint.style = Paint.Style.FILL
        for (p in petals) {
            val yy = (p.y + t * p.sp) % (SH + 120f) - 60f
            val xx = p.x + sin(t * 0.9f + p.ph) * p.sway
            c.save()
            c.translate(xx, yy)
            c.rotate(p.rot + t * 60f * (0.6f + p.ph / 12f))
            paint.color = (theme.petal(p.ph / 6.28f) and 0x00FFFFFF) or (215 shl 24)
            val fy = if (theme.kind == 3) 1f else 0.55f
            c.drawOval(RectF(-p.sz, -p.sz * fy, p.sz, p.sz * fy), paint)
            c.restore()
        }

        c.drawText("استمع إلى المزيد على T Music", SW / 2f, 1240f, cta)
    }

    /** عنصر بعيد حسب السمة: توري (غروب)، باغودا (غابة)، قمر (ثلج)، جبال (حبر). */
    private fun drawFar(c: Canvas, t: Float, bass: Float) {
        paint.style = Paint.Style.FILL
        val cx = SW / 2f
        when (theme.kind) {
            1 -> {
                paint.color = Color.argb(235, 110, 14, 18)
                val base = card.top + 20f; val top = base - 330f; val pw = 22f; val half = 130f
                c.drawRect(cx - half, top + 60f, cx - half + pw, base, paint)
                c.drawRect(cx + half - pw, top + 60f, cx + half, base, paint)
                val kasa = Path()
                kasa.moveTo(cx - half - 50f, top + 10f); kasa.lineTo(cx + half + 50f, top + 10f)
                kasa.lineTo(cx + half + 28f, top + 44f); kasa.lineTo(cx - half - 28f, top + 44f); kasa.close()
                c.drawPath(kasa, paint)
                c.drawRect(cx - half - 12f, top + 66f, cx + half + 12f, top + 90f, paint)
            }
            2 -> {
                paint.color = Color.argb(235, 8, 22, 18)
                var w = 210f; var y = card.top + 20f
                for (i in 0 until 4) {
                    val h = 64f
                    c.drawRect(cx - w * 0.36f, y - h, cx + w * 0.36f, y, paint)
                    val roof = Path()
                    roof.moveTo(cx - w * 0.62f, y - h + 8f); roof.lineTo(cx + w * 0.62f, y - h + 8f)
                    roof.lineTo(cx + w * 0.42f, y - h - 22f); roof.lineTo(cx - w * 0.42f, y - h - 22f); roof.close()
                    c.drawPath(roof, paint)
                    y -= h + 14f; w *= 0.8f
                }
                c.drawRect(cx - 3f, y - 56f, cx + 3f, y + 4f, paint)
            }
            3 -> {
                val my = 420f + 6f * sin(t * 0.5f)
                paint.shader = RadialGradient(cx, my, 190f, Color.argb(120 + (40 * bass).toInt(), 190, 215, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                c.drawCircle(cx, my, 190f, paint); paint.shader = null
                paint.color = Color.rgb(238, 244, 255)
                c.drawCircle(cx, my, 64f, paint)
            }
            4 -> {
                for (layer in 0 until 3) {
                    paint.color = Color.argb(90 + layer * 50, 14 + layer * 10, 14 + layer * 10, 20 + layer * 10)
                    val baseY = horizon - 80f - layer * 20f
                    val path = Path()
                    path.moveTo(0f, horizon); path.lineTo(0f, baseY)
                    var x = 0f
                    var k = 0
                    while (x < SW) {
                        x += 90f + layer * 20f
                        path.lineTo(x - 45f, baseY - 190f + layer * 40f + 30f * (k % 3))
                        path.lineTo(x, baseY)
                        k++
                    }
                    path.lineTo(SW.toFloat(), horizon); path.close()
                    c.drawPath(path, paint)
                }
            }
        }
    }

    private fun drawTree(c: Canvas, cx: Float, sway: Float, mirror: Boolean) {
        val sc = 1.25f
        c.save()
        c.translate(cx, horizon + 30f - tree.height * sc)
        if (mirror) c.scale(-1f, 1f)
        c.scale(sc, sc)
        c.rotate(sway, 0f, tree.height.toFloat())
        c.drawBitmap(tree, -tree.width / 2f, 0f, paint)
        c.restore()
    }

    private fun drawCardBody(c: Canvas, t: Float, bass: Float) {
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(240, 22, 10, 28); c.drawRoundRect(card, 18f, 18f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
        paint.color = Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawRoundRect(card, 18f, 18f, paint)
        paint.style = Paint.Style.FILL

        // الغلاف
        c.save()
        val cp = Path().apply { addRoundRect(coverRect, 10f, 10f, Path.Direction.CW) }
        c.clipPath(cp)
        if (art != null) c.drawBitmap(art, coverCrop(art, coverRect), coverRect, paint) else { paint.color = accent; c.drawRect(coverRect, paint) }
        c.restore()

        // الأعمدة (طيف حقيقي) في أسفل البطاقة، تحت الأزرار
        val base = card.bottom - 12f
        val n = bars.size
        val bw = (colR - colX) / (n * 1.6f)
        val gap = bw * 0.6f
        paint.shader = LinearGradient(colX, 0f, colR, 0f, Color.rgb(70, 220, 255), accent, Shader.TileMode.CLAMP)
        paint.alpha = 215
        var x = colX
        for (i in 0 until n) {
            val h = 4f + 38f * bars[i]
            c.drawRoundRect(RectF(x, base - h, x + bw, base), bw / 2f, bw / 2f, paint)
            x += bw + gap
        }
        paint.shader = null; paint.alpha = 255

        // الاسم والعنوان والفنان
        c.drawText(brand, colX, card.top + 56f, head)
        c.drawText(tTitle, colX, card.top + 104f, tt)
        c.drawText(tArtist, colX, card.top + 134f, ta)

        // خط التقدّم والأزمنة
        val total = max(song.duration, 1L)
        val nowMs = startMs + (t * 1000f).toLong()
        val frac = (nowMs.toFloat() / total).coerceIn(0f, 1f)
        val py = card.top + 166f
        paint.color = Color.argb(90, 255, 255, 255)
        c.drawRoundRect(RectF(colX, py - 2f, colR, py + 2f), 2f, 2f, paint)
        paint.color = Color.WHITE
        c.drawRoundRect(RectF(colX, py - 2f, colX + (colR - colX) * frac, py + 2f), 2f, 2f, paint)
        c.drawText(clock(nowMs), colX, py + 26f, small)
        small.textAlign = Paint.Align.RIGHT
        c.drawText("-" + clock((total - nowMs).coerceAtLeast(0L)), colR, py + 26f, small)
        small.textAlign = Paint.Align.LEFT

        // أزرار التحكم
        val cy = card.top + 232f
        val step = (colR - colX) / 6f
        paint.color = Color.WHITE
        icon(c, 0, colX + step * 0.5f, cy)
        icon(c, 1, colX + step * 1.5f, cy)
        icon(c, 2, colX + step * 2.5f, cy)
        icon(c, 3, colX + step * 3.5f, cy)
        icon(c, 4, colX + step * 4.5f, cy)
        icon(c, 5, colX + step * 5.5f, cy)
    }

    /** أيقونات بسيطة مرسومة بالمسارات: 0 نغمة، 1 السابق، 2 تشغيل، 3 التالي، 4 تكرار، 5 عشوائي. */
    private fun icon(c: Canvas, kind: Int, x: Float, y: Float) {
        val s = 11f
        val p = Path()
        paint.style = Paint.Style.FILL
        when (kind) {
            0 -> {
                c.drawCircle(x - s * 0.35f, y + s * 0.6f, s * 0.42f, paint)
                c.drawRect(x + s * 0.0f, y - s * 0.9f, x + s * 0.16f, y + s * 0.6f, paint)
                p.moveTo(x + s * 0.16f, y - s * 0.9f); p.lineTo(x + s * 0.75f, y - s * 0.45f); p.lineTo(x + s * 0.16f, y - s * 0.3f); p.close()
                c.drawPath(p, paint)
            }
            1 -> {
                p.moveTo(x + s * 0.7f, y - s * 0.7f); p.lineTo(x - s * 0.5f, y); p.lineTo(x + s * 0.7f, y + s * 0.7f); p.close()
                c.drawPath(p, paint)
                c.drawRect(x - s * 0.8f, y - s * 0.7f, x - s * 0.6f, y + s * 0.7f, paint)
            }
            2 -> {
                p.moveTo(x - s * 0.55f, y - s * 0.85f); p.lineTo(x + s * 0.85f, y); p.lineTo(x - s * 0.55f, y + s * 0.85f); p.close()
                c.drawPath(p, paint)
            }
            3 -> {
                p.moveTo(x - s * 0.7f, y - s * 0.7f); p.lineTo(x + s * 0.5f, y); p.lineTo(x - s * 0.7f, y + s * 0.7f); p.close()
                c.drawPath(p, paint)
                c.drawRect(x + s * 0.6f, y - s * 0.7f, x + s * 0.8f, y + s * 0.7f, paint)
            }
            4 -> {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.6f
                c.drawArc(RectF(x - s * 0.8f, y - s * 0.6f, x + s * 0.8f, y + s * 0.6f), 200f, 250f, false, paint)
                paint.style = Paint.Style.FILL
                p.moveTo(x + s * 0.9f, y - s * 0.55f); p.lineTo(x + s * 0.35f, y - s * 0.75f); p.lineTo(x + s * 0.45f, y - s * 0.1f); p.close()
                c.drawPath(p, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.6f
                c.drawLine(x - s * 0.9f, y - s * 0.55f, x + s * 0.5f, y + s * 0.55f, paint)
                c.drawLine(x - s * 0.9f, y + s * 0.55f, x + s * 0.5f, y - s * 0.55f, paint)
                paint.style = Paint.Style.FILL
                p.moveTo(x + s * 0.95f, y - s * 0.55f); p.lineTo(x + s * 0.4f, y - s * 0.9f); p.lineTo(x + s * 0.4f, y - s * 0.2f); p.close()
                c.drawPath(p, paint)
                val q = Path()
                q.moveTo(x + s * 0.95f, y + s * 0.55f); q.lineTo(x + s * 0.4f, y + s * 0.9f); q.lineTo(x + s * 0.4f, y + s * 0.2f); q.close()
                c.drawPath(q, paint)
            }
        }
    }

    /** الماء: ضوء وردي عند الأفق، انعكاس مموّج للغلاف والبطاقة يتلاشى للأسفل، وخطوط لمعان أفقية. */
    private fun drawWater(c: Canvas, t: Float, bob: Float, tilt: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, horizon, 0f, SH.toFloat(), theme.water1, theme.water2, Shader.TileMode.CLAMP)
        c.drawRect(0f, horizon, SW.toFloat(), SH.toFloat(), paint); paint.shader = null

        val reflH = 300f
        val area = RectF(0f, horizon, SW.toFloat(), horizon + reflH)
        val layer = c.saveLayer(area, null)
        val strip = 6f
        var y = horizon
        var i = 0
        while (y < horizon + reflH) {
            val dx = 7f * sin(t * 2.2f + i * 0.55f) * (0.4f + i / 50f)
            c.save()
            c.clipRect(0f, y, SW.toFloat(), y + strip)
            c.translate(dx, 0f)
            // ننعكس حول الأفق: y' = 2*horizon - y
            c.translate(0f, 2f * horizon)
            c.scale(1f, -1f)
            c.translate(0f, bob)
            c.rotate(tilt, SW / 2f, (card.top + card.bottom) / 2f)
            paint.color = Color.argb(240, 22, 10, 28); c.drawRoundRect(card, 18f, 18f, paint)
            if (art != null) c.drawBitmap(art, coverCrop(art, coverRect), coverRect, paint)
            c.restore()
            y += strip; i++
        }
        // تلاشي الانعكاس تدريجيًا
        paint.shader = LinearGradient(0f, horizon, 0f, horizon + reflH, Color.argb(150, 0, 0, 0), Color.argb(0, 0, 0, 0), Shader.TileMode.CLAMP)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawRect(area, paint)
        paint.xfermode = null; paint.shader = null
        c.restoreToCount(layer)

        // لمعان الماء: خطوط أفقية رفيعة تتبدّل شفافيتها
        paint.style = Paint.Style.FILL
        for (k in 0 until 14) {
            val yy = horizon + 14f + k * 26f
            val w = 120f + 220f * abs(sin(t * 0.6f + k * 1.3f))
            val x = (k * 173f + t * (16f + k)) % (SW + 300f) - 150f
            paint.color = theme.glowA((40 + 50 * abs(sin(t + k))).toInt())
            c.drawRoundRect(RectF(x, yy, x + w, yy + 3f), 1.5f, 1.5f, paint)
        }
        // خط الأفق المضيء
        paint.shader = LinearGradient(0f, 0f, SW.toFloat(), 0f, intArrayOf(Color.TRANSPARENT, theme.glowA(220), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, horizon - 2f, SW.toFloat(), horizon + 3f, paint); paint.shader = null
    }
}
