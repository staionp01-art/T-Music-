package com.tmusic.app

import android.app.Activity
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Display
import android.view.FrameMetrics
import android.view.Window
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * محرّك «الزجاج السائل».
 * المستويات: 0 = بدون مؤثرات (أخف شيء)، 1 = زجاج (تدرجات + حافة ضوء + غلاف ضبابي)، 2 = سائل (+ خلفية متحركة + لمعان يمرّ).
 * الوضع التلقائي يختار المستوى حسب الجهاز، ويخفّضه وحده لو رصد تقطيعًا، ويحترم وضع توفير الطاقة.
 */
object Glass {
    /** 0 تلقائي، 1 أداء (بدون زجاج)، 2 زجاج، 3 سائل كامل */
    var quality by mutableIntStateOf(0)
    /** 0 تلقائي، -1 الأقصى، وإلا قيمة بالهرتز (60/90/120) */
    var fps by mutableIntStateOf(0)
    var motion by mutableStateOf(true)
    var adaptive by mutableStateOf(true)
    /** عدد درجات التخفيض التلقائي بعد رصد تقطيع */
    var penalty by mutableIntStateOf(0)
    var powerSave by mutableStateOf(false)
    /** رسالة تُعرض مرة واحدة عند التخفيض التلقائي */
    var notice by mutableStateOf<String?>(null)
    /** عدّاد الفريمات الحقيقي فوق الشاشة */
    var showFps by mutableStateOf(false)

    private var base = 2
    private var prefs: android.content.SharedPreferences? = null
    private var inited = false

    /** المستوى الفعلي الذي تقرأه كل الواجهات. */
    val tier: Int
        get() = when (quality) {
            1 -> 0
            2 -> 1
            3 -> 2
            else -> ((base - penalty) - (if (powerSave) 1 else 0)).coerceIn(0, 2)
        }

    val tierName: String
        get() = when (tier) { 0 -> "أداء"; 1 -> "زجاج"; else -> "سائل" }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val app = ctx.applicationContext
        val p = app.getSharedPreferences("tm_glass", Context.MODE_PRIVATE)
        prefs = p
        // الإصدار 2: الافتراضي الآن «سائل» بأقصى معدل إطارات وبدون خفض تلقائي (يُصفَّر مرة واحدة)
        if (!p.getBoolean("v2", false)) p.edit().clear().putBoolean("v2", true).apply()
        quality = p.getInt("quality", 3)
        fps = p.getInt("fps", -1)
        motion = p.getBoolean("motion", true)
        adaptive = p.getBoolean("adaptive", false)
        penalty = p.getInt("penalty", 0)
        showFps = p.getBoolean("showFps", false)
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        base = when {
            am.isLowRamDevice -> 1
            Build.VERSION.SDK_INT < 26 -> 1
            Runtime.getRuntime().availableProcessors() <= 4 && Build.VERSION.SDK_INT < 29 -> 1
            else -> 2
        }
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        powerSave = pm.isPowerSaveMode
        runCatching {
            app.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) { powerSave = pm.isPowerSaveMode }
            }, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED))
        }
    }

    fun save() {
        prefs?.edit()?.putInt("quality", quality)?.putInt("fps", fps)?.putBoolean("motion", motion)
            ?.putBoolean("adaptive", adaptive)?.putInt("penalty", penalty)?.putBoolean("showFps", showFps)?.apply()
    }

    fun resetAuto() { penalty = 0; notice = null; save() }

    // ---------- معدل التحديث ----------
    @Suppress("DEPRECATION")
    private fun displayOf(a: Activity): Display =
        (if (Build.VERSION.SDK_INT >= 30) a.display else null) ?: a.windowManager.defaultDisplay

    /** المعدلات التي تدعمها الشاشة فعلًا بنفس الدقة الحالية. */
    fun supportedRates(a: Activity): List<Int> = runCatching {
        val d = displayOf(a)
        val cur = d.mode
        d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .map { it.refreshRate.roundToInt() }.distinct().sorted()
    }.getOrDefault(listOf(60))

    fun currentRate(a: Activity): Int = runCatching { displayOf(a).refreshRate.roundToInt() }.getOrDefault(60)

    fun applyRefresh(a: Activity) {
        runCatching {
            val lp = a.window.attributes
            val d = displayOf(a)
            val cur = d.mode
            val same = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            val maxHz = same.maxOfOrNull { it.refreshRate } ?: 60f
            if (fps == 0) {
                lp.preferredDisplayModeId = 0
                lp.preferredRefreshRate = 0f
            } else {
                val want = if (fps == -1) maxHz else fps.toFloat()
                // أقرب نمط مدعوم لا يقل عن المطلوب، وإلا أعلى نمط متاح
                val m = same.filter { it.refreshRate >= want - 0.5f }.minByOrNull { it.refreshRate } ?: same.maxByOrNull { it.refreshRate }
                if (m != null) {
                    lp.preferredDisplayModeId = m.modeId
                    lp.preferredRefreshRate = m.refreshRate
                }
            }
            a.window.attributes = lp
        }
    }

    // ---------- مراقب التقطيع (لا يُجبر النظام على رسم إطارات إضافية) ----------
    private var listener: Window.OnFrameMetricsAvailableListener? = null
    private var thread: HandlerThread? = null
    private var attachedAt = 0L
    private var frames = 0
    private var janky = 0
    private var badRuns = 0

    fun attach(a: Activity) {
        detach(a)
        if (Build.VERSION.SDK_INT < 24) return
        runCatching {
            val th = HandlerThread("tm-frames").also { it.start() }
            thread = th
            attachedAt = SystemClock.uptimeMillis()
            frames = 0; janky = 0; badRuns = 0
            val main = Handler(Looper.getMainLooper())
            val l = Window.OnFrameMetricsAvailableListener { _, fm, _ ->
                if (quality != 0 || !adaptive || tier == 0) return@OnFrameMetricsAvailableListener
                if (SystemClock.uptimeMillis() - attachedAt < 5000) return@OnFrameMetricsAvailableListener
                if (fm.getMetric(FrameMetrics.FIRST_DRAW_FRAME) == 1L) return@OnFrameMetricsAvailableListener
                val hz = currentRate(a).coerceAtLeast(30)
                val budget = 1_000_000_000L / hz
                val total = fm.getMetric(FrameMetrics.TOTAL_DURATION)
                frames++
                if (total > budget * 1.5) janky++
                if (frames >= 120) {
                    val ratio = janky / frames.toFloat()
                    frames = 0; janky = 0
                    if (ratio > 0.20f) badRuns++ else badRuns = 0
                    if (badRuns >= 2) {
                        badRuns = 0
                        main.post {
                            if (penalty < base) {
                                penalty++
                                save()
                                notice = "خفّضتُ مستوى الزجاج تلقائيًا لسلاسة أفضل (${tierName})"
                            }
                        }
                    }
                }
            }
            listener = l
            a.window.addOnFrameMetricsAvailableListener(l, Handler(th.looper))
        }
    }

    fun detach(a: Activity) {
        runCatching { listener?.let { a.window.removeOnFrameMetricsAvailableListener(it) } }
        listener = null
        runCatching { thread?.quitSafely() }
        thread = null
    }
}

/**
 * سطح زجاجي: تدرّج شفاف + لمعة علوية + حافة ضوء + (اختياريًا) غلاف الأغنية مموّهًا بالداخل.
 * في المستوى 2 يمرّ لمعان بطيء فوق السطح. في المستوى 0 يصبح سطحًا معتمًا خفيفًا.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(24.dp),
    tint: Color = Color.White,
    art: Bitmap? = null,
    strength: Float = 1f
): Modifier = composed {
    val tier = Glass.tier
    val moving = tier >= 2 && Glass.motion
    val phase = if (moving) rememberInfiniteTransition(label = "glass-sheen").animateFloat(
        0f, 1f, infiniteRepeatable(tween(8500, easing = LinearEasing)), label = "sheen"
    ) else null
    val tiny = remember(art) {
        art?.let { runCatching { Bitmap.createScaledBitmap(it, 24, 24, true).asImageBitmap() }.getOrNull() }
    }
    this.clip(shape).drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        if (tier == 0) {
            tmOutline(outline, TM.Raised.copy(alpha = 0.96f))
            tmOutline(outline, Color.White.copy(alpha = 0.10f), style = Stroke(1.dp.toPx()))
            return@drawBehind
        }
        tmOutline(outline, Color.Black.copy(alpha = 0.30f))
        // طبقة حليبية ناعمة (تشبه الزجاج المصنفر في iOS)
        tmOutline(outline, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.06f))))
        tmOutline(outline, tint.copy(alpha = (0.08f * strength).coerceIn(0f, 1f)))
        if (tiny != null) {
            drawImage(
                tiny, dstSize = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1)),
                alpha = 0.55f * strength.coerceAtMost(1f), filterQuality = FilterQuality.High
            )
            drawRect(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.42f))))
        }
        // توهّج عدسي: زاوية علوية بيضاء وزاوية سفلية بلون الغلاف (يعطي إحساس السائل)
        val mn = minOf(size.width, size.height)
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent), center = Offset(size.width * 0.12f, size.height * 0.05f), radius = mn * 1.1f),
            radius = mn * 1.1f, center = Offset(size.width * 0.12f, size.height * 0.05f)
        )
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = (0.24f * strength).coerceIn(0f, 0.5f)), Color.Transparent), center = Offset(size.width * 0.95f, size.height), radius = mn * 1.0f),
            radius = mn * 1.0f, center = Offset(size.width * 0.95f, size.height)
        )
        // لمعة علوية
        drawRect(
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.12f), Color.Transparent)),
            size = Size(size.width, size.height * 0.45f)
        )
        // ظل داخلي سفلي
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.22f))),
            topLeft = Offset(0f, size.height * 0.55f), size = Size(size.width, size.height * 0.45f)
        )
        val ph = phase
        if (ph != null) {
            val x = (ph.value * 2.2f - 0.6f) * size.width
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.13f), Color.Transparent),
                    start = Offset(x, 0f), end = Offset(x + size.width * 0.35f, size.height)
                )
            )
        }
        // حواف منكسرة (فرق لوني دقيق على الأطراف مثل الزجاج الحقيقي)
        if (tier >= 2) {
            val o = 0.8.dp.toPx()
            translate(o, o) { tmOutline(outline, Color.White.copy(alpha = 0.10f), style = Stroke(1.dp.toPx())) }
            translate(-o, -o) { tmOutline(outline, Color.White.copy(alpha = 0.06f), style = Stroke(1.dp.toPx())) }
        }
        // حافة الضوء
        tmOutline(
            outline,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.70f), Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f), Color.White.copy(alpha = 0.40f)),
                start = Offset.Zero, end = Offset(size.width, size.height)
            ),
            style = Stroke(1.2.dp.toPx())
        )
    }
}

/** خلفية التطبيق: أسود + بقع لونية تنساب ببطء بلون غلاف الأغنية الحالية. */
@Composable
fun LiquidBackdrop(pal: CoverPalette, modifier: Modifier = Modifier) {
    val tier = Glass.tier
    val accent by animateColorAsState(pal.accent, tween(900), label = "bd-accent")
    val bg by animateColorAsState(pal.bg, tween(900), label = "bd-bg")
    val t = if (tier >= 2 && Glass.motion) rememberInfiniteTransition(label = "bd").animateFloat(
        0f, 1f, infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Restart), label = "bd-t"
    ) else null
    Canvas(modifier.fillMaxSize()) {
        drawRect(TM.Ink)
        if (tier == 0) return@Canvas
        val ph = (t?.value ?: 0.15f) * 6.2832f
        val w = size.width; val h = size.height
        fun blob(cx: Float, cy: Float, r: Float, c: Color, a: Float) {
            drawCircle(
                Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy)
            )
        }
        blob(w * (0.20f + 0.12f * sin(ph)), h * (0.16f + 0.05f * cos(ph * 0.8f)), w * 0.95f, accent, 0.32f)
        blob(w * (0.88f + 0.08f * cos(ph * 0.7f)), h * (0.55f + 0.07f * sin(ph * 1.1f)), w * 1.05f, bg, 0.55f)
        blob(w * (0.30f + 0.14f * sin(ph * 0.5f + 1f)), h * (0.93f + 0.03f * cos(ph)), w * 0.9f, accent, 0.20f)
    }
}

/** يعيد النشاط الحاضن لأي Context (لضبط معدل التحديث وقراءة الشاشة). */
fun Context.hostActivity(): Activity? {
    var c: Context? = this
    while (c is android.content.ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
